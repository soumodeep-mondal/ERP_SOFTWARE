<?php include('db/conn.php');
// Retrieve form data
$vendor_name = $_POST['vendor_name'];
$vendor_person_name = $_POST['vendor_person_name'];
$vendor_address = $_POST['vendor_address'];
$vendor_contact_no = $_POST['vendor_contact_no'];
$vendor_state = $_POST['vendor_state'];
$vendor_state_code = $_POST['vendor_state_code'];
$vendor_gst = $_POST['vendor_gst'];

// Insert into database
$sql = "INSERT INTO vendor_master (vendor_name, vendor_person_name, vendor_address, vendor_contact_no, vendor_state, vendor_state_code, vendor_gst) VALUES ('$vendor_name', '$vendor_person_name', '$vendor_address', '$vendor_contact_no', '$vendor_state', '$vendor_state_code', '$vendor_gst')";
if ($conn->query($sql) === TRUE) {
    $newVendorId = $conn->insert_id;
    $newVendor = array(
        'vendor_id' => $newVendorId,
        'vendor_name' => $vendor_name
    );
    echo json_encode($newVendor);
} else {
    echo json_encode(array('error' => $conn->error));
}

$conn->close();
?>
