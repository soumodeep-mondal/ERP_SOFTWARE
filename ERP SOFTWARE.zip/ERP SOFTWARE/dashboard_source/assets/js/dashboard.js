
    // Function to confirm deletion
    function DeleteRecheck() {
        if (confirm("Are you sure to delete?")) {
            return true;
        } else {
            return false;
        }
    }

    // Function to convert input data to uppercase
    function convert_data_to_upper(x) {
        x.value = x.value.toUpperCase();
    }

    // Function to check if input is numeric
    function check_numeric(x) {
        var validChars = "-0123456789.";
        var i = 0;
        var numberOfDecimalPoints = 0;

        while (i < x.value.length) {
            if (validChars.indexOf(x.value.charAt(i)) == -1) {
                x.value = x.value.substring(0, i);
                return false;
            }
            if (".".indexOf(x.value.charAt(i)) != -1) {
                numberOfDecimalPoints++;
                if (numberOfDecimalPoints > 1) {
                    x.value = x.value.substring(0, i);
                    return false;
                }
            }
            i++;
        }
    }

    // Function to check if input is a decimal number
    function check_decimal(x) {
        var validChars = "0123456789.";
        var i = 0;
        var numberOfDecimalPoints = 0;

        while (i < x.value.length) {
            if (validChars.indexOf(x.value.charAt(i)) == -1) {
                x.value = x.value.substring(0, i);
                return false;
            }
            if (".".indexOf(x.value.charAt(i)) != -1) {
                numberOfDecimalPoints++;
                if (numberOfDecimalPoints > 1) {
                    x.value = x.value.substring(0, i);
                    return false;
                }
            }
            i++;
        }
    }

