<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
 

// Update operation
if (isset($_POST['change_password'])) {
    $user_id = $_POST['user_id'];
    $old_password= $_POST['old_password'];
    $new_password= $_POST['new_password'];
    $confirm_password= $_POST['confirm_password'];

    $sql = "SELECT * FROM user_master WHERE user_id = '$user_id' AND password ='$old_password'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
    $count = mysqli_num_rows($result);
    if ($count == 1) {
        if ($old_password != $new_password) {

            if ($new_password == $confirm_password) {
                $sql = "UPDATE user_master SET password = '$new_password' WHERE user_id = '$user_id'";
                if (mysqli_query($conn, $sql)) {
                    $msg="succ=Password changed successfully.";
                    header("location:change_password.php?" . $msg);
                } else {
                    $msg="err=Error changing password.";
                    header("location:change_password.php?old_password=".$old_password."&new_password=".$new_password."&confirm_password=".$confirm_password."&" . $msg);
                }
            } else {
                $msg="err=New password and confirm password do not match.";
                header("location:change_password.php?old_password=".$old_password."&new_password=".$new_password."&confirm_password=".$confirm_password."&" . $msg);
            }
        }
        else {
            $msg="err=Old password and new password is same! Please give new password.";
            header("location:change_password.php?old_password=".$old_password."&new_password=".$new_password."&confirm_password=".$confirm_password."&" . $msg);
        }
    } 
    else {
        $msg="err=Old password is incorrect.";
        header("location:change_password.php?old_password=".$old_password."&new_password=".$new_password."&confirm_password=".$confirm_password."&" . $msg);
         
    }



 


    // $sql = "UPDATE `user_master` SET `password`='$new_password' WHERE `user_id` = $user_id";

    // if (mysqli_query($conn, $sql)) {
    //     $msg = "succ=Vendor record updated successfully";
    // } else {
    //     $msg = "err=Error updating record: " . mysqli_error($conn);
    // }

    // header("location:vendor_master.php?" . $msg);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Change Password</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
<?php
 
    $fetch_user_password = mysqli_query($conn, "SELECT `user_name`, `password` FROM user_master WHERE user_id = '$user_id_session'");
    if ($fetch = mysqli_fetch_array($fetch_user_password)) {
        $user_name = $fetch['user_name'];
        $password = $fetch['password'];
    }

?>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Change Password</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      
            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">New Password</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->


                            <form action="" method="post" enctype="multipart/form-data" onsubmit="validatePasswords(event)">
                                <input type="hidden" id="user_id" name="user_id" readonly="readonly" value="<?php echo $user_id_session; ?>" />

                                <div class="row">
                                    <div class="col-sm-3 form-group">
                                        <label>Old Password  <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="old_password" id="old_password" placeholder="Enter old password" value="<?php if(isset($_REQUEST['old_password'])){ echo $_REQUEST['old_password'];} ?>" required />

                                    </div>

                                    <div class="col-sm-3 form-group">
                                        <label>New Password <span class="text-danger">*</span></label>
                                        <input class="form-control" type="password" name="new_password" id="new_password" placeholder="Enter new password" value="<?php if(isset($_REQUEST['new_password'])){ echo $_REQUEST['new_password']; }?>" required />
                                    </div>

                                    <div class="col-sm-3 form-group">
                                        <label>Confirm Password <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="confirm_password" id="confirm_password" placeholder="Enter confirm password" value="<?php if(isset($_REQUEST['confirm_password'])){ echo $_REQUEST['confirm_password'];} ?>" required>
                                    </div>

                                    <div class="col-sm-2 form-group mt-4 pt-2">
                                        <button class="btn btn-success" type="submit" name="change_password">Change</button>
                                    </div>
                                </div>
                                <div id="message"></div>
                            </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

 
         
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
 

</body>

</html>
