<?php
include('db/conn.php');

if(isset($_POST['username'])) {
    $username = $_POST['username'];
    
    // Sanitize the input (optional, but recommended)
    $username = htmlspecialchars($username); // You might need more robust sanitization based on your application
    
    // Query to check if username exists
    $query = "SELECT COUNT(*) AS count FROM user_master WHERE user_name = '$username'";
    
    $result = $conn->query($query); // Execute the query
    
    if ($result === false) {
        die("Error: " . $conn->error); // Handle query errors
    }
    
    $row = $result->fetch_assoc();
    
    if($row['count'] > 0) {
        echo '<span style="color: red;">Username not available</span>';
    } else {
        echo '<span style="color: green;">Username available</span>';
    }
}

// Close connection
$conn->close();
?>