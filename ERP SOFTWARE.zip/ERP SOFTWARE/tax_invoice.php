<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
 

if(isset($_POST['save'])){
    $invoice_no = $_POST['invoice_no'];
    $customer_id = $_POST['customer_id'];
    $invoice_date = $_POST['invoice_date'];
    $delivery_note = $_POST['delivery_note'];
    $mode_terms_payment = $_POST['mode_terms_payment'];
    $ref_no_date = $_POST['ref_no_date'];
    $other_reference = $_POST['other_reference'];
    $buyer_order_no = $_POST['buyer_order_no'];
    $buyer_order_date = $_POST['buyer_order_date'];
    $dispatch_doc_no = $_POST['dispatch_doc_no'];
    $delivery_note_date = $_POST['delivery_note_date'];
    $dispatch_through = $_POST['dispatch_through'];
    $dispatch_destination = $_POST['dispatch_destination'];
    $terms_delivery = $_POST['terms_delivery'];
    $consignee_name = $_POST['consignee_name'];
    $consignee_address = $_POST['consignee_address'];
    $consignee_gstin = $_POST['consignee_gstin'];
    $consignee_state_name = $_POST['consignee_state_name'];
    $buyer_name = $_POST['buyer_name'];
    $buyer_address = $_POST['buyer_address'];
    $buyer_gstin = $_POST['buyer_gstin'];
    $buyer_state_name = $_POST['buyer_state_name'];
    $place_supply = $_POST['place_supply'];
    $amount_chargeable_word = $_POST['amount_chargeable_word'];
    $tax_amount_word = $_POST['tax_amount_word'];
    $remarks = $_POST['remarks'];
    $irn_no = $_POST['irn_no'];
    $ack_no = $_POST['ack_no'];
    $ack_date = $_POST['ack_date'];
    $grand_total_qty = $_POST['grand_total_qty'];
    $grand_total_taxable_amt = $_POST['grand_total_taxable_amt'];
    $grand_total_cgst_amt = $_POST['grand_total_cgst_amt'];
    $grand_total_sgst_amt = $_POST['grand_total_sgst_amt'];
    $grand_total_amt = $_POST['grand_total_amt'];


    $sql1="INSERT INTO `tax_invoice`(`customer_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery`, `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`, `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply`, `amount_chargeable_word`, `tax_amount_word`, `remarks`, `irn_no`, `ack_no`, `ack_date`, `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt`)
     VALUES ('$customer_id', '$invoice_no','$invoice_date','$delivery_note','$mode_terms_payment','$ref_no_date','$other_reference','$buyer_order_no','$buyer_order_date','$dispatch_doc_no','$delivery_note_date','$dispatch_through','$dispatch_destination','$terms_delivery','$consignee_name','$consignee_address','$consignee_gstin','$consignee_state_name','$buyer_name','$buyer_address','$buyer_gstin','$buyer_state_name','$place_supply','$amount_chargeable_word','$tax_amount_word','$remarks','$irn_no','$ack_no','$ack_date','$grand_total_qty','$grand_total_taxable_amt','$grand_total_cgst_amt','$grand_total_sgst_amt','$grand_total_amt')";

    if ($conn->query($sql1) === TRUE){
        $tax_invoice_id_max=$conn->insert_id;
        // row1
        $qty1=trim($_POST['qty1']);
        $rate1=trim($_POST['rate1']);
        $per_value1=trim($_POST['per_value1']);
        $taxable_amt1=trim($_POST['taxable_amt1']);
        $cgst_rate1=trim($_POST['cgst_rate1']);
        $cgst_amt1=trim($_POST['cgst_amt1']);
        $sgst_rate1=trim($_POST['sgst_rate1']);
        $sgst_amt1=trim($_POST['sgst_amt1']);
        $total_amount1=trim($_POST['total_amount1']);
        $i=0;
        // row2
        $qty2=trim($_POST['qty2']);
        $rate2=trim($_POST['rate2']);
        $per_value2=trim($_POST['per_value2']);
        $taxable_amt2=trim($_POST['taxable_amt2']);
        $cgst_rate2=trim($_POST['cgst_rate2']);
        $cgst_amt2=trim($_POST['cgst_amt2']);
        $sgst_rate2=trim($_POST['sgst_rate2']);
        $sgst_amt2=trim($_POST['sgst_amt2']);
        $total_amount2=trim($_POST['total_amount2']);
        // row3
        $qty3=trim($_POST['qty3']);
        $rate3=trim($_POST['rate3']);
        $per_value3=trim($_POST['per_value3']);
        $taxable_amt3=trim($_POST['taxable_amt3']);
        $cgst_rate3=trim($_POST['cgst_rate3']);
        $cgst_amt3=trim($_POST['cgst_amt3']);
        $sgst_rate3=trim($_POST['sgst_rate3']);
        $sgst_amt3=trim($_POST['sgst_amt3']);
        $total_amount3=trim($_POST['total_amount3']);
        // row4
        $qty4=trim($_POST['qty4']);
        $rate4=trim($_POST['rate4']);
        $per_value4=trim($_POST['per_value4']);
        $taxable_amt4=trim($_POST['taxable_amt4']);
        $cgst_rate4=trim($_POST['cgst_rate4']);
        $cgst_amt4=trim($_POST['cgst_amt4']);
        $sgst_rate4=trim($_POST['sgst_rate4']);
        $sgst_amt4=trim($_POST['sgst_amt4']);
        $total_amount4=trim($_POST['total_amount4']);
        // row5
        $qty5=trim($_POST['qty5']);
        $rate5=trim($_POST['rate5']);
        $per_value5=trim($_POST['per_value5']);
        $taxable_amt5=trim($_POST['taxable_amt5']);
        $cgst_rate5=trim($_POST['cgst_rate5']);
        $cgst_amt5=trim($_POST['cgst_amt5']);
        $sgst_rate5=trim($_POST['sgst_rate5']);
        $sgst_amt5=trim($_POST['sgst_amt5']);
        $total_amount5=trim($_POST['total_amount5']);

        // row1
        if(isset($_POST['prod_name'][0]))
        {
            $prod_name=trim($_POST['prod_name'][0]);
            $hsn_sac_code=trim($_POST['hsn_sac_code'][0]);
            $sql2="INSERT INTO tax_invoice_details (tax_invoice_id, prod_name, hsn_sac_code, qty, rate, per_id, taxable_amt, cgst_rate, cgst_amt,sgst_rate,sgst_amt,total_amount) VALUES ('$tax_invoice_id_max', '$prod_name', '$hsn_sac_code','$qty1', '$rate1', '$per_value1', '$taxable_amt1', '$cgst_rate1','$cgst_amt1', '$sgst_rate1','$sgst_amt1','$total_amount1')";
            $insert2=mysqli_query($conn,$sql2);
        }
        // row2
        if(isset($_POST['prod_name'][1]))
        {
            $prod_name=trim($_POST['prod_name'][1]);
            $hsn_sac_code=trim($_POST['hsn_sac_code'][1]);
            $sql2="INSERT INTO tax_invoice_details (tax_invoice_id, prod_name, hsn_sac_code, qty,rate, per_id, taxable_amt,cgst_rate,cgst_amt,sgst_rate,sgst_amt,total_amount) VALUES ('$tax_invoice_id_max', '$prod_name', '$hsn_sac_code','$qty2', '$rate2', '$per_value2', '$taxable_amt2', '$cgst_rate2','$cgst_amt2', '$sgst_rate2','$sgst_amt2','$total_amount2')";
            $insert2=mysqli_query($conn,$sql2);
        }
        // row3
        if(isset($_POST['prod_name'][2]))
        {
            $prod_name=trim($_POST['prod_name'][2]);
            $hsn_sac_code=trim($_POST['hsn_sac_code'][2]);
            $sql2="INSERT INTO tax_invoice_details (tax_invoice_id, prod_name, hsn_sac_code, qty,rate, per_id, taxable_amt,cgst_rate,cgst_amt,sgst_rate,sgst_amt,total_amount) VALUES ('$tax_invoice_id_max', '$prod_name', '$hsn_sac_code','$qty3', '$rate3', '$per_value3', '$taxable_amt3', '$cgst_rate3','$cgst_amt3', '$sgst_rate3','$sgst_amt3','$total_amount3')";
            $insert2=mysqli_query($conn,$sql2);
        }
        // row4
        if(isset($_POST['prod_name'][3]))
        {
            $prod_name=trim($_POST['prod_name'][3]);
            $hsn_sac_code=trim($_POST['hsn_sac_code'][3]);
            $sql2="INSERT INTO tax_invoice_details (tax_invoice_id, prod_name, hsn_sac_code, qty,rate, per_id, taxable_amt, cgst_rate,cgst_amt,sgst_rate,sgst_amt,total_amount) VALUES ('$tax_invoice_id_max', '$prod_name', '$hsn_sac_code','$qty4', '$rate4', '$per_value4', '$taxable_amt4', '$cgst_rate4','$cgst_amt4', '$sgst_rate4','$sgst_amt4','$total_amount4')";
            $insert2=mysqli_query($conn,$sql2);
        }
        // row5
        if(isset($_POST['prod_name'][4]))
        {
            $prod_name=trim($_POST['prod_name'][4]);
            $hsn_sac_code=trim($_POST['hsn_sac_code'][4]);
            $sql2="INSERT INTO tax_invoice_details (tax_invoice_id, prod_name, hsn_sac_code, qty,rate, per_id, taxable_amt,cgst_rate,cgst_amt,sgst_rate,sgst_amt,total_amount) VALUES ('$tax_invoice_id_max', '$prod_name', '$hsn_sac_code','$qty5', '$rate5', '$per_value5', '$taxable_amt5', '$cgst_rate5','$cgst_amt5', '$sgst_rate4','$sgst_amt4','$total_amount5')";
            $insert2=mysqli_query($conn,$sql2);
        }

        $msg = "invoice_no=".$invoice_no."&invoice_date=".$invoice_date."&grand_total_amt=".$grand_total_amt."&succ=Tax Invoice Generated Successfully.";
 
    }
    else
    {
        $msg = "err=Tax Invoice Not Generated.";
    }

    header('location:tax_invoice.php?'.$msg);
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Tax Invoice</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
 

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Tax Invoice</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      


            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">TAX INVOICE</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>

                            <div class="ibox-body">
                                <!--==================DISPLAY MASSAGE=============================-->
                                <?php include('includes/display_massage.php'); ?>
                                <!--==================DISPLAY MASSAGE=============================-->

                                <?php 
                                if(isset($_REQUEST['invoice_no']))
                                {
                                ?>
                                <div class="alert alert-info alert-dismissable fade show">
                                    <button class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <h6>INVOICE NO : <?php echo $_REQUEST['invoice_no'];?></h6>
                                    <h6>INVOICE DATE : <?php echo $_REQUEST['invoice_date'];?></h6>
                                    <h6>TOTAL AMOUNT : <?php echo $_REQUEST['grand_total_amt'];?></h6>
                                </div>
                                <?php
                                }
                                ?>




                                <form action="" method="post">
                                <div class="row">
                                    <div class="col-lg-12 text-center">
                                      
                                        <h2 class="invoice-heading">Tax Invoice</h2>
                                        <h4 class="invoice-heading-sub">Orginal/Buyer's Copy/Triplicate Copy</h4>
                                        <hr>
                                    </div>
                                </div>

                                <?php if(isset($_POST['save'])){ ?>
                                    <div class="row p p-3 mb-2 bg-success">
                                        <div class="col-lg-12">
                                            <h3 class="text-center text-white">Form submitted successfully!</h3>
                                            <h6>INVOICE NO : <?php echo $_POST['invoice_no'];?></h6>
                                            <h6>INVOICE DATE : <?php echo $_POST['invoice_date'];?></h6>
                                            <a href="" style="color: black; text-decoration: none;"><h6>TOTAL AMOUNT : <?php echo $_POST['grand_total_amt'];?></h6></a>
                                        </div>
                                    </div>
                                    <hr>
                                    <?php }?>
                                
                                <!-- `irn_no`, `ack_no`, `ack_date` -->
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label for="customer_id"><span class="text-danger">*</span>&nbsp;COMPANY NAME :</label>
                                    </div>
                                    <div class="col-lg-3">
                                        <select id="customer_id" name="customer_id" class="form-control" required >
                                            <option value="">SELECT COMPANY NAME</option>
                                            <?php
                                            /* SELECT `customer_id`, `customer_company_name`, `customer_name`, `customer_mob`, `customer_address`, `customer_state_name`, `customer_state_code`, `customer_gst_in` FROM `master_customer` WHERE 1*/
                                            $q=mysqli_query($conn,"SELECT * FROM master_customer ORDER BY customer_company_name");
                                            while($f=mysqli_fetch_array($q))
                                            {
                                                $customer_id=$f['customer_id'];
                                                $customer_company_name=$f['customer_company_name'];
                                                ?>
                                                <option value="<?php echo $customer_id;?>" <?php if(isset($_REQUEST['xedit'])){ if($f['customer_id'] == $customer_id){ echo "selected";} }?>><?php echo $customer_company_name;?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-9 pt-3">
                                        <div class="row">
                                            <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                                                <p>IRN :<span class="text-danger"></p>
                                            </div>
                                            <div class="col-lg-11 ">
                                                <input class="" type="text" name="irn_no"  id="irn_no"  size="100%" placeholder="Enter IRN">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                                                <p>Ack No. :<span class="text-danger"></p>
                                            </div>
                                            <div class="col-lg-11">
                                                <input class="" type="text" name="ack_no"  id="ack_no"  size="100%" placeholder="Enter Ack No">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                                                <p>Ack Date :<span class="text-danger"></p>
                                            </div>
                                            <div class="col-lg-11">
                                                <input class="" type="date" name="ack_date"  id="ack_date"  size="100%" placeholder="Enter Date">
                                            </div>
                                        </div>
                                    </div>
                                 
                                </div>

                                <div class="row" style="border:2px solid black;">
                                    <div class="col-lg-6" style="border-right:2px solid black;">

                                        <div style="border-bottom:2px solid black;">
                                            <h5 class="pt-3"><b>A.R.Enterprise</b></h5>
                                            <h6>5A,Alimuddin Street, Kolkata-700016</h6>
                                            <h6>GSTIN/UIN: 19ADHPR3448R1ZL</h6>
                                            <h6>State Name : West Bengal, Code : 19</h6>
                                            <h6>E-Mail : ar.enterprise@yahoo.com</h6>
                                        </div>

                                        <!-- `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`,  -->
                                        <div style="border-bottom:2px solid black;">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h6 class="pt-1">Consignee (Ship to)</h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_name"  id="consignee_name"  size="100%" placeholder="Enter Name"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_address"  id="consignee_address"  size="100%" placeholder="Enter address"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">GSTIN/UIN:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_gstin"  id="consignee_gstin"  size="100%" placeholder=""></p>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">State Name:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_state_name"  id="consignee_state_name"  size="100%" placeholder=""></p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply` -->
                                        <div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h6 class="pt-1">Buyer (Bill to)</h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_name"  id="buyer_name"  size="100%" placeholder="Enter Name"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_address"  id="buyer_address"  size="100%" placeholder="Enter address"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">GSTIN/UIN:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_gstin"  id="buyer_gstin"  size="100%" placeholder=""></p>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">State Name:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_state_name"  id="buyer_state_name"  size="100%" placeholder=""></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">Place of Supply:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="place_supply"  id="place_supply"  size="100%" placeholder=""></p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- `tax_invoice_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery` -->
                                    <div class="col-lg-6">
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Invoice No.</h6>
                                                <p><input class="" type="text" name="invoice_no"  id="invoice_no"  size="100%" placeholder="Enter invoice no."></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Dated</h6>
                                                <p><input class="" type="date" name="invoice_date"  id="invoice_date"  size="100%" placeholder="Enter Date"></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Delivery Note</h6>
                                                <p><input class="" type="text" name="delivery_note"  id="delivery_note"  size="100%" placeholder=""></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Mode/Terms of Payment</h6>
                                                <p><input class="" type="text" name="mode_terms_payment"  id="mode_terms_payment"  size="100%" placeholder=""></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Reference No. & Date.</h6>
                                                <p><input class="" type="text" name="ref_no_date"  id="ref_no_date"  size="100%" placeholder=""></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Other References</h6>
                                                <p><input class="" type="text" name="other_reference"  id="other_reference"  size="100%" placeholder=""></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Buyer's Order No.</h6>
                                                <p><input class="" type="text" name="buyer_order_no"  id="buyer_order_no"  size="100%" placeholder=""></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Dated</h6>
                                                <p><input class="" type="date" name="buyer_order_date"  id="buyer_order_date"  size="100%" placeholder=""></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Dispatch Doc No.</h6>
                                                <p><input class="" type="text" name="dispatch_doc_no"  id="dispatch_doc_no"  size="100%" placeholder=""></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Delivery Note Date</h6>
                                                <p><input class="" type="text" name="delivery_note_date"  id="delivery_note_date"  size="100%" placeholder=""></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Dispatched through</h6>
                                                <p><input class="" type="text" name="dispatch_through"  id="dispatch_through"  size="100%" placeholder=""></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Destination</h6>
                                                <p><input class="" type="text" name="dispatch_destination"  id="dispatch_destination"  size="100%" placeholder=""></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <h6 class="pt-2">Terms of Delivery</h6>
                                                <p>
                                                    <textarea size="100%" name="terms_delivery"  id="terms_delivery"  id="" cols="100" rows="5"></textarea>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- SELECT `tax_invoice_details_id`, `description_goods`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE 1 -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div style="width:3%; border-right:2px solid black;border-left:2px solid black; text-align: center;">
                                        Sl No.
                                    </div>
                                    <div style="width:23%; border-right:2px solid black; text-align: center;">
                                        Description of Goods
                                    </div>
                                    <div style="width:10%; border-right:2px solid black;  text-align: center;">
                                        HSN/SAC
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Qty
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Rate
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Per
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Taxable Amt
                                    </div>
                                    <div style="width:15%; border-right:2px solid black;  text-align: center;">
                                        <div>
                                            <div style="width:100%; border-bottom:2px solid black;">
                                                <h6 class="text-center"><b>CGST</b></h6>
                                            </div>
                                            <div style="width:100%;">
                                                <div style="display:flex;">
                                                    <div style="width:50%; height:100%; border-right:2px solid black;">
                                                        <h6 class="text-center"><b>Rate</b></h6>

                                                    </div>
                                                    <div style="width:50%;">
                                                        <h6 class="text-center"><b>Amount</b></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="width:15%; border-right:2px solid black; text-align: center;">
                                        <div>
                                            <div style="width:100%; border-bottom:2px solid black;">
                                                <h6 class="text-center"><b>SGST&nbsp;/&nbsp;UGST</b></h6>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <h6 class="text-center"><b>Rate</b></h6>

                                                    </div>
                                                    <div class="col-lg-6">
                                                        <h6 class="text-center"><b>Amount</b></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="width:14%; border-right:2px solid black; text-align: center;">
                                        <p>Amount</p>
                                    </div>
                                </div>
                                <!-- ======================= bill section ======================= -->
 
                                <!-- =========== row 1 ============ -->
                                <div class="row" id="row1">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $prod_id;?>"><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty1"  id="qty1"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate1"  id="rate"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                            <select class="per_value" id="per_value" name="per_value1" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>"><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt1"  id="taxable_amt"  size="100%" placeholder="">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate1"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt1"  id="cgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate1"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt1"  id="sgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount1"  id="total_amount"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 2 ============ -->
                                <div class="row" id="row2">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $prod_id;?>"><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty2"  id="qty1"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate2"  id="rate"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value2" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>"><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt2"  id="taxable_amt"  size="100%" placeholder="">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate2"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt2"  id="cgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate2"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt2"  id="sgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount2"  id="total_amount"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 3 ============ -->
                                <div class="row" id="row3">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $prod_id;?>"><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty3"  id="qty1"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate3"  id="rate"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value3" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>"><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt3"  id="taxable_amt"  size="100%" placeholder="">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate3"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt3"  id="cgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate3"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt3"  id="sgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount3"  id="total_amount"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 4 ============ -->
                                <div class="row" id="row4">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $prod_id;?>"><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty4"  id="qty1"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate4"  id="rate"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value4" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>"><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt4"  id="taxable_amt"  size="100%" placeholder="">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate4"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt4"  id="cgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate4"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt4"  id="sgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount4"  id="total_amount"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 5 ============ -->
                                <div class="row" id="row5">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $prod_id;?>"><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty5"  id="qty1"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate5"  id="rate"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value5" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>"><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt5"  id="taxable_amt"  size="100%" placeholder="">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate5"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt5"  id="cgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate5"  id="gst_rate[]"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt5"  id="sgst_amt"  size="100%" placeholder="">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount5"  id="total_amount"  size="100%" placeholder="">
                                        </p>
                                    </div>
                                </div>

                                <!-- ======================================================================== -->
                                <!-- `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;"></div>
                                    <div class="text-right" style="width:23%; border-right:2px solid black;">
                                        <h5 class="pt-3"> <b>Total</b></h5>
                                    </div>
                                    <div class="" style="width:10%; border-right:2px solid black;"></div>

                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <h6 class="pt-3"> <b><input class="grand-total-qty" type="text" name="grand_total_qty"  id="grand_total_qty"  size="100%" placeholder=""></b></h6>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;"></div>
                                    <div class="" style="width:5%; border-right:2px solid black;"></div>

                                    <div class="" style="width:5%; border-right:2px solid black;">
                                    <h6 class="pt-3"> <b><input class="grand-total-tax-amt" type="text" name="grand_total_taxable_amt"  id="grand_total_taxable_amt"  size="100%" placeholder=""></b></h6></div>

                                    <div class="" style="width:15%; display:flex; border-right:2px solid black;">
                                        <div style="width:50%; height:100%; border-right:2px solid black;"></div>
                                        <div style="width:50%; height:100%;">
                                            <h6 class="pt-3"> <b><input class="grand-total-cgst-amt" type="text" name="grand_total_cgst_amt"  id="grand_total_cgst_amt"  size="100%" placeholder=""></b></h6>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%;display:flex; border-right:2px solid black;">
                                        <div style="width:50%; height:100%; border-right:2px solid black;"></div>
                                        <div style="width:50%; height:100%;">
                                            <h6 class="pt-3"> <b><input class="grand-total-sgst-amt" type="text" name="grand_total_sgst_amt"  id="grand_total_sgst_amt"  size="100%" placeholder=""></b></h6>       
                                        </div>
                                    </div>
                                    <div class="text-right" style="width:14%; border-right:2px solid black;">
                                        <h5 class="pt-3"><b>
                                            <input class="grand-total-amt" type="text" name="grand_total_amt"  id="grand_total_amt"  size="100%" placeholder="" >
                                        </b></h5>
                                    </div>
                                </div>
                                <!-- ======================================================================== -->

                                <!-- `amount_chargeable_word`, `tax_amount_word`, `remarks`,  -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-12 pt-1" style="border-right:2px solid black;border-left:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <p>Amount Chargeable (in words)</p>
                                            </div>
                                            <div class="col-lg-6">
                                                <p class="text-right">E. & O.E</p>
                                            </div>
                                        </div>
                                        <p> <input class="" type="text" name="amount_chargeable_word"  id="amount_chargeable_word"  onfocus="convertNumberToWords()" size="150%" placeholder=""></p>
                                    </div>
                                </div>

                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-1" style="border-right:2px solid black;border-left:2px solid black;">
                                        <h6 class="text-center"><b>HSN/SAC</b></h6>
                                    </div>
                                    <div class="col-lg-1 pt-1" style="border-right:2px solid black;">
                                        <h6 class="text-center"><b>Taxable Value</b></h6>
                                    </div>
                                    <div class="col-lg-5" style="border-right:2px solid black;">

                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">

                                                <div class="row">
                                                    <div class="col-lg-12" style="border-bottom:2px solid black;">
                                                        <h6 class="text-center"><b>CGST</b></h6>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                                <h6 class="text-center"><b>Rate</b></h6>

                                                            </div>
                                                            <div class="col-lg-6">
                                                                <h6 class="text-center"><b>Amount</b></h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">

                                                <div class="row">
                                                    <div class="col-lg-12" style="border-bottom:2px solid black;">
                                                        <h6 class="text-center"><b>SGST/UTGST</b></h6>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                                <h6 class="text-center"><b>Rate</b></h6>

                                                            </div>
                                                            <div class="col-lg-6">
                                                                <h6 class="text-center"><b>Amount</b></h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <h6 class="text-center"><b>Total Tax Amount</b></h6>
                                    </div>
                                </div>


                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                                        <p><input class="hsn_sac_code_output" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-5 " style="border-right:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                </div>

                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-5 " style="border-right:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                </div>

                                <!-- new cell grand total   -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                                        <h5 class="text-right"><b>Total</b></h5>
                                    </div>
                                    <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-5 " style="border-right:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                </div>
                                <!-- `amount_chargeable_word`, `tax_amount_word`, `remarks` -->
                                <div class="row pt-3" style="border-right:2px solid black;border-left:2px solid black;">
                                    <div class="col-lg-3">
                                        <h5>Tax Amount (in words) : </h5>
                                    </div>
                                    <div class="col-lg-9">
                                        <p><input class="" type="text" name="tax_amount_word"  id="tax_amount_word"  size="100%" placeholder="INR Five Hundred Thirty and Six paise Only"></p>
                                    </div>
                                </div>

                                <div class="row pt-3" style="border-bottom:2px solid black;border-right:2px solid black;border-left:2px solid black;">
                                    <div class="col-lg-6">
                                        <h5><b> Remarks: </b></h5>

                                        <textarea size="100" name="remarks"  id="remarks"  id="" cols="100" rows="3"></textarea>

                                        <div class="row pt-3">
                                            <div class="col-lg-6">
                                                <h5>
                                                    Company's PAN
                                                </h5>
                                            </div>
                                            <div class="col-lg-6">
                                                <h5>
                                                    <b>: ADHPR3448R</b>
                                                </h5>
                                            </div>
                                        </div>

                                        <div class="row pt-2">
                                            <div class="col-lg-12">
                                                <h5 style="text-decoration:underline;">
                                                    <b> Declaration</b>
                                                </h5>
                                                <p>We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</p>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="col-lg-6">
                                        <h5><b>Company's Bank Details</b></h5>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>A/c Holder's Name </h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b> : A.R.Enterprise</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>Bank Name </h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b>: Punjab National Bank</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>A/c No.</h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b> : 7870002100000553</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>Branch & IFS Code</h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b> : Baguiati & PUNB0787000</b></h5>
                                            </div>
                                        </div>


                                        <div class="row pt-5" style="border-top:2px solid black;border-left:2px solid black;">
                                            <div class="col-lg-4 pt-5">
                                                <div>
                                                    <img src="invoice/prepared_by.png" alt="">
                                                </div>
                                                <div class="text-center">
                                                    <h6>Prepared By</h6>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 pt-5">
                                                <div>
                                                    <img src="invoice/verified_by.png" alt="">
                                                </div>
                                                <div class="text-center">
                                                    <h6>Verified By </h6>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 pt-5">
                                                <div>
                                                    <img src="invoice/authorised_signatory.png" alt="">
                                                </div>
                                                <div class="text-center">
                                                    <h6>Authorised Signatory</h6>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row p">
                                    <div class="col-lg-12">
                                        <h5 class="text-center pt-4"><b>SUBJECT TO KOLKATA JURISDICTION</b></h5>
                                        <h6 class="text-center pt-4">This is a Computer Generated Invoice</h6>
                                    </div>
                                </div>
                                <div class="row justify-content-between">
                                    <div></div>
                                    <div>
                                        <button type="submit" name="save" id="save" class="btn btn-primary" style="width:150px"> SUBMIT </button>
                                    </div>
                                </div>
                                </form>
                            </div>                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">TAX INVOICE RECORDS</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row" style="border-bottom:1px solid #000; background-color:var(--primary-color);">
                                        <!-- /* SELECT `tax_invoice_id`, `customer_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery`, `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`, `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply`, `amount_chargeable_word`, `tax_amount_word`, `remarks`, `irn_no`, `ack_no`, `ack_date`, `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` FROM `tax_invoice` WHERE 1 */ -->

                                            <div class="col-lg-2 text-light text-center "><b>DATE</b></div>
                                            <div class="col-lg-3 text-light text-center "><b>COMPANY NAME</b></div>
                                            <div class="col-lg-3 text-light text-center "><b>INVOICE NO.</b></div>
                                            <div class="col-lg-2 text-light text-center "><b>TOTAL AMOUNT</b></div>
                                            <div class="col-lg-2 text-light text-center "><b>ACTION</b></div>

                                            
                                        </div>
                                        <?php
                                        /* SELECT `tax_invoice_id`, `customer_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery`, `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`, `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply`, `amount_chargeable_word`, `tax_amount_word`, `remarks`, `irn_no`, `ack_no`, `ack_date`, `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` FROM `tax_invoice` WHERE 1 */

                                            $count=0;
                                            $q="SELECT * FROM tax_invoice ORDER BY tax_invoice_id DESC";
                                            $display_result = mysqli_query($conn, $q);
                                            while ($fetch = mysqli_fetch_array($display_result)) {
                                                if ($count >= 100) {
                                                    break;
                                                }
                                                $tax_invoice_id = $fetch["tax_invoice_id"];
                                                $customer_id = $fetch["customer_id"];
                                                $invoice_no = $fetch["invoice_no"];
                                                $invoice_date = $fetch["invoice_date"];
                                                $delivery_note = $fetch["delivery_note"];
                                                $mode_terms_payment = $fetch["mode_terms_payment"];
                                                $ref_no_date = $fetch["ref_no_date"];
                                                $other_reference = $fetch["other_reference"];
                                                $buyer_order_no = $fetch["buyer_order_no"];
                                                $buyer_order_date = $fetch["buyer_order_date"];
                                                $dispatch_doc_no = $fetch["dispatch_doc_no"];
                                                $delivery_note_date = $fetch["delivery_note_date"];
                                                $dispatch_through = $fetch["dispatch_through"];
                                                $dispatch_destination = $fetch["dispatch_destination"];
                                                $terms_delivery = $fetch["terms_delivery"];
                                                $consignee_name = $fetch["consignee_name"];
                                                $consignee_address = $fetch["consignee_address"];
                                                $consignee_gstin = $fetch["consignee_gstin"];
                                                $consignee_state_name = $fetch["consignee_state_name"];
                                                $buyer_name = $fetch["buyer_name"];
                                                $buyer_address = $fetch["buyer_address"];
                                                $buyer_gstin = $fetch["buyer_gstin"];
                                                $buyer_state_name = $fetch["buyer_state_name"];
                                                $place_supply = $fetch["place_supply"];
                                                $amount_chargeable_word = $fetch["amount_chargeable_word"];
                                                $tax_amount_word = $fetch["tax_amount_word"];
                                                $remarks = $fetch["remarks"];
                                                $irn_no = $fetch["irn_no"];
                                                $ack_no = $fetch["ack_no"];
                                                $ack_date = $fetch["ack_date"];
                                                $grand_total_qty = $fetch["grand_total_qty"];
                                                $grand_total_taxable_amt = $fetch["grand_total_taxable_amt"];
                                                $grand_total_cgst_amt = $fetch["grand_total_cgst_amt"];
                                                $grand_total_sgst_amt = $fetch["grand_total_sgst_amt"];
                                                $grand_total_amt = $fetch["grand_total_amt"];

                                                /* SELECT `customer_id`, `customer_company_name`, `address`, `state_code`, `state_name`, `gst_in`, `opening_balance`, `date_of_creation` FROM `master_customer` WHERE 1 */
                                                $customer_company_name_sql="SELECT customer_company_name FROM master_customer WHERE customer_id='$customer_id'";
                                                $customer_company_name_result = mysqli_query($conn, $customer_company_name_sql);
                                                if($customer_company_name_row = mysqli_fetch_array($customer_company_name_result)){
                                                    $customer_company_name= $customer_company_name_row["customer_company_name"];
                                                }
                                                ?>
                                                <div class="row" >
                                                    <div class="col-lg-2 text-dark text-center " style="border:1px solid black;"><?php echo (DateTime::createFromFormat('Y-m-d', $invoice_date))->format('d/m/Y'); ?></div>
                                                    <div class="col-lg-3 text-dark text-center " style="border:1px solid black;"><?php echo $customer_company_name?></div>
                                                    <div class="col-lg-3 text-dark text-center "style="border:1px solid black;"><?php echo $invoice_no?></div>
                                                    <div class="col-lg-2 text-dark text-center "style="border:1px solid black;"><?php echo $grand_total_amt?></div>
                                                    <div class="col-lg-2 text-dark text-center "style="border:1px solid black;">
                                                        <!-- edit  -->
                                                        <button class="btn btn-primary" type="button" name="" onClick="window.location.href='tax_invoice_edit.php?xedit=1&tax_invoice_id=<?php echo $tax_invoice_id; ?>'">
                                                            <i class="fa-solid fa-edit"></i>
                                                            

                                                        </button>
                                                        <!-- view  -->
                                                        <button class="btn btn-success" type="button" name="" onClick="window.location.href='tax_invoice_view.php?view_data=1&tax_invoice_id=<?php echo $tax_invoice_id; ?>'">
                                                            <i class="fa-solid fa-eye"></i>
                                                        </button>
                                                        <!-- print  -->
                                                        <button class="btn btn-warning" type="button" name="btn_print" onClick="">
                                                            <i class="fa-solid fa-print"></i>
                                                        </button>
                                                    </div>                                                
                                                </div>
                                                <?php
                                                $count++;
                                            }
                                            
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>    





            
 
           
         
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>


    <script src="./autoComplete/JS-AjaxFiles/find_and_calculate_all_data.js"></script>


    <script>
        function updateSerialNumber(selectElement, rowNumber) {
            var selectedValue = selectElement.value;
            var serialNumberInput = document.querySelector('#row' + rowNumber + ' input[name="serial_number"]');
            serialNumberInput.value = selectedValue === '' ? '' : rowNumber.toString();
        }
    </script>

    <script>
        function numberToWords(number) {
            const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
            const teens = ['', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
            const tens = ['', 'Ten', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
            const scales = ['', 'Thousand', 'Lakh', 'Crore'];

            const toWords = (number) => {
                if (number === 0) return 'Zero';

                let words = '';

                const integerPart = Math.floor(number);
                const fractionalPart = Math.round((number - integerPart) * 100); // Get two decimal places

                if (integerPart > 0) {
                    words += convertToWords(integerPart) + ' Rupees';
                }

                if (fractionalPart > 0) {
                    words += (words ? ' and ' : '') + convertToWords(fractionalPart) + ' Paisa';
                }

                return words.trim().toUpperCase();
            };

            const convertToWords = (number) => {
                let words = '';

                for (let i = 0; number > 0 && i < scales.length; i++) {
                    let triplet = number % 1000;
                    if (triplet !== 0) {
                        let tripletWords = '';
                        let hundreds = Math.floor(triplet / 100);
                        let tensUnits = triplet % 100;

                        if (hundreds > 0) {
                            tripletWords += ones[hundreds] + ' Hundred ';
                        }

                        if (tensUnits > 0) {
                            if (tensUnits < 10) {
                                tripletWords += ones[tensUnits];
                            } else if (tensUnits < 20) {
                                tripletWords += teens[tensUnits - 10];
                            } else {
                                tripletWords += tens[Math.floor(tensUnits / 10)];
                                if (tensUnits % 10 !== 0) {
                                    tripletWords += ' ' + ones[tensUnits % 10];
                                }
                            }
                        }

                        words = tripletWords.trim() + ' ' + scales[i] + ' ' + words;
                    }

                    number = Math.floor(number / 1000);
                }

                return words.trim();
            };

            return toWords(number);
        }


        function convertNumberToWords() {
            const numberInput = document.getElementById("grand_total_amt");
            const number = numberInput.value;

            if (!isNaN(number)) {
                var words = numberToWords(number);
                document.getElementById("amount_chargeable_word").value = words;
            } else {
                wordsOutput.value = ''; // Clear the output field if the input is not a valid number
            }
        }

        document.getElementById("grand_total_amt").addEventListener("input", convertNumberToWords);

    </script>
</body>

</html>
