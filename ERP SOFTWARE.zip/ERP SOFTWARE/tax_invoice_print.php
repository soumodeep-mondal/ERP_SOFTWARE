<?php
include_once("db/conn.php");
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Tax Invoice</title>
    <link rel="shortcut icon" href="../assets/img/favicon.png" type="image/x-icon">
    <!-- GLOBAL MAINLY STYLES-->
    <link href="dashboard-source/assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="dashboard-source/assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="dashboard-source/assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="dashboard-source/assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="dashboard-source/assets/css/main.min.css" rel="stylesheet" />
    <link href="dashboard-source/assets/css/dashboard.css" rel="stylesheet" />
    <link href="dashboard-source/assets/css/invoice.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>
<?php if (isset($_REQUEST['view_data'])) {
        $tax_invoice_id = $_REQUEST["tax_invoice_id"];

        /* SELECT `tax_invoice_id`, `company_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery`, `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`, `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply`, `amount_chargeable_word`, `tax_amount_word`, `remarks`, `irn_no`, `ack_no`, `ack_date`, `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` FROM `tax_invoice` WHERE 1 */

        $sql="SELECT * FROM tax_invoice WHERE tax_invoice_id='$tax_invoice_id'";
        $result=mysqli_query($conn,$sql);
        if($fetch=mysqli_fetch_array($result)){
            $company_id = $fetch["company_id"];
            $invoice_no = $fetch["invoice_no"];
            $invoice_date = $fetch["invoice_date"];
            $delivery_note = $fetch["delivery_note"];
            $mode_terms_payment = $fetch["mode_terms_payment"];
            $ref_no_date = $fetch["ref_no_date"];
            $other_reference = $fetch["other_reference"];
            $buyer_order_no = $fetch["buyer_order_no"];
            $buyer_order_date = $fetch["buyer_order_date"];
            $dispatch_doc_no = $fetch["dispatch_doc_no"];
            $delivery_note_date = $fetch["delivery_note_date"];
            $dispatch_through = $fetch["dispatch_through"];
            $dispatch_destination = $fetch["dispatch_destination"];
            $terms_delivery = $fetch["terms_delivery"];
            $consignee_name = $fetch["consignee_name"];
            $consignee_address = $fetch["consignee_address"];
            $consignee_gstin = $fetch["consignee_gstin"];
            $consignee_state_name = $fetch["consignee_state_name"];
            $buyer_name = $fetch["buyer_name"];
            $buyer_address = $fetch["buyer_address"];
            $buyer_gstin = $fetch["buyer_gstin"];
            $buyer_state_name = $fetch["buyer_state_name"];
            $place_supply = $fetch["place_supply"];
            $amount_chargeable_word = $fetch["amount_chargeable_word"];
            $tax_amount_word = $fetch["tax_amount_word"];
            $remarks = $fetch["remarks"];
            $irn_no = $fetch["irn_no"];
            $ack_no = $fetch["ack_no"];
            $ack_date = $fetch["ack_date"];
            $grand_total_qty = $fetch["grand_total_qty"];
            $grand_total_taxable_amt = $fetch["grand_total_taxable_amt"];
            $grand_total_cgst_amt = $fetch["grand_total_cgst_amt"];
            $grand_total_sgst_amt = $fetch["grand_total_sgst_amt"];
            $grand_total_amt = $fetch["grand_total_amt"];
            
            /* SELECT `company_id`, `company_name`, `address`, `state_code`, `state_name`, `gst_in`, `opening_balance`, `date_of_creation` FROM `master_company` WHERE 1 */
            $company_name_sql="SELECT company_name FROM master_company WHERE company_id='$company_id'";
            $company_name_result = mysqli_query($conn, $company_name_sql);
            $company_name_row = mysqli_fetch_array($company_name_result);
            $company_name= $company_name_row["company_name"];
        }
        

        if(isset($_REQUEST["tax_invoice_id"]) && isset($_REQUEST["view_data"])){
            /* SELECT MIN(`tax_invoice_details_id`) AS first_tax_invoice_details_id FROM `tax_invoice_details` WHERE `tax_invoice_id` = ; */
            $sql_0="SELECT MIN(`tax_invoice_details_id`) AS first_tax_invoice_details_id FROM `tax_invoice_details` WHERE `tax_invoice_id` = '$tax_invoice_id'";
            $result_0=mysqli_query($conn,$sql_0);
            $fetch_0=mysqli_fetch_array($result_0);
            $tax_invoice_details_id_1= $fetch_0['first_tax_invoice_details_id'];
            $tax_invoice_details_id_2= $fetch_0['first_tax_invoice_details_id']+1;
            $tax_invoice_details_id_3= $fetch_0['first_tax_invoice_details_id']+2;
            $tax_invoice_details_id_4= $fetch_0['first_tax_invoice_details_id']+3;
            $tax_invoice_details_id_5= $fetch_0['first_tax_invoice_details_id']+4;
        }
    }
    ?>
    <form action="" method="post">
        <div class="row">
            <div class="col-lg-12 text-center">
                <img src="admin-source/images/logo2.png" width="200px" alt="">
                <h2 class="invoice-heading">Tax Invoice</h2>
                <h4 class="invoice-heading-sub">Orginal/Buyer's Copy/Triplicate Copy</h4>
                <hr>
            </div>
        </div>
        <!-- `irn_no`, `ack_no`, `ack_date` -->
        <div class="row">
            <div class="col-lg-2">
                <label for="company_id"><span class="text-danger">*</span>&nbsp;COMPANY NAME :</label>
            </div>
            <div class="col-lg-10">
                <input readonly class="form-control" type="text" id="company_name" name="company_name" value="<?php if(isset($_REQUEST['view_data'])){echo $company_name;}?>">
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-lg-9 pt-3">
                <div class="row">
                    <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                        <p>IRN :<span class="text-danger"></p>
                    </div>
                    <div class="col-lg-11 ">
                        <input readonly class="" type="text" name="irn_no"  id="irn_no"  size="100%" placeholder="Enter IRN" value="<?php if(isset($_REQUEST['view_data'])){echo $irn_no;}?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                        <p>Ack No. :<span class="text-danger"></p>
                    </div>
                    <div class="col-lg-11">
                        <input readonly class="" type="text" name="ack_no"  id="ack_no"  size="100%" placeholder="Enter Ack No" value="<?php if(isset($_REQUEST['view_data'])){echo $ack_no;}?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                        <p>Ack Date :<span class="text-danger"></p>
                    </div>
                    <div class="col-lg-11">
                        <input readonly class="" type="text" name="ack_date"  id="ack_date"  size="100%" placeholder="Enter Date" value="<?php if(isset($_REQUEST['view_data'])){echo $ack_date;}?>">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 pt-3">
                <img src="invoice/qr.png" width="100px" alt="" style="position:relative;left:50%;transform:translate(-50%,0);">
            </div>
        </div>

        <div class="row" style="border:2px solid black;">
            <div class="col-lg-6" style="border-right:2px solid black;">
            <?php echo $tax_invoice_details_id_1;?>
            <?php echo $tax_invoice_details_id_2;?>
            <?php echo $tax_invoice_details_id_3;?>
            <?php echo $tax_invoice_details_id_4;?>
            <?php echo $tax_invoice_details_id_5;?>
                <div style="border-bottom:2px solid black;">
                    <h5 class="pt-3"><b>A.R.Enterprise</b></h5>
                    <h6>5A,Alimuddin Street, Kolkata-700016</h6>
                    <h6>GSTIN/UIN: 19ADHPR3448R1ZL</h6>
                    <h6>State Name : West Bengal, Code : 19</h6>
                    <h6>E-Mail : ar.enterprise@yahoo.com</h6>
                </div>

                <!-- `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`,  -->
                <div style="border-bottom:2px solid black;">
                    <div class="row">
                        <div class="col-lg-12">
                            <h6 class="pt-1">Consignee (Ship to)</h6>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="pt-1"><input readonly class="" type="text" name="consignee_name"  id="consignee_name"  size="100%" placeholder="Enter Name" value="<?php if(isset($_REQUEST['view_data'])){echo $consignee_name;}?>"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="pt-1"><input readonly class="" type="text" name="consignee_address"  id="consignee_address"  size="100%" placeholder="Enter address" value="<?php if(isset($_REQUEST['view_data'])){echo $consignee_address;}?>"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <p class="pt-1">GSTIN/UIN:</p>
                        </div>
                        <div class="col-lg-9">
                            <p class="pt-1"><input readonly class="" type="text" name="consignee_gstin"  id="consignee_gstin"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $consignee_gstin;}?>"></p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-3">
                            <p class="pt-1">State Name:</p>
                        </div>
                        <div class="col-lg-9">
                            <p class="pt-1"><input readonly class="" type="text" name="consignee_state_name"  id="consignee_state_name"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $consignee_state_name;}?>"></p>
                        </div>
                    </div>
                </div>
                <!-- `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply` -->
                <div>
                    <div class="row">
                        <div class="col-lg-12">
                            <h6 class="pt-1">Buyer (Bill to)</h6>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="pt-1"><input readonly class="" type="text" name="buyer_name"  id="buyer_name"  size="100%" placeholder="Enter Name" value="<?php if(isset($_REQUEST['view_data'])){echo $buyer_name;}?>"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="pt-1"><input readonly class="" type="text" name="buyer_address"  id="buyer_address"  size="100%" placeholder="Enter address" value="<?php if(isset($_REQUEST['view_data'])){echo $buyer_address;}?>"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <p class="pt-1">GSTIN/UIN:</p>
                        </div>
                        <div class="col-lg-9">
                            <p class="pt-1"><input readonly class="" type="text" name="buyer_gstin"  id="buyer_gstin"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $buyer_gstin;}?>"></p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-3">
                            <p class="pt-1">State Name:</p>
                        </div>
                        <div class="col-lg-9">
                            <p class="pt-1"><input readonly class="" type="text" name="buyer_state_name"  id="buyer_state_name"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $buyer_state_name;}?>"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <p class="pt-1">Place of Supply:</p>
                        </div>
                        <div class="col-lg-9">
                            <p class="pt-1"><input readonly class="" type="text" name="place_supply"  id="place_supply"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $place_supply;}?>"></p>
                        </div>
                    </div>
                </div>

            </div>
            <!-- `tax_invoice_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery` -->
            <div class="col-lg-6">
                <div class="row" style="border-bottom:2px solid black;">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <h6 class="pt-2">Invoice No.</h6>
                        <p><input readonly class="" type="text" name="invoice_no"  id="invoice_no"  size="100%" placeholder="Enter invoice no." value="<?php if(isset($_REQUEST['view_data'])){echo $invoice_no;}?>"></p>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="pt-2">Dated</h6>
                        <p><input readonly class="" type="text" name="invoice_date"  id="invoice_date"  size="100%" placeholder="Enter Date" value="<?php if(isset($_REQUEST['view_data'])){echo $invoice_date;}?>"></p>
                    </div>
                </div>
                <div class="row" style="border-bottom:2px solid black;">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <h6 class="pt-2">Delivery Note</h6>
                        <p><input readonly class="" type="text" name="delivery_note"  id="delivery_note"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $delivery_note;}?>"></p>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="pt-2">Mode/Terms of Payment</h6>
                        <p><input readonly class="" type="text" name="mode_terms_payment"  id="mode_terms_payment"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $mode_terms_payment;}?>"></p>
                    </div>
                </div>
                <div class="row" style="border-bottom:2px solid black;">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <h6 class="pt-2">Reference No. & Date.</h6>
                        <p><input readonly class="" type="text" name="ref_no_date"  id="ref_no_date"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $ref_no_date;}?>"></p>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="pt-2">Other References</h6>
                        <p><input readonly class="" type="text" name="other_reference"  id="other_reference"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $other_reference;}?>"></p>
                    </div>
                </div>
                <div class="row" style="border-bottom:2px solid black;">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <h6 class="pt-2">Buyer's Order No.</h6>
                        <p><input readonly class="" type="text" name="buyer_order_no"  id="buyer_order_no"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $buyer_order_no;}?>"></p>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="pt-2">Dated</h6>
                        <p><input readonly class="" type="text" name="buyer_order_date"  id="buyer_order_date"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $buyer_order_date;}?>"></p>
                    </div>
                </div>
                <div class="row" style="border-bottom:2px solid black;">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <h6 class="pt-2">Dispatch Doc No.</h6>
                        <p><input readonly class="" type="text" name="dispatch_doc_no"  id="dispatch_doc_no"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $dispatch_doc_no;}?>"></p>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="pt-2">Delivery Note Date</h6>
                        <p><input readonly class="" type="text" name="delivery_note_date"  id="delivery_note_date"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $delivery_note_date;}?>"></p>
                    </div>
                </div>
                <div class="row" style="border-bottom:2px solid black;">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <h6 class="pt-2">Dispatched through</h6>
                        <p><input readonly class="" type="text" name="dispatch_through"  id="dispatch_through"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $dispatch_through;}?>"></p>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="pt-2">Destination</h6>
                        <p><input readonly class="" type="text" name="dispatch_destination"  id="dispatch_destination"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $dispatch_destination;}?>"></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <h6 class="pt-2">Terms of Delivery</h6>
                        <p>
                            <textarea readonly size="100%" name="terms_delivery"  id="terms_delivery"  id="" cols="100" rows="5"><?php if(isset($_REQUEST['view_data'])){echo $terms_delivery;}?></textarea>

                    </div>
                </div>
            </div>
        </div>
        <!-- SELECT `tax_invoice_details_id`, `description_goods`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE 1 -->
        <div class="row" style="border-bottom:2px solid black;">
            <div style="width:3%; border-right:2px solid black;border-left:2px solid black; text-align: center;">
                Sl No.
            </div>
            <div style="width:23%; border-right:2px solid black; text-align: center;">
                Description of Goods
            </div>
            <div style="width:10%; border-right:2px solid black;  text-align: center;">
                HSN/SAC
            </div>
            <div style="width:5%; border-right:2px solid black; text-align: center;">
                Qty
            </div>
            <div style="width:5%; border-right:2px solid black; text-align: center;">
                Rate
            </div>
            <div style="width:5%; border-right:2px solid black; text-align: center;">
                Per
            </div>
            <div style="width:5%; border-right:2px solid black; text-align: center;">
                Taxable Amt
            </div>
            <div style="width:15%; border-right:2px solid black;  text-align: center;">
                <div>
                    <div style="width:100%; border-bottom:2px solid black;">
                        <h6 class="text-center"><b>CGST</b></h6>
                    </div>
                    <div style="width:100%;">
                        <div style="display:flex;">
                            <div style="width:50%; height:100%; border-right:2px solid black;">
                                <h6 class="text-center"><b>Rate</b></h6>

                            </div>
                            <div style="width:50%;">
                                <h6 class="text-center"><b>Amount</b></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="width:15%; border-right:2px solid black; text-align: center;">
                <div>
                    <div style="width:100%; border-bottom:2px solid black;">
                        <h6 class="text-center"><b>SGST&nbsp;/&nbsp;UGST</b></h6>
                    </div>
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-6" style="border-right:2px solid black;">
                                <h6 class="text-center"><b>Rate</b></h6>

                            </div>
                            <div class="col-lg-6">
                                <h6 class="text-center"><b>Amount</b></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="width:14%; border-right:2px solid black; text-align: center;">
                <p>Amount</p>
            </div>
        </div>
        <!-- ======================= bill section ======================= -->
        <!-- SELECT `tax_invoice_details_id`, `description_goods`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE 1 -->
        
        <!-- =========== row 1 ============ -->
        <?php
        $i=0;
        $prod_name_1="";
        $hsn_sac_code_1="";
        $qty_1="";
        $rate_1="";
        $taxable_amt_1="";
        $cgst_rate_1="";
        $cgst_amt_1="";
        $sgst_rate_1="";
        $sgst_amt_1="";
        $total_amount_1="";
        $tax_invoice_id=$_REQUEST['tax_invoice_id'];
        $sql_001="SELECT `prod_name`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE `tax_invoice_id` = '$tax_invoice_id'";
        $result_001=mysqli_query($conn,$sql_001);
        
        while($row_001=mysqli_fetch_array($result_001)){
            $i++;
            $prod_name_1=$row_001['prod_name'];
            $hsn_sac_code_1=$row_001['hsn_sac_code'];
            $qty_1=$row_001['qty'];
            $rate_1=$row_001['rate'];
            $taxable_amt_1=$row_001['taxable_amt'];
            $cgst_rate_1=$row_001['cgst_rate'];
            $cgst_amt_1=$row_001['cgst_amt'];
            $sgst_rate_1=$row_001['sgst_rate'];
            $sgst_amt_1=$row_001['sgst_amt'];
            $total_amount_1=$row_001['total_amount'];


            $product_name_1="";
            $sql_p_n_1="SELECT `prod_name`, `hsn_sac_id` FROM `master_product` WHERE `prod_id` = '$prod_name_1'";
            $result_p_n_1=mysqli_query($conn,$sql_p_n_1);
            if($fetch_p_n_1=mysqli_fetch_array($result_p_n_1)){
                $product_name_1=$fetch_p_n_1['prod_name'];
            }
        ?>
        <div class="row" id="row1">
            <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                <p class="pt-3"><!--Sl No.-->
                    <input readonly class="" type="text" name="serial_number"  id=""  size="100%" placeholder="" value="<?php echo $i?>">
                </p>
            </div>
            <div class="" style="width:23%; border-right:2px solid black;">
                <p class="pt-3">
                    <input readonly type="text" class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" value="<?php echo $product_name_1?>">
                </p>
            </div>
            <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_product` WHERE 1 -->
            <div class="" style="width:10%; border-right:2px solid black;">
                <p class="pt-3"><!--HSN/SAC-->
                    <input readonly class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="" value="<?php echo $hsn_sac_code_1;?>">
                </p>
            </div>
            <div class="" style="width:5%; border-right:2px solid black;">
                <p class="pt-3"><!--Quantity-->
                    <input readonly class="quantity-input" type="text" name="qty5"  id="qty1"  size="100%" placeholder="" value="<?php echo $qty_1;?>" >
                </p>
            </div>
            <div class="" style="width:5%; border-right:2px solid black;">
                <p class="pt-3"><!--Rate-->
                    <input readonly class="rate" type="text" name="rate5"  id="rate"  size="100%" placeholder="" value="<?php echo $rate_1;?>">
                </p>
            </div>
            <div class="" style="width:5%; border-right:2px solid black;">
                <p class="pt-3"><!--per-->
                <input readonly class="" type="text" name="per"  id="per"  size="100%" placeholder="" value="<?php " ";?>">
                </p>
            </div>
            <div class="" style="width:5%; border-right:2px solid black;">
                <p class="pt-3"><!--taxable amount-->
                    <input readonly class="tax-amt-input" type="text" name="taxable_amt5"  id="taxable_amt"  size="100%" placeholder="" value="<?php echo $taxable_amt_1;?>">

                </p>
            </div>
            <div class="" style="width:15%; border-right:2px solid black;">
                <div style="display:flex;">
                    <div style="width:50%; height:100%;border-right:2px solid black;">
                        <p class="pt-3"><!--per-->
                            <input readonly class="gst_rate" type="text" name="cgst_rate5"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $cgst_rate_1;?>">
                        </p>
                    </div>
                    <div style="width:50%;height:100%;">
                        <p class="pt-3"><!--per-->
                            <input readonly class="cgst-amt-input" type="text" name="cgst_amt5"  id="cgst_amt"  size="100%" placeholder="" value="<?php echo $cgst_amt_1;?>">
                        </p>
                    </div>
                </div>
            </div>
            <div class="" style="width:15%; border-right:2px solid black;">
                <div style="display:flex;">
                    <div style="width:50%; height:100%;border-right:2px solid black;">
                        <p class="pt-3"><!--per-->
                            <input readonly class="gst_rate" type="text" name="sgst_rate5"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $sgst_rate_1;?>">
                        </p>
                    </div>
                    <div style="width:50%;height:100%;">
                        <p class="pt-3"><!--per-->
                            <input readonly class="sgst-amt-input" type="text" name="sgst_amt5"  id="sgst_amt"  size="100%" placeholder="" value="<?php echo $sgst_amt_1;?>">
                        </p>
                    </div>
                </div>
            </div>
            <div class="" style="width:14%; border-right:2px solid black;">
                <p class="pt-3"><!--per-->
                    <input readonly class="total-amt-input" type="text" name="total_amount5"  id="total_amount"  size="100%" placeholder="" value="<?php echo $total_amount_1;?>">
                </p>
            </div>
        </div>
        <?php
        }
        ?>
        
        <!-- ======================================================================== -->
        <!-- `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` -->
        <div class="row" style="border-bottom:2px solid black;">
            <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;"></div>
            <div class="text-right" style="width:23%; border-right:2px solid black;">
                <h5 class="pt-3"> <b>Total</b></h5>
            </div>
            <div class="" style="width:10%; border-right:2px solid black;"></div>

            <div class="" style="width:5%; border-right:2px solid black;">
                <h6 class="pt-3"> <b><input readonly class="grand-total-qty" type="text" name="grand_total_qty"  id="grand_total_qty"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $grand_total_qty;}?>"></b></h6>
            </div>
            <div class="" style="width:5%; border-right:2px solid black;"></div>
            <div class="" style="width:5%; border-right:2px solid black;"></div>

            <div class="" style="width:5%; border-right:2px solid black;">
            <h6 class="pt-3"> <b><input readonly class="grand-total-tax-amt" type="text" name="grand_total_taxable_amt"  id="grand_total_taxable_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $grand_total_taxable_amt;}?>"></b></h6></div>

            <div class="" style="width:15%; display:flex; border-right:2px solid black;">
                <div style="width:50%; height:100%; border-right:2px solid black;"></div>
                <div style="width:50%; height:100%;">
                    <h6 class="pt-3"> <b><input readonly class="grand-total-cgst-amt" type="text" name="grand_total_cgst_amt"  id="grand_total_cgst_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $grand_total_cgst_amt;}?>"></b></h6>
                </div>
            </div>
            <div class="" style="width:15%;display:flex; border-right:2px solid black;">
                <div style="width:50%; height:100%; border-right:2px solid black;"></div>
                <div style="width:50%; height:100%;">
                    <h6 class="pt-3"> <b><input readonly class="grand-total-sgst-amt" type="text" name="grand_total_sgst_amt"  id="grand_total_sgst_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $grand_total_sgst_amt;}?>"></b></h6>       
                </div>
            </div>
            <div class="text-right" style="width:14%; border-right:2px solid black;">
                <h5 class="pt-3"><b>
                    <input readonly class="grand-total-amt" type="text" name="grand_total_amt"  id="grand_total_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $grand_total_amt;}?>">
                </b></h5>
            </div>
        </div>
        <!-- ======================================================================== -->

        <!-- `amount_chargeable_word`, `tax_amount_word`, `remarks`,  -->
        <div class="row" style="border-bottom:2px solid black;">
            <div class="col-lg-12 pt-1" style="border-right:2px solid black;border-left:2px solid black;">
                <div class="row">
                    <div class="col-lg-6">
                        <p>Amount Chargeable (in words)</p>
                    </div>
                    <div class="col-lg-6">
                        <p class="text-right">E. & O.E</p>
                    </div>
                </div>
                <p> <input readonly class="" type="text" name="amount_chargeable_word"  id="amount_chargeable_word"  onfocus="convertNumberToWords()" size="150%" placeholder="" value="<?php if(isset($_REQUEST['view_data'])){echo $tax_amount_word;}?>"></p>
            </div>
        </div>

        <div class="row" style="border-bottom:2px solid black;">
            <div class="col-lg-4 pt-1" style="border-right:2px solid black;border-left:2px solid black;">
                <h6 class="text-center"><b>HSN/SAC</b></h6>
            </div>
            <div class="col-lg-1 pt-1" style="border-right:2px solid black;">
                <h6 class="text-center"><b>Taxable Value</b></h6>
            </div>
            <div class="col-lg-5" style="border-right:2px solid black;">

                <div class="row">
                    <div class="col-lg-6" style="border-right:2px solid black;">

                        <div class="row">
                            <div class="col-lg-12" style="border-bottom:2px solid black;">
                                <h6 class="text-center"><b>CGST</b></h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                        <h6 class="text-center"><b>Rate</b></h6>

                                    </div>
                                    <div class="col-lg-6">
                                        <h6 class="text-center"><b>Amount</b></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">

                        <div class="row">
                            <div class="col-lg-12" style="border-bottom:2px solid black;">
                                <h6 class="text-center"><b>SGST/UTGST</b></h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                        <h6 class="text-center"><b>Rate</b></h6>

                                    </div>
                                    <div class="col-lg-6">
                                        <h6 class="text-center"><b>Amount</b></h6>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                <h6 class="text-center"><b>Total Tax Amount</b></h6>
            </div>
        </div>

        <?php 
        $tax_invoice_id=$_REQUEST['tax_invoice_id'];
        $query_00="SELECT hsn_sac_code, cgst_rate, SUM(CAST(taxable_amt AS DECIMAL(10,2))) AS total_taxable_amt, SUM(CAST(cgst_amt AS DECIMAL(10,2))) AS total_cgst_amt, SUM(CAST(sgst_amt AS DECIMAL(10,2))) AS total_sgst_amt, SUM(CAST(total_amount AS DECIMAL(10,2))) AS total_invoice_amount FROM (SELECT tax_invoice_id, hsn_sac_code, cgst_rate, sgst_rate, taxable_amt, cgst_amt, sgst_amt, total_amount FROM tax_invoice_details WHERE tax_invoice_id = '$tax_invoice_id' AND hsn_sac_code IS NOT NULL AND hsn_sac_code != '') AS filtered_data GROUP BY hsn_sac_code, cgst_rate";


        $reult_00=mysqli_query($conn,$query_00);
        while($row_00=mysqli_fetch_array($reult_00)){
            $hsn_sac_code=$row_00['hsn_sac_code'];
            $cgst_rate=$row_00['cgst_rate'];
            $total_taxable_amt=$row_00['total_taxable_amt'];
            $total_cgst_amt=$row_00['total_cgst_amt'];
            $total_sgst_amt=$row_00['total_sgst_amt'];
            $total_invoice_amount=$row_00['total_invoice_amount'];
        
        ?>
        
        <div class="row" style="border-bottom:2px solid black;">
            <!-- hsn code  -->
            <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                <p><input readonly class="hsn_sac_code_output" type="text" name=""  id=""  size="100%" placeholder="" value="<?php echo $hsn_sac_code;?>"></p>
            </div>
            <!-- taxable amount -->
            <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                <p><input readonly class="" type="text" name=""  id=""  size="100%" placeholder="" value="<?php echo $total_taxable_amt;?>"></p>
            </div>
            <div class="col-lg-5 " style="border-right:2px solid black;">
                <div class="row">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <div class="row">
                            <div class="col-lg-6" style="border-right:2px solid black;">
                                <p class="pt-2"><input readonly class="" type="text" name=""  id=""  size="100%" placeholder=""  value="<?php echo $cgst_rate;?>"></p>
                            </div>
                            <div class="col-lg-6">
                                <p class="pt-2"><input readonly class="" type="text" name=""  id=""  size="100%" placeholder="" value="<?php echo $total_cgst_amt;?>"></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6" style="border-right:2px solid black;">
                                <p class="pt-2"><input readonly class="" type="text" name=""  id=""  size="100%" placeholder=""  value="<?php echo $cgst_rate;?>"></p>
                            </div>
                            <div class="col-lg-6">
                                <p class="pt-2"><input readonly class="" type="text" name=""  id=""  size="100%" placeholder=""  value="<?php echo $total_sgst_amt;?>"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                <p><input readonly class="" type="text" name=""  id=""  size="100%" placeholder=""  value="<?php echo $total_invoice_amount;?>"></p>
            </div>
        </div>
        <?php 
        }
        ?>


        <!-- $grand_total_qty
        $grand_total_taxable_amt
        $grand_total_cgst_amt
        $grand_total_sgst_amt
        $grand_total_amt -->
        <!-- new cell grand total   -->
        <div class="row" style="border-bottom:2px solid black;">
            <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                <h5 class="text-right"><b>Total</b></h5>
            </div>
            <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                <p><input readonly class="" type="text" name=""  id=""  size="100%" placeholder="" value="<?php echo $grand_total_taxable_amt?>"></p>
            </div>
            <div class="col-lg-5 " style="border-right:2px solid black;">
                <div class="row">
                    <div class="col-lg-6" style="border-right:2px solid black;">
                        <div class="row">
                            <div class="col-lg-6" style="border-right:2px solid black;">
                                <p class="pt-2"></p>
                            </div>
                            <div class="col-lg-6">
                                <p class="pt-2"><input readonly class="" type="text" name=""  id=""  size="100%" placeholder="" value="<?php echo $grand_total_cgst_amt?>"></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6" style="border-right:2px solid black;">
                                <p class="pt-2"></p>
                            </div>
                            <div class="col-lg-6">
                                <p class="pt-2"><input readonly class="" type="text" name=""  id=""  size="100%" placeholder="" value="<?php echo $grand_total_sgst_amt?>"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                <p><input readonly class="" type="text" name=""  id=""  size="100%" placeholder=""value="<?php echo $grand_total_amt?>"></p>
            </div>
        </div>
        <!-- `amount_chargeable_word`, `tax_amount_word`, `remarks` -->
        <div class="row pt-3" style="border-right:2px solid black;border-left:2px solid black;">
            <div class="col-lg-3">
                <h5>Tax Amount (in words) : </h5>
            </div>
            <div class="col-lg-9">
                <p><input readonly class="" type="text" name="tax_amount_word"  id="tax_amount_word"  size="100%" placeholder="INR Five Hundred Thirty and Six paise Only" value="<?php if(isset($_REQUEST['view_data'])){echo $tax_amount_word;}?>"></p>
            </div>
        </div>

        <div class="row pt-3" style="border-bottom:2px solid black;border-right:2px solid black;border-left:2px solid black;">
            <div class="col-lg-6">
                <h5><b> Remarks: </b></h5>

                <textarea readonly size="100" name="remarks"  id="remarks"  id="" cols="100" rows="3" ><?php if(isset($_REQUEST['view_data'])){echo $remarks;}?></textarea>

                <div class="row pt-3">
                    <div class="col-lg-6">
                        <h5>
                            Company's PAN
                        </h5>
                    </div>
                    <div class="col-lg-6">
                        <h5>
                            <b>: ADHPR3448R</b>
                        </h5>
                    </div>
                </div>

                <div class="row pt-2">
                    <div class="col-lg-12">
                        <h5 style="text-decoration:underline;">
                            <b> Declaration</b>
                        </h5>
                        <p>We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</p>
                    </div>
                </div>


            </div>
            <div class="col-lg-6">
                <h5><b>Company's Bank Details</b></h5>
                <div class="row">
                    <div class="col-lg-4">
                        <h5>A/c Holder's Name </h5>
                    </div>
                    <div class="col-lg-8">
                        <h5><b> : A.R.Enterprise</b></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <h5>Bank Name </h5>
                    </div>
                    <div class="col-lg-8">
                        <h5><b>: Punjab National Bank</b></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <h5>A/c No.</h5>
                    </div>
                    <div class="col-lg-8">
                        <h5><b> : 7870002100000553</b></h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <h5>Branch & IFS Code</h5>
                    </div>
                    <div class="col-lg-8">
                        <h5><b> : Baguiati & PUNB0787000</b></h5>
                    </div>
                </div>


                <div class="row pt-5" style="border-top:2px solid black;border-left:2px solid black;">
                    <div class="col-lg-4 pt-5">
                        <div>
                            <img src="invoice/prepared_by.png" alt="">
                        </div>
                        <div class="text-center">
                            <h6>Prepared By</h6>
                        </div>
                    </div>
                    <div class="col-lg-4 pt-5">
                        <div>
                            <img src="invoice/verified_by.png" alt="">
                        </div>
                        <div class="text-center">
                            <h6>Verified By </h6>
                        </div>
                    </div>
                    <div class="col-lg-4 pt-5">
                        <div>
                            <img src="invoice/authorised_signatory.png" alt="">
                        </div>
                        <div class="text-center">
                            <h6>Authorised Signatory</h6>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row p">
            <div class="col-lg-12">
                <h5 class="text-center pt-4"><b>SUBJECT TO KOLKATA JURISDICTION</b></h5>
                <h6 class="text-center pt-4">This is a Computer Generated Invoice</h6>
            </div>
        </div>
    </form>
</body>
</html>