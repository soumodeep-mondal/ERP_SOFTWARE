-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2024 at 03:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp_software`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_master`
--

CREATE TABLE `access_master` (
  `access_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `access_master`
--

INSERT INTO `access_master` (`access_id`, `emp_id`, `dept_id`) VALUES
(456, 26, 3),
(457, 26, 6),
(458, 26, 9),
(459, 26, 0),
(460, 26, 0),
(461, 26, 0),
(462, 26, 0),
(463, 26, 0),
(464, 26, 0),
(465, 26, 0),
(466, 26, 0),
(511, 27, 1),
(512, 27, 2),
(513, 27, 7),
(514, 27, 0),
(515, 27, 0),
(516, 27, 0),
(517, 27, 0),
(518, 27, 0),
(519, 27, 0),
(520, 27, 0),
(521, 27, 0),
(522, 31, 1),
(523, 31, 2),
(524, 31, 3),
(525, 31, 4),
(526, 31, 5),
(527, 31, 6),
(528, 31, 7),
(529, 31, 9),
(530, 31, 10),
(531, 31, 0),
(532, 31, 0),
(533, 25, 4),
(534, 25, 6),
(535, 25, 9),
(536, 25, 10),
(537, 25, 0),
(538, 25, 0),
(539, 25, 0),
(540, 25, 0),
(541, 25, 0),
(542, 25, 0),
(543, 25, 0),
(555, 32, 3),
(556, 32, 9),
(557, 32, 0),
(558, 32, 0),
(559, 32, 0),
(560, 32, 0),
(561, 32, 0),
(562, 32, 0),
(563, 32, 0),
(564, 32, 0),
(565, 32, 0),
(610, 17, 1),
(611, 17, 2),
(612, 17, 3),
(613, 17, 4),
(614, 17, 5),
(615, 17, 6),
(616, 17, 7),
(617, 17, 9),
(618, 17, 10),
(619, 17, 0),
(620, 17, 0),
(665, 30, 2),
(666, 30, 4),
(667, 30, 5),
(668, 30, 6),
(669, 30, 9),
(670, 30, 10),
(671, 30, 0),
(672, 30, 0),
(673, 30, 0),
(674, 30, 0),
(675, 30, 0),
(676, 29, 1),
(677, 29, 2),
(678, 29, 3),
(679, 29, 4),
(680, 29, 7),
(681, 29, 9),
(682, 29, 10),
(683, 29, 0),
(684, 29, 0),
(685, 29, 0),
(686, 29, 0),
(687, 24, 1),
(688, 24, 2),
(689, 24, 3),
(690, 24, 4),
(691, 24, 5),
(692, 24, 6),
(693, 24, 9),
(694, 24, 10),
(695, 24, 0),
(696, 24, 0),
(697, 24, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE `customer_master` (
  `customer_id` int(11) NOT NULL,
  `customer_company_name` varchar(100) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_mob` varchar(20) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_state_name` varchar(30) NOT NULL,
  `customer_state_code` varchar(20) NOT NULL,
  `customer_gst_in` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`customer_id`, `customer_company_name`, `customer_name`, `customer_mob`, `customer_address`, `customer_state_name`, `customer_state_code`, `customer_gst_in`) VALUES
(15, 'SKC INFOTECH', 'RUDRA SHING', '84545412148', 'Kolkata, Barasat', 'West Bengal', '124', 'GKMDDW2615D1221'),
(16, 'CSDS', 'sunil', '53654546545', 'kolkata', 'wb', '45247', 'vdxfdfrdsfg');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `designation_id` int(11) NOT NULL,
  `designation_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`designation_id`, `designation_name`) VALUES
(1, 'ADMIN'),
(2, 'OFFICE ASSISTENT'),
(3, 'SALESMAN'),
(5, 'PURCHASE'),
(6, 'PRODUCTION MGR'),
(8, 'TENDER EXECUTIVE'),
(9, 'ACCOUNTS');

-- --------------------------------------------------------

--
-- Table structure for table `purchased_item`
--

CREATE TABLE `purchased_item` (
  `purchased_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `invoice_date` varchar(20) NOT NULL,
  `invoice_amount` float NOT NULL,
  `cgst_amt` float NOT NULL,
  `sgst_amt` float NOT NULL,
  `igst_amt` float NOT NULL,
  `entry_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchased_item`
--

INSERT INTO `purchased_item` (`purchased_id`, `vendor_id`, `invoice_no`, `invoice_date`, `invoice_amount`, `cgst_amt`, `sgst_amt`, `igst_amt`, `entry_date`) VALUES
(13, 4, '003', '2024-07-01', 100.5, 40, 620, 1500, '2024-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `purchased_item_details`
--

CREATE TABLE `purchased_item_details` (
  `purchased_item_details_id` int(11) NOT NULL,
  `purchased_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `raw_material_quantity` float NOT NULL,
  `raw_matarial_rate` float NOT NULL,
  `raw_matarial_amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchased_item_details`
--

INSERT INTO `purchased_item_details` (`purchased_item_details_id`, `purchased_id`, `raw_material_id`, `raw_material_quantity`, `raw_matarial_rate`, `raw_matarial_amount`) VALUES
(56, 13, 5, 200, 20.5, 4100),
(57, 13, 2, 200.22, 10, 2002.2),
(58, 13, 6, 150.22, 28.36, 4260.24);

-- --------------------------------------------------------

--
-- Table structure for table `raw_material_master`
--

CREATE TABLE `raw_material_master` (
  `raw_material_id` int(11) NOT NULL,
  `raw_material_unit_id` int(11) NOT NULL,
  `raw_material_name` varchar(100) NOT NULL,
  `raw_material_desc` text NOT NULL,
  `raw_material_quantity` float NOT NULL,
  `reorder_qty` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `raw_material_master`
--

INSERT INTO `raw_material_master` (`raw_material_id`, `raw_material_unit_id`, `raw_material_name`, `raw_material_desc`, `raw_material_quantity`, `reorder_qty`) VALUES
(2, 1, 'TEA', 'GREEN TEA', 2201.76, 500),
(5, 1, 'RICE', 'Bastoti Rice', 2410, 50),
(6, 3, 'ATTA', 'chakki atta', 1951.76, 10);

-- --------------------------------------------------------

--
-- Table structure for table `raw_material_unit_master`
--

CREATE TABLE `raw_material_unit_master` (
  `raw_material_unit_id` int(11) NOT NULL,
  `raw_material_unit_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `raw_material_unit_master`
--

INSERT INTO `raw_material_unit_master` (`raw_material_unit_id`, `raw_material_unit_name`) VALUES
(1, 'KG'),
(3, 'Gram'),
(4, 'cm'),
(5, 'PCS'),
(6, 'MTR'),
(7, 'MM');

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE `user_master` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_ref` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`id`, `user_id`, `password`, `user_ref`) VALUES
(1, 'admin', 'admin', 1),
(29, 'jon', '123', 12),
(33, 'ramkumar', '123', 15),
(34, 'ram', '123', 17),
(35, 'sunitbabu', '123', 16),
(36, 'liza', '123', 13),
(37, 'nopita', '123', 22);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_master`
--

CREATE TABLE `vendor_master` (
  `vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `vendor_person_name` varchar(50) NOT NULL,
  `vendor_address` text NOT NULL,
  `vendor_contact_no` varchar(50) NOT NULL,
  `vendor_state` varchar(50) NOT NULL,
  `vendor_state_code` varchar(50) NOT NULL,
  `vendor_gst` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendor_master`
--

INSERT INTO `vendor_master` (`vendor_id`, `vendor_name`, `vendor_person_name`, `vendor_address`, `vendor_contact_no`, `vendor_state`, `vendor_state_code`, `vendor_gst`) VALUES
(4, 'UNO SERVICE', 'AJOY', 'Cement Supplyer', '5464564564', 'WESTBENGAL', '154', 'NYJG2KUK'),
(5, 'SKC INFOTECH', 'soumo', 'Barasat', '7575541787', 'WESTBENGAL', '154', 'NYJG2KUK'),
(6, 'WEB SERVICE', 'AJOY', 'NIL', '5464564564', 'WESTBENGAL', '154', '27AATFT6114H1ZT'),
(10, 'pioneer', 'sandip', 'Barasat', '7575541787', 'WB', '124', 'NYJG2KUK'),
(11, 'Ratan Co', 'Ratan Das', 'kolkata', '7575541787', 'wb', '124', 'NYJG2KUK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_master`
--
ALTER TABLE `access_master`
  ADD PRIMARY KEY (`access_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `customer_master`
--
ALTER TABLE `customer_master`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`designation_id`);

--
-- Indexes for table `purchased_item`
--
ALTER TABLE `purchased_item`
  ADD PRIMARY KEY (`purchased_id`);

--
-- Indexes for table `purchased_item_details`
--
ALTER TABLE `purchased_item_details`
  ADD PRIMARY KEY (`purchased_item_details_id`);

--
-- Indexes for table `raw_material_master`
--
ALTER TABLE `raw_material_master`
  ADD PRIMARY KEY (`raw_material_id`),
  ADD UNIQUE KEY `raw_material_name` (`raw_material_name`);

--
-- Indexes for table `raw_material_unit_master`
--
ALTER TABLE `raw_material_unit_master`
  ADD PRIMARY KEY (`raw_material_unit_id`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `vendor_master`
--
ALTER TABLE `vendor_master`
  ADD PRIMARY KEY (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_master`
--
ALTER TABLE `access_master`
  MODIFY `access_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=698;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_master`
--
ALTER TABLE `customer_master`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `designation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `purchased_item`
--
ALTER TABLE `purchased_item`
  MODIFY `purchased_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `purchased_item_details`
--
ALTER TABLE `purchased_item_details`
  MODIFY `purchased_item_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `raw_material_master`
--
ALTER TABLE `raw_material_master`
  MODIFY `raw_material_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `raw_material_unit_master`
--
ALTER TABLE `raw_material_unit_master`
  MODIFY `raw_material_unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_master`
--
ALTER TABLE `user_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `vendor_master`
--
ALTER TABLE `vendor_master`
  MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
