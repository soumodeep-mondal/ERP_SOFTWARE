<?php
include('db/conn.php');
include('db/sequre_page.php');

// Delete operation
if (isset($_POST['delete'])) {
    $raw_material_id_to_delete = $_POST['raw_material_id'];
    $sql_delete = "DELETE FROM `master_raw_material` WHERE `raw_material_id` = $raw_material_id_to_delete";

    if (mysqli_query($conn, $sql_delete)) {
        $msg = "succ=Record deleted successfully";
    } else {
        $msg = "err=Error deleting record: " . mysqli_error($conn);
    }
    header("location:master_raw_material.php?" . $msg);
}

// Insert operation
if (isset($_POST['submit'])) {
    $raw_material_name = $_POST['raw_material_name'];
    $raw_material_unit_id = $_POST['raw_material_unit_id'];
    $raw_material_desc = $_POST['raw_material_desc'];
    $raw_material_quantity = $_POST['raw_material_quantity'];
    $reorder_qty = $_POST['reorder_qty'];

    // Check if raw_material_name is unique
    $check_sql = "SELECT * FROM `master_raw_material` WHERE `raw_material_name` = '$raw_material_name'";
    $check_query = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_query) > 0) {
        // raw_material_name already exists
        $msg = "err=Raw material name already exists.";
    } else {
        // Insert query
        $sql = "INSERT INTO `master_raw_material` (`raw_material_name`, `raw_material_unit_id`, `raw_material_desc`, `raw_material_quantity`, `reorder_qty`) 
                VALUES ('$raw_material_name', '$raw_material_unit_id', '$raw_material_desc', '$raw_material_quantity', '$reorder_qty')";

        if (mysqli_query($conn, $sql)) {
            $msg = "succ=New raw material record created successfully";
        } else {
            $msg = "err=Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
    header("location:master_raw_material.php?" . $msg);
}

// Update operation
if (isset($_POST['update'])) {
    $raw_material_id = $_POST['raw_material_id'];
    $raw_material_name = $_POST['raw_material_name'];
    $raw_material_unit_id = $_POST['raw_material_unit_id'];
    $raw_material_desc = $_POST['raw_material_desc'];
    $raw_material_quantity = $_POST['raw_material_quantity'];
    $reorder_qty = $_POST['reorder_qty'];

    // Check if raw_material_name is unique (excluding the current record)
    $check_sql = "SELECT * FROM `master_raw_material` WHERE `raw_material_name` = '$raw_material_name' AND `raw_material_id` != $raw_material_id";
    $check_query = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_query) > 0) {
        // raw_material_name already exists
        $msg = "err=Raw material name already exists.";
    } else {
        // Update query
        $sql = "UPDATE `master_raw_material` SET 
                `raw_material_name` = '$raw_material_name',
                `raw_material_unit_id` = '$raw_material_unit_id',
                `raw_material_desc` = '$raw_material_desc',
                `raw_material_quantity` = '$raw_material_quantity',
                `reorder_qty` = '$reorder_qty'
                WHERE `raw_material_id` = $raw_material_id";

        if (mysqli_query($conn, $sql)) {
            $msg = "succ=Raw material record updated successfully";
        } else {
            $msg = "err=Error updating record: " . mysqli_error($conn);
        }
    }
    header("location:master_raw_material.php?" . $msg);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raw Material Master</title>
    <?php include('includes/dashboard_link_css.php');?>
    <script>
        /* Useful default functions */
        // DeleteRecheck
        // convert_data_to_upper
        // check_numeric
        // check_decimal
    </script>
</head>

<?php
if (isset($_REQUEST['xedit'])) {
    $raw_material_id = $_REQUEST['raw_material_id'];
    $qre = mysqli_query($conn, "SELECT * FROM `master_raw_material` WHERE `raw_material_id` = '$raw_material_id'");
    if ($fetch = mysqli_fetch_array($qre)) {
        // Fetching fields from `master_raw_material`
        $raw_material_id = $fetch['raw_material_id'];
        $raw_material_name = $fetch['raw_material_name'];
        $raw_material_unit_id = $fetch['raw_material_unit_id'];
        $raw_material_desc = $fetch['raw_material_desc'];
        $raw_material_quantity = $fetch['raw_material_quantity'];
        $reorder_qty = $fetch['reorder_qty'];
    }
}
?>


<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER -->
        <?php include('includes/dashboard_header.php');?>
        <!-- END HEADER -->
        <div class="content-wrapper">

            <!-- START PAGE CONTENT -->
                <div class="row pt-2 text-center dashboard-header-color">
                    <div class="col-lg-12">
                        <h4 class="dashboard-page-heading">Raw Material Master</h4>
                    </div>
                </div>

                <!-- Insert and Update Form -->
                <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="ibox">
                                <div class="ibox-head">
                                    <div class="ibox-title">Raw Material Details</div>
                                    <div class="ibox-tools">
                                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                    </div>
                                </div>
                                <div class="ibox-body">
                                    <!-- Display Messages -->
                                    <?php include('includes/display_massage.php'); ?>

                                    <form action="" method="post" enctype="multipart/form-data">
                                        <input type="hidden" id="raw_material_id" name="raw_material_id" readonly="readonly" value="<?php if(isset($_REQUEST['xedit'])) { echo $raw_material_id; } ?>" />

                                        <div class="row">
                                            <div class="col-sm-3 form-group">
                                                <label>Raw Material Name <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="raw_material_name" id="raw_material_name" placeholder="Enter raw material name" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($raw_material_name); } ?>" onkeyup="convert_data_to_upper(this);"  required>
                                            </div>

                                            

                                            <div class="col-sm-3 form-group">
                                                <label>Description <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="raw_material_desc" id="raw_material_desc" placeholder="Enter description" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($raw_material_desc); } ?>" required>
                                            </div>

                                            <div class="col-sm-2 form-group">
                                                <label>Quantity <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="raw_material_quantity" id="raw_material_quantity" placeholder="Enter quantity" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($raw_material_quantity); } ?>" required>
                                            </div>
                                               <div class="col-sm-2 form-group">
                                                <label>Reorder Quantity <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="reorder_qty" id="reorder_qty" placeholder="Enter reorder quantity" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($reorder_qty); } ?>" required>
                                            </div>
                                            <div class="col-sm-2 form-group">
                                                <label>Unit <span class="text-danger">*</span></label>
                                                <select class="form-control" name="raw_material_unit_id" id="raw_material_unit_id" required>
                                                    <option value="">Select Unit</option>
                                                  

                                                    <?php
                                                    $sql_unit = "SELECT * FROM master_raw_material_unit ORDER BY raw_material_unit_name ";
                                                    $result_unit = mysqli_query($conn, $sql_unit);
                                                    while($row_unit = mysqli_fetch_array($result_unit)) 
                                                    {?>
                                                         <option value="<?php echo $row_unit['raw_material_unit_id']; ?>"<?php if(isset($_REQUEST['xedit'])) { if($row_unit['raw_material_unit_id']==$raw_material_unit_id){ echo "selected"; } }?>><?php echo $row_unit['raw_material_unit_name']; ?></option>
                                                            
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                         

                                            <div class="col-sm-3 form-group mt-4 pt-2">
                                                <?php if(isset($_REQUEST['xedit'])) { ?>
                                                    <button class="btn btn-warning" type="submit" name="update">Update</button>
                                                <?php } else { ?>
                                                    <button class="btn btn-success" type="submit" name="submit">Submit</button>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Insert and Update Form -->

                <!-- Display Table -->
                <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox">
                                <div class="ibox-head">
                                    <div class="ibox-title">Raw Materials List</div>
                                    <div class="ibox-tools">
                                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                    </div>
                                </div>
                                <div class="ibox-body">
                                <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Raw Material Name</th>
                                                <th>Description</th>
                                                <th>Quantity</th>
                                                <th>Reorder Quantity</th>
                                                <th>Unit</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                // Fetching data from master_raw_material table
                                                $sql1 = "SELECT * FROM `master_raw_material` order by raw_material_name";
                                                $query1 = mysqli_query($conn, $sql1);
                                                
                                                while ($prd = mysqli_fetch_array($query1)) 
                                                {
                                                    $raw_material_id = $prd['raw_material_id'];
                                                    
                                                    $raw_material_unit_id = $prd['raw_material_unit_id'];
                                                    $sql_unit = mysqli_query($conn,"SELECT `raw_material_unit_name` FROM `master_raw_material_unit` WHERE `raw_material_unit_id` = '$raw_material_unit_id'");
                                                 
                                                    if ($unit = mysqli_fetch_array($sql_unit)) {


                                            ?>
                                                <tr>
                                                    <td><b><?php echo htmlspecialchars($prd['raw_material_name']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($prd['raw_material_desc']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($prd['raw_material_quantity']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($prd['reorder_qty']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($unit['raw_material_unit_name']); ?></b></td>
                                                    <td class="d-flex">
                                                        
                                                        
                                                          <?php
                                                            $sql1 = mysqli_query($conn,"SELECT * FROM `purchased_item_details` WHERE raw_material_id='$raw_material_id' ");
                                                            $count = mysqli_num_rows($sql1);
                                                            if ($count == 0) {
                                                          
                                                          ?>
                                                        <a href="master_raw_material.php?xedit=1&raw_material_id=<?php echo $prd['raw_material_id']; ?>">
                                                            <i class="fa fa-pencil-square" aria-hidden="true" style="font-size:25px;"></i>
                                                        </a>
                                                        <form method="post" action="" enctype="multipart/form-data" onsubmit="return myFunction();">
                                                            <input type="hidden" name="raw_material_id" value="<?php echo $prd['raw_material_id']; ?>" />
                                                            <button style="border:none; color:#007bff" type="submit" name="delete">
                                                                <i class="fa fa-trash" aria-hidden="true" style="font-size:25px;"></i>
                                                            </button>
                                                        </form>
                                                        <?php
                                                        }
                                                        ?>


                                                    </td>
                                                </tr>
                                            <?php
                                                    }
                                                }
                                            ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Display Table -->


            <!-- END PAGE CONTENT -->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL -->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL -->

    <!-- CORE PLUGINS -->
    <?php include('includes/dashboard_link_script.php');?>
</body>
</html>
