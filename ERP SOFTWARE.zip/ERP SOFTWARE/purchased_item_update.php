<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>
<?php
//globel Variable
$cgst_amt = 0;
$sgst_amt = 0;
$igst_amt = 0;
//globel Variable


if (isset($_REQUEST['purchased_id'])) {
    $purchased_id = $_REQUEST['purchased_id'];
    $qre = mysqli_query($conn, "SELECT `purchased_id`, `vendor_id`, `invoice_no`, `invoice_date`, `invoice_amount`, `cgst_amt`, `sgst_amt`, `igst_amt`, `entry_date` FROM `purchased_item` WHERE `purchased_id` = '$purchased_id'");
    if ($fetch = mysqli_fetch_array($qre)) {
        // Fetching fields from `purchased_item`
        $purchased_id = $fetch['purchased_id'];
        $vendor_id = $fetch['vendor_id'];
        $invoice_no = $fetch['invoice_no'];
        $invoice_date = $fetch['invoice_date'];
        $invoice_amount = $fetch['invoice_amount'];
        $cgst_amt = $fetch['cgst_amt'];
        $sgst_amt = $fetch['sgst_amt'];
        $igst_amt = $fetch['igst_amt'];
        $entry_date = $fetch['entry_date'];
    }
}











// Insert operation
if (isset($_POST['update'])) {
    $purchased_id = $_POST['purchased_id'];
    $vendor_id = $_POST['vendor_id'];
    $invoice_no = $_POST['invoice_no'];
    $invoice_date = $_POST['invoice_date'];
    $invoice_amount = $_POST['invoice_amount'];

    if($_POST['cgst_amt']!='')
    {
        $cgst_amt = $_POST['cgst_amt'];
    }
    if($_POST['sgst_amt']!='')
    {
        $sgst_amt = $_POST['sgst_amt'];
    }
    if($_POST['igst_amt']!='')
    {
        $igst_amt = $_POST['igst_amt'];
    }

    // Insert query
    $sql = mysqli_query($conn, " UPDATE `purchased_item` SET `vendor_id` = '$vendor_id', `invoice_no` = '$invoice_no', `invoice_date` = '$invoice_date', `invoice_amount` = '$invoice_amount', `cgst_amt` = '$cgst_amt', `sgst_amt` = '$sgst_amt', `igst_amt` = '$igst_amt' WHERE `purchased_id` = '$purchased_id'");

    if($sql){

       
       //delete query
       $sql2 = mysqli_query($conn,"DELETE FROM `purchased_item_details` WHERE `purchased_id` = '$purchased_id'");
       
        //SELECT `purchased_item_details_id`, `purchased_id`, `raw_material_id`, `raw_material_quantity`, `raw_matarial_rate`, `raw_matarial_amount` FROM `purchased_item_details` WHERE 1

        $i=0;
        $raw_material_id=null;
        while(isset($_POST['raw_material_id'][$i]))
         {
            $raw_material_id=trim($_POST['raw_material_id'][$i]);
            $raw_material_quantity=trim($_POST['raw_material_quantity'][$i]);
            $raw_matarial_rate=trim($_POST['raw_matarial_rate'][$i]);
            $raw_matarial_amount=trim($_POST['raw_matarial_amount'][$i]);

            $sql2 = mysqli_query($conn,"INSERT INTO `purchased_item_details` (`purchased_id`, `raw_material_id`, `raw_material_quantity`, `raw_matarial_rate`, `raw_matarial_amount`) VALUES ('$purchased_id', '$raw_material_id', '$raw_material_quantity', '$raw_matarial_rate', '$raw_matarial_amount')");


            $update_stock=mysqli_query($conn,"UPDATE `master_raw_material` SET raw_material_quantity=raw_material_quantity+'$raw_material_quantity' WHERE raw_material_id='$raw_material_id' ");

        $i++;
        }

        if($sql2){
            $msg = "succ=purchase record updated successfully";
        }
        else
        {
            $msg = "err=Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } 
    else {
        $msg = "err=Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    if (isset($_REQUEST['page_redirect']) && $_REQUEST['page_redirect']=='report') {
        
        $url_from_date=$_REQUEST['from_date'];
        $url_to_date=$_REQUEST['to_date'];
        $url_invoice_no=$_REQUEST['invoice_no'];
        $url_vendor_id=$_REQUEST['vendor_id'];  
        header("location:purchased_item_report.php?from_date=".$url_from_date."&to_date=".$url_to_date."&invoice_no=".$url_invoice_no."&vendor_id=".$url_vendor_id."&". $msg);     
    }
    else
    {
       header("location:purchased_item.php?" . $msg);     
    }


}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>PURCHASED ITEM UPDATE</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
 



<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Purchased Item UPDATE</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      
            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Upload Details</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->
                            <form action="" method="post">
                                <input type="hidden" name="purchased_id" value="<?= $purchased_id; ?>" >
                                 
                   
                                <div class="row">                                    
                                    <div class="col-lg-2 form-group">
                                        <label>Invoice Date <span style="color:red;">*</span></label>
                                        <div>
                                            <input class="form-control" type="date" name="invoice_date" id="invoice_date" value="<?php echo $invoice_date;?>" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 form-group">
                                        <label>Invoice No <span style="color:red;">*</span></label>
                                        <div>
                                            <input class="form-control" type="text" name="invoice_no" id="invoice_no" value="<?php echo $invoice_no;?>" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 form-group">
                                        <label>Vendor <span class="text-danger">*</span></label>
                                        <select class="form-control" name="vendor_id" id="vendor_id" required onchange="choose_vendor(this);">
                                            <option value="" selected disabled="none">Choose Name</option>
                                            <?php
                                            $sql_ctgy = "SELECT * FROM `master_vendor` WHERE 1";
                                            $query_ctgy = mysqli_query($conn, $sql_ctgy);
                                            while ($ctgy = mysqli_fetch_array($query_ctgy)) { ?>
                                                <option value="<?php echo $ctgy['vendor_id']; ?>" <?php   if($ctgy['vendor_id']==$vendor_id){ echo 'selected'; } ?> ><?php echo $ctgy['vendor_name']; ?></option>
                                            <?php } ?>
                                        </select>

                                    </div>
                                    <div class="col-lg-2 mt-4 pt-2 form-group">
                                        <button class="btn btn-success" type="button" name="add_vendor" id="add_vendor_container" style="display: none;">Add</button>
                                    </div>
                                    

                                    <!-- SELECT `vendor_id`, `vendor_name`, `vendor_person_name`, `vendor_address`, `vendor_contact_no`, `vendor_state`, `vendor_state_code`, `vendor_gst` FROM `master_vendor` WHERE 1 -->

                                    <div class="col-lg-12">
                                        <?php
                                         $sql_ctgy2 = "SELECT * FROM `master_vendor` WHERE 1";
                                         $query_ctgy2 = mysqli_query($conn, $sql_ctgy2);
                                         if ($ctgy2 = mysqli_fetch_array($query_ctgy2)) 
                                         { 
                                            $display_vendor_person_name=$ctgy2['vendor_person_name'];
                                            $display_vendor_contact_no=$ctgy2['vendor_contact_no'];
                                            $display_vendor_gst=$ctgy2['vendor_gst'];
                                            $display_vendor_address=$ctgy2['vendor_address'];
                                      
                                            

                                         }
                                         ?>

                                        <div class="row">
                                            <div class="col-lg-2 form-group">
                                                <label>Person Name </label>
                                                <div>
                                                    <input class="form-control" type="text" id="display_vendor_person_name" value="<?php echo  $display_vendor_person_name;?>" readonly>

                                                </div>
                                            </div>
                                            <div class="col-lg-2 form-group">
                                                <label>Contact No</label>
                                                <div>
                                                    <input class="form-control" type="text" id="display_vendor_contact_no" value="<?php echo  $display_vendor_contact_no;?>" readonly>
                                                </div>
                                            </div>

                                            <div class="col-lg-2 form-group">
                                                <label>GST</label>
                                                <div>
                                                    <input class="form-control" type="text" id="display_vendor_gst" value="<?php echo  $display_vendor_gst;?>" readonly>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 form-group">
                                                <label>Address</label>
                                                <div>
                                                    <input class="form-control" type="text" id="display_vendor_address" value="<?php echo  $display_vendor_address;?>" readonly>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                          
        
 
 
                                    <div class="col-lg-2 form-group">
                                        <label>CGST Amount <span style="color:red;">*</span></label>
                                        <div>
                                            <input class="form-control" type="number" step="0.01" name="cgst_amt" id="cgst_amt" value="<?php echo $cgst_amt;?>" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 form-group">
                                        <label>SGST Amount <span style="color:red;">*</span></label>
                                        <div>
                                            <input class="form-control" type="number" step="0.01" name="sgst_amt" id="sgst_amt" value="<?php echo $sgst_amt;?>" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 form-group">
                                        <label>IGST Amount <span style="color:red;">*</span></label>
                                        <div>
                                            <input class="form-control" type="number" step="0.01" name="igst_amt" id="igst_amt" value="<?php echo $igst_amt;?>" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 form-group">
                                        <label>Invoice Amount <span style="color:red;">*</span></label>
                                        <div>
                                            <input class="form-control" type="number" step="0.01" name="invoice_amount" id="invoice_amount" value="<?php echo $invoice_amount;?>" required>
                                        </div>
                                    </div>
                                 
                                    

                                    <div class="col-sm-2 form-group mt-4 pt-2">
                                        <button class="btn btn-warning" type="submit" name="update">Update</button>
                                    </div>
                                    


                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-2">
                                                <label><b> Raw Material </b> <span class="text-danger">*</span> </label>
                                            </div>
                                            <div class="col-2">
                                                <label><b> Unit</b> <span class="text-danger">*</span> </label>
                                            </div>
                                            <div class="col-2">
                                                <label><b> Quantity</b> <span class="text-danger">*</span> </label>
                                            </div>
                                            
                                            <div class="col-2">
                                                <label><b> Rate</b> <span class="text-danger">*</span> </label>
                                            </div>
                                            <div class="col-2">
                                                <label><b> Amount</b> <span class="text-danger">*</span> </label>
                                            </div>
                                        </div>
                                    </div>




                                    <div class="col-lg-12" id="add_item_table">
                                        <?php
                                        //SELECT `purchased_item_details_id`, `purchased_id`, `raw_material_id`, `raw_material_quantity`, `raw_matarial_rate`, `raw_matarial_amount` FROM `purchased_item_details` WHERE 1
                                        $purchased_item_details= mysqli_query($conn, "SELECT * FROM purchased_item_details where purchased_id='$purchased_id'");
                                        $i=0;
                                        while ($fetch_items_details = mysqli_fetch_array($purchased_item_details)) 
                                        {
                                            $raw_material_id=$fetch_items_details['raw_material_id'];
                                            $raw_material_quantity=$fetch_items_details['raw_material_quantity'];
                                            $raw_matarial_rate=$fetch_items_details['raw_matarial_rate'];
                                            $raw_matarial_amount=$fetch_items_details['raw_matarial_amount'];

                                            $qre = mysqli_query($conn, "SELECT rm.raw_material_id, rm.raw_material_unit_id, ru.raw_material_unit_name FROM  master_raw_material rm JOIN  master_raw_material_unit ru  ON  rm.raw_material_unit_id = ru.raw_material_unit_id WHERE  rm.raw_material_id = '$raw_material_id'");
                                            if ($fetch = mysqli_fetch_array($qre)) 
                                            {
                                                $raw_material_unit_name = $fetch['raw_material_unit_name'];
                                            }
                                        ?>


                                        <div class="row mt-3">
                                            <div class="col-2">
                                                <select class="form-control raw_material_id select2" name="raw_material_id[]" id="raw_material_id" required onchange="fetchUnitName(this)">
                                                    <option value="" selected disabled="none">Choose Item</option>
                                                    <?php
                                                    $sql = mysqli_query($conn,"SELECT * FROM master_raw_material ORDER BY raw_material_name ASC");
                                                    while ($fetch1 = mysqli_fetch_array($sql)) { ?>
                                                        <option value="<?php echo $fetch1['raw_material_id']; ?>"  <?php if($fetch1['raw_material_id']==$raw_material_id){ echo "selected";} ?>><?php echo $fetch1['raw_material_name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <input type="text"  class="form-control raw_material_unit_name" id="raw_material_unit_name" value='<?php echo $raw_material_unit_name; ?>' readonly>
                                            </div>
                                            <div class="col-2">
                                                <input type="text" class="form-control raw_matarial_quantity"  name="raw_material_quantity[]" value="<?php echo  $raw_material_quantity; ?>" onkeyup="calculateAmount(this); check_decimal(this);" required>
                                            </div>
                                            
                                            <div class="col-2">
                                                <input type="text" class="form-control raw_matarial_rate"  name="raw_matarial_rate[]" value="<?php echo  $raw_matarial_rate; ?>"  onkeyup="calculateAmount(this); check_decimal(this);" required>
                                            </div>
                                            <div class="col-2">
                                                <input type="text" class="form-control raw_matarial_amount"  name="raw_matarial_amount[]" value="<?php echo  $raw_matarial_amount; ?>"  onkeyup="check_decimal(this);" required>
                                            </div>
                                            <div class="col-2">

                                            <?php
                                            if($i==0)
                                            {?>
                                                <button type="button" id="add_item_btn"  class="btn btn-primary add_item_btn" style="font-size: 14px;"> <i class="fa fa-plus"></i> </button>
                                            <?php
                                            }
                                            else
                                            {
                                            ?>   
                                                <button type="button" id="remove_item_btn"  class="btn btn-danger remove_item_btn" style="font-size: 14px;"> <i class="fa fa-minus"></i></button>
                                            <?php
                                            }
                                            ?>


                                                
                                            </div>
                                        </div>

                                        <?php
                                        $i++;
                                        }
                                        ?>

                                    </div>







                            </div>

                            </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
 
 



            <!-- Bootstrap Modal -->
            <div class="modal fade" id="addVendorModal" tabindex="-1" role="dialog" aria-labelledby="addVendorModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addVendorModalLabel">Add Vendor</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <!-- Add your form fields here -->
                            <form id="addVendorForm">
                                    
                                <div class="row">
                                    <div class="col-6 form-group">
                                        <label for="vendor_name">Vendor Name</label>
                                        <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
                                    </div>
                                    <div class="col-6 form-group">
                                        <label for="vendor_person_name">Vendor Person Name</label>
                                        <input type="text" class="form-control" id="vendor_person_name" name="vendor_person_name" required>
                                    </div>
                                    <div class="col-6 form-group">
                                        <label for="vendor_address">Vendor Address</label>
                                        <textarea class="form-control" id="vendor_address" name="vendor_address" rows="1" required></textarea>
                                    </div>
                                    <div class="col-6 form-group">
                                        <label for="vendor_contact_no">Vendor Contact No</label>
                                        <input type="text" class="form-control" id="vendor_contact_no" name="vendor_contact_no" required>
                                    </div>
                                    <div class="col-4 form-group">
                                        <label for="vendor_state">Vendor State</label>
                                        <input type="text" class="form-control" id="vendor_state" name="vendor_state" placeholder="Enter N/A if not applicable" required>
                                    </div>
                                    <div class="col-4 form-group">
                                        <label for="vendor_state_code">Vendor State Code</label>
                                        <input type="text" class="form-control" id="vendor_state_code" name="vendor_state_code" placeholder="Enter N/A if not applicable" required>
                                    </div>
                                    <div class="col-4 form-group">
                                        <label for="vendor_gst">Vendor GST</label>
                                        <input type="text" class="form-control" id="vendor_gst" name="vendor_gst" placeholder="Enter N/A if not applicable" required>
                                    </div>
                                    <div class="col-4 form-group">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </div>       
                            </form>
                        </div>
                    </div>
                </div>
            </div>








                                    

            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
    
    <script>
        $('.raw_material_id').select2();  
        $('#vendor_id').select2();

    
        $(document).ready(function(){

            /* ----------------------------------------------------------------- */
            var html = '<div class="row mt-3"> <div class="col-2"> <select class="form-control raw_material_id select2" name="raw_material_id[]" required onchange="fetchUnitName(this)"> <option value="" selected disabled="none">Choose Item</option> <?php $sql = mysqli_query($conn,"SELECT * FROM master_raw_material ORDER BY raw_material_name ASC"); while ($fetch1 = mysqli_fetch_array($sql)) { ?> <option value="<?php echo $fetch1['raw_material_id']; ?>"><?php echo $fetch1['raw_material_name']; ?></option> <?php } ?> </select> </div> <div class="col-2"> <input type="text"  class="form-control raw_material_unit_name" id="raw_material_unit_name" readonly> </div> <div class="col-2"> <input type="text" class="form-control raw_matarial_quantity"  name="raw_material_quantity[]" onkeyup="calculateAmount(this); check_decimal(this);" required> </div>  <div class="col-2"> <input type="text" class="form-control raw_matarial_rate"  name="raw_matarial_rate[]"  onkeyup="calculateAmount(this); check_decimal(this);" required> </div> <div class="col-2"> <input type="text" class="form-control raw_matarial_amount"  name="raw_matarial_amount[]" onkeyup="check_decimal(this);" required> </div> <div class="col-2"> <button type="button" id="remove_item_btn"  class="btn btn-danger remove_item_btn" style="font-size: 14px;"> <i class="fa fa-minus"></i>  </button> </div> </div>'; 

            $("#add_item_btn").click(function(){
                $("#add_item_table").append(html);
                $('.raw_material_id').select2();  
            
            });

            $("#add_item_table").on('click', '.remove_item_btn', function(){
                $(this).closest('.row').remove();
                // Additional logic if needed
            });
            /* ----------------------------------------------------------------- */
    


            // Handle the case when no results are found
            $('#vendor_id').on('select2:open', function(e) {
                var select2Search = $('.select2-search__field');
                select2Search.on('input', function() {
                    var results = $('.select2-results__option').filter(function() {
                        return $(this).text() === 'No results found';
                    });
                    if (results.length > 0) {
                        $('#add_vendor_container').show();
                    } else {
                        $('#add_vendor_container').hide();
                    }
                });
            });



            $('#add_vendor_container').on('click', function() {
                $('#addVendorModal').modal('show');
            });




            $('#addVendorForm').on('submit', function(e) {
                e.preventDefault();
                
                var formData = $(this).serialize();

                $.ajax({
                    type: 'POST',
                    url: 'add_vendor.php', // Change this URL to your actual PHP script
                    data: formData,
                    success: function(response) {
                        // Assuming your PHP script returns the new vendor as a JSON object
                        var newVendor = JSON.parse(response);

                        // Add new vendor to the select2 dropdown
                        var newOption = new Option(newVendor.vendor_name, newVendor.vendor_id, false, false);
                        $('#vendor_id').append(newOption).trigger('change');

                        // Hide the modal
                        $('#addVendorModal').modal('hide');

                        // Clear the form fields
                        $('#addVendorForm')[0].reset();

                        // Hide the add button
                        $('#add_vendor_container').hide();

                          // Display success alert
                          alert('Vendor added successfully!');
                    },
                    error: function() {
                        alert('Error adding vendor. Please try again.');
                    }
                });
            });




        });

        function fetchUnitName(element) {
            var rawMaterialId = element.value;
        
            if (rawMaterialId) {
                // AJAX request
                $.ajax({
                    url: 'fetch_unit_name.php',
                    type: 'GET',
                    data: { id: rawMaterialId },
                    success: function(response) {
                        $(element).closest('.row').find('.raw_material_unit_name').val(response);
                    }
                });
            } else {
                $(element).closest('.row').find('.raw_material_unit_name').val('');
            }
        }
        function calculateAmount(input) {
            // Get the quantity and rate input fields for this row
            var quantity = input.parentElement.parentElement.querySelector('.raw_matarial_quantity').value;
            var rate = input.parentElement.parentElement.querySelector('.raw_matarial_rate').value;

            // Calculate the amount
            var amount = parseFloat(quantity) * parseFloat(rate);

            // Update the amount field for this row
            input.parentElement.parentElement.querySelector('.raw_matarial_amount').value = amount;
        }

        function choose_vendor(element) {
            var vendor_id = element.value;
            if (vendor_id) {
                $.ajax({
                    url: 'fetch_vendor_details.php',
                    type: 'POST',
                    data: { vendor_id: vendor_id },
                    success: function(response) {
                        var vendor = JSON.parse(response);
                        document.getElementById('display_vendor_person_name').value = vendor.vendor_person_name;
                        document.getElementById('display_vendor_contact_no').value = vendor.vendor_contact_no;
                        document.getElementById('display_vendor_gst').value = vendor.vendor_gst;
                        document.getElementById('display_vendor_address').value = vendor.vendor_address;
                    },
                    error: function() {
                        alert('Error fetching vendor details.');
                    }
                });
            } else {
                // Clear the fields if no vendor is selected
                document.getElementById('display_vendor_person_name').value = '';
                document.getElementById('display_vendor_contact_no').value = '';
                document.getElementById('display_vendor_gst').value = '';
                document.getElementById('display_vendor_address').value = '';
            }
        }
    </script>

 
<script>
        function toggleDiv(x) {
            

            var menu = document.getElementById('menu' + x);

            if (menu.style.display === 'none') {
                menu.style.display = 'block';

            } else {
                menu.style.display = 'none';
            }
        }
    </script>                            
 

</body>

</html>
