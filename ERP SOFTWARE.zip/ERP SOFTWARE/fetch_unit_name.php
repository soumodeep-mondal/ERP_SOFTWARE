<?php
include('db/conn.php');

if (isset($_GET['id'])) {
    $rawMaterialId = $_GET['id'];

    $sql = "SELECT raw_material_unit_name 
            FROM raw_material_unit_master 
            WHERE raw_material_unit_id = (SELECT raw_material_unit_id FROM raw_material_master WHERE raw_material_id = $rawMaterialId)";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        $fetch2 = mysqli_fetch_array($result);
        if ($fetch2) {
            echo $fetch2['raw_material_unit_name'];
        } else {
            echo '';
        }
    }
} else {
    echo '';
}

mysqli_close($conn);
