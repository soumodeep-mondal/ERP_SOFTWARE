<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
// Delete operation
if (isset($_POST['delete'])) {
    $raw_material_unit_id_to_delete = $_POST['raw_material_unit_id'];
    $sql_delete = "DELETE FROM `master_raw_material_unit` WHERE `raw_material_unit_id` = $raw_material_unit_id_to_delete";

    if (mysqli_query($conn, $sql_delete)) {
        $msg = "succ=Record deleted successfully";
    } else {
        $msg = "err=Error deleting record: " . mysqli_error($conn);
    }
    header("location:master_raw_material_unit.php?". $msg);
}

// Insert operation
if (isset($_POST['submit'])) {
    $raw_material_unit_name = $_POST['raw_material_unit_name'];

    // Insert query
    $sql = "INSERT INTO `master_raw_material_unit` (`raw_material_unit_name`) 
    VALUES ('$raw_material_unit_name')";

    if (mysqli_query($conn, $sql)) {
        $msg = "succ=New Raw Material Unit record created successfully";
    } else {
        $msg = "err=Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    header("location:master_raw_material_unit.php?" . $msg);
}

// Update operation
if (isset($_POST['update'])) {
    $raw_material_unit_id = $_POST['raw_material_unit_id'];
    $raw_material_unit_name = $_POST['raw_material_unit_name'];

    $sql = "UPDATE `master_raw_material_unit` SET 
    `raw_material_unit_name` = '$raw_material_unit_name'
    WHERE `raw_material_unit_id` = $raw_material_unit_id";

    if (mysqli_query($conn, $sql)) {
        $msg = "succ=Raw Material Unit record updated successfully";
    } else {
        $msg = "err=Error updating record: " . mysqli_error($conn);
    }

    header("location:master_raw_material_unit.php?" . $msg);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Dashboard</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
<?php
if (isset($_REQUEST['xedit'])) {
    $raw_material_unit_id = $_REQUEST['raw_material_unit_id'];
    $qre = mysqli_query($conn, "SELECT * FROM master_raw_material_unit WHERE raw_material_unit_id = '$raw_material_unit_id'");
    if ($fetch = mysqli_fetch_array($qre)) {
        // Fetching fields from `master_raw_material_unit`
        $raw_material_unit_id = $fetch['raw_material_unit_id'];
        $raw_material_unit_name = $fetch['raw_material_unit_name'];
    }
}
?>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Raw Material Unit Master</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      
            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Upload Details</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->

                                <form action="" method="post" enctype="multipart/form-data">
                                    <input type="hidden" id="raw_material_unit_id" name="raw_material_unit_id" readonly="readonly" value="<?php if(isset($_REQUEST['xedit'])) { echo $raw_material_unit_id; } ?>" />

                                    <div class="row">
                                        <div class="col-sm-3 form-group">
                                            <label>Raw Material Unit Name <span class="text-danger">*</span></label>
                                            <input class="form-control" type="text" name="raw_material_unit_name" id="raw_material_unit_name" placeholder="Enter raw material unit name" onkeyup="convert_data_to_upper(this);" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($raw_material_unit_name); } ?>" required>
                                        </div>

                                        <div class="col-sm-3 form-group mt-4 pt-2">
                                            <?php if(isset($_REQUEST['xedit'])) { ?>
                                                <button class="btn btn-warning" type="submit" name="update">Update</button>
                                            <?php } else { ?>
                                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Raw Material Unit Details</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Raw Material Unit Name</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        // Fetching data from master_raw_material_unit table
                                        $sql1 = "SELECT * FROM master_raw_material_unit order by raw_material_unit_name";
                                        $query1 = mysqli_query($conn, $sql1);
                                        while ($prd = mysqli_fetch_array($query1)) {
                                    ?>
                                        <tr>
                                            <td><b><?php echo htmlspecialchars($prd['raw_material_unit_name']); ?></b></td>
                                            <td class="d-flex">
                                                <a href="master_raw_material_unit.php?master_raw_material_unit=active&xedit=1&raw_material_unit_id=<?php echo $prd['raw_material_unit_id']; ?>">
                                                    <i class="fa fa-pencil-square" aria-hidden="true" style="font-size:25px;"></i>
                                                </a>
                                                <form method="post" action="" enctype="multipart/form-data" onsubmit="return myFunction();">
                                                    <input type="hidden" name="raw_material_unit_id" value="<?php echo $prd['raw_material_unit_id']; ?>" />
                                                    <button style="border:none; color:#007bff" type="submit" name="delete">
                                                        <i class="fa fa-trash" aria-hidden="true" style="font-size:25px;"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
</body>

</html>
