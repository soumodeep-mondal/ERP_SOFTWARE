<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
 if(isset($_POST['update'])){
    $tax_invoice_id=$_REQUEST['tax_invoice_id'];
    $invoice_no = $_POST['invoice_no'];
    $customer_id = $_POST['customer_id'];
    $invoice_date = $_POST['invoice_date'];
    $delivery_note = $_POST['delivery_note'];
    $mode_terms_payment = $_POST['mode_terms_payment'];
    $ref_no_date = $_POST['ref_no_date'];
    $other_reference = $_POST['other_reference'];
    $buyer_order_no = $_POST['buyer_order_no'];
    $buyer_order_date = $_POST['buyer_order_date'];
    $dispatch_doc_no = $_POST['dispatch_doc_no'];
    $delivery_note_date = $_POST['delivery_note_date'];
    $dispatch_through = $_POST['dispatch_through'];
    $dispatch_destination = $_POST['dispatch_destination'];
    $terms_delivery = $_POST['terms_delivery'];
    $consignee_name = $_POST['consignee_name'];
    $consignee_address = $_POST['consignee_address'];
    $consignee_gstin = $_POST['consignee_gstin'];
    $consignee_state_name = $_POST['consignee_state_name'];
    $buyer_name = $_POST['buyer_name'];
    $buyer_address = $_POST['buyer_address'];
    $buyer_gstin = $_POST['buyer_gstin'];
    $buyer_state_name = $_POST['buyer_state_name'];
    $place_supply = $_POST['place_supply'];
    $amount_chargeable_word = $_POST['amount_chargeable_word'];
    $tax_amount_word = $_POST['tax_amount_word'];
    $remarks = $_POST['remarks'];
    $irn_no = $_POST['irn_no'];
    $ack_no = $_POST['ack_no'];
    $ack_date = $_POST['ack_date'];
    $grand_total_qty = $_POST['grand_total_qty'];
    $grand_total_taxable_amt = $_POST['grand_total_taxable_amt'];
    $grand_total_cgst_amt = $_POST['grand_total_cgst_amt'];
    $grand_total_sgst_amt = $_POST['grand_total_sgst_amt'];
    $grand_total_amt = $_POST['grand_total_amt'];

    $query = "UPDATE tax_invoice SET ";
    $query .= "customer_id='$customer_id', ";
    $query .= "invoice_no='$invoice_no', ";
    $query .= "invoice_date='$invoice_date', ";
    $query .= "delivery_note='$delivery_note', ";
    $query .= "mode_terms_payment='$mode_terms_payment', ";
    $query .= "ref_no_date='$ref_no_date', ";
    $query .= "other_reference='$other_reference', ";
    $query .= "buyer_order_no='$buyer_order_no', ";
    $query .= "buyer_order_date='$buyer_order_date', ";
    $query .= "dispatch_doc_no='$dispatch_doc_no', ";
    $query .= "delivery_note_date='$delivery_note_date', ";
    $query .= "dispatch_through='$dispatch_through', ";
    $query .= "dispatch_destination='$dispatch_destination', ";
    $query .= "terms_delivery='$terms_delivery', ";
    $query .= "consignee_name='$consignee_name', ";
    $query .= "consignee_address='$consignee_address', ";
    $query .= "consignee_gstin='$consignee_gstin', ";
    $query .= "consignee_state_name='$consignee_state_name', ";
    $query .= "buyer_name='$buyer_name', ";
    $query .= "buyer_address='$buyer_address', ";
    $query .= "buyer_gstin='$buyer_gstin', ";
    $query .= "buyer_state_name='$buyer_state_name', ";
    $query .= "place_supply='$place_supply', ";
    $query .= "amount_chargeable_word='$amount_chargeable_word', ";
    $query .= "tax_amount_word='$tax_amount_word', ";
    $query .= "remarks='$remarks', ";
    $query .= "irn_no='$irn_no', ";
    $query .= "ack_no='$ack_no', ";
    $query .= "ack_date='$ack_date', ";
    $query .= "grand_total_qty='$grand_total_qty', ";
    $query .= "grand_total_taxable_amt='$grand_total_taxable_amt', ";
    $query .= "grand_total_cgst_amt='$grand_total_cgst_amt', ";
    $query .= "grand_total_sgst_amt='$grand_total_sgst_amt', ";
    $query .= "grand_total_amt='$grand_total_amt' ";
    $query .= "WHERE tax_invoice_id='$tax_invoice_id'";

    $display_result = mysqli_query($conn, $query);
    



    

    $query_0000 = "SELECT tax_invoice_details_id FROM tax_invoice_details WHERE tax_invoice_id = '$tax_invoice_id' LIMIT 1";
    $result_0000 = mysqli_query($conn, $query_0000);
    $row_0000 = mysqli_fetch_array($result_0000);
    $tax_invoice_details_id_1 = $row_0000['tax_invoice_details_id'];
    $tax_invoice_details_id_2 = $tax_invoice_details_id_1 + 1;
    $tax_invoice_details_id_3 = $tax_invoice_details_id_1 + 2;
    $tax_invoice_details_id_4 = $tax_invoice_details_id_1 + 3;
    $tax_invoice_details_id_5 = $tax_invoice_details_id_1 + 4;

    for ($i = 1; $i <= 5; $i++) {
        $tax_invoice_details_id = ${'tax_invoice_details_id_' . $i};
        $updateQuery = "UPDATE tax_invoice_details SET ";

        $updateQuery .= "prod_name = '" . trim($_POST['prod_name'][$i - 1]) . "', ";
        $updateQuery .= "hsn_sac_code = '" . trim($_POST['hsn_sac_code'][$i - 1]) . "', ";
        $updateQuery .= "qty = '" . trim($_POST['qty' . $i]) . "', ";
        $updateQuery .= "rate = '" . trim($_POST['rate' . $i]) . "', ";
        $updateQuery .= "per_id = '" . trim($_POST['per_value' . $i]) . "', ";
        $updateQuery .= "taxable_amt = '" . trim($_POST['taxable_amt' . $i]) . "', ";
        $updateQuery .= "cgst_rate = '" . trim($_POST['cgst_rate' . $i]) . "', ";
        $updateQuery .= "cgst_amt = '" . trim($_POST['cgst_amt' . $i]) . "', ";
        $updateQuery .= "sgst_rate = '" . trim($_POST['sgst_rate' . $i]) . "', ";
        $updateQuery .= "sgst_amt = '" . trim($_POST['sgst_amt' . $i]) . "', ";
        $updateQuery .= "total_amount = '" . trim($_POST['total_amount' . $i]) . "' ";

        $updateQuery .= "WHERE tax_invoice_details_id = '$tax_invoice_details_id'";
        
        $result = mysqli_query($conn, $updateQuery);
    }
    header("location: tax_invoice.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Tax Invoice</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
<?php if (isset($_REQUEST['xedit'])) {
        $tax_invoice_id = $_REQUEST["tax_invoice_id"];

        /* SELECT `tax_invoice_id`, `customer_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery`, `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`, `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply`, `amount_chargeable_word`, `tax_amount_word`, `remarks`, `irn_no`, `ack_no`, `ack_date`, `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` FROM `tax_invoice` WHERE 1 */

        $sql="SELECT * FROM tax_invoice WHERE tax_invoice_id='$tax_invoice_id'";
        $result=mysqli_query($conn,$sql);
        if($fetch=mysqli_fetch_array($result)){
            $customer_idx = $fetch["customer_id"];
            $invoice_no = $fetch["invoice_no"];
            $invoice_date = $fetch["invoice_date"];
            $delivery_note = $fetch["delivery_note"];
            $mode_terms_payment = $fetch["mode_terms_payment"];
            $ref_no_date = $fetch["ref_no_date"];
            $other_reference = $fetch["other_reference"];
            $buyer_order_no = $fetch["buyer_order_no"];
            $buyer_order_date = $fetch["buyer_order_date"];
            $dispatch_doc_no = $fetch["dispatch_doc_no"];
            $delivery_note_date = $fetch["delivery_note_date"];
            $dispatch_through = $fetch["dispatch_through"];
            $dispatch_destination = $fetch["dispatch_destination"];
            $terms_delivery = $fetch["terms_delivery"];
            $consignee_name = $fetch["consignee_name"];
            $consignee_address = $fetch["consignee_address"];
            $consignee_gstin = $fetch["consignee_gstin"];
            $consignee_state_name = $fetch["consignee_state_name"];
            $buyer_name = $fetch["buyer_name"];
            $buyer_address = $fetch["buyer_address"];
            $buyer_gstin = $fetch["buyer_gstin"];
            $buyer_state_name = $fetch["buyer_state_name"];
            $place_supply = $fetch["place_supply"];
            $amount_chargeable_word = $fetch["amount_chargeable_word"];
            $tax_amount_word = $fetch["tax_amount_word"];
            $remarks = $fetch["remarks"];
            $irn_no = $fetch["irn_no"];
            $ack_no = $fetch["ack_no"];
            $ack_date = $fetch["ack_date"];
            $grand_total_qty = $fetch["grand_total_qty"];
            $grand_total_taxable_amt = $fetch["grand_total_taxable_amt"];
            $grand_total_cgst_amt = $fetch["grand_total_cgst_amt"];
            $grand_total_sgst_amt = $fetch["grand_total_sgst_amt"];
            $grand_total_amt = $fetch["grand_total_amt"];
        }

        if(isset($_REQUEST['xedit']) && isset($_REQUEST['tax_invoice_id'])){
            /* SELECT `tax_invoice_details_id`, `tax_invoice_id`, `prod_name`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE 1 */
            $query_0000="SELECT tax_invoice_details_id FROM tax_invoice_details WHERE tax_invoice_id = '$tax_invoice_id' LIMIT 1";
            $result_0000=mysqli_query($conn,$query_0000);
            $row_0000=mysqli_fetch_array($result_0000);
            $tax_invoice_details_id_1=$row_0000['tax_invoice_details_id'];
            $tax_invoice_details_id_2=$row_0000['tax_invoice_details_id']+1;
            $tax_invoice_details_id_3=$row_0000['tax_invoice_details_id']+2;
            $tax_invoice_details_id_4=$row_0000['tax_invoice_details_id']+3;
            $tax_invoice_details_id_5=$row_0000['tax_invoice_details_id']+4;


            // row 1 data fetched 
            $prod_name_1="";
            $hsn_sac_code_1="";
            $qty_1="";
            $rate_1="";
            $per_id_1="";
            $taxable_amt_1="";
            $cgst_rate_1="";
            $cgst_amt_1="";
            $sgst_rate_1="";
            $sgst_amt_1="";
            $total_amount_1="";
            $query_0001="SELECT * FROM tax_invoice_details WHERE tax_invoice_details_id='$tax_invoice_details_id_1'";
            $result_0001=mysqli_query($conn,$query_0001);
            if($row_0001=mysqli_fetch_array($result_0001)){
                $tax_invoice_details_id_1=$row_0001['tax_invoice_details_id'];
            $tax_invoice_id_1=$row_0001['tax_invoice_id'];
            $prod_name_1=$row_0001['prod_name'];
            $hsn_sac_code_1=$row_0001['hsn_sac_code'];
            $qty_1=$row_0001['qty'];
            $rate_1=$row_0001['rate'];
            $per_id_1=$row_0001['per_id'];
            $taxable_amt_1=$row_0001['taxable_amt'];
            $cgst_rate_1=$row_0001['cgst_rate'];
            $cgst_amt_1=$row_0001['cgst_amt'];
            $sgst_rate_1=$row_0001['sgst_rate'];
            $sgst_amt_1=$row_0001['sgst_amt'];
            $total_amount_1=$row_0001['total_amount'];
            }


            // row 2 data fetched 
            $prod_name_2="";
            $hsn_sac_code_2="";
            $qty_2="";
            $rate_2="";
            $per_id_2="";
            $taxable_amt_2="";
            $cgst_rate_2="";
            $cgst_amt_2="";
            $sgst_rate_2="";
            $sgst_amt_2="";
            $total_amount_2="";
            $query_0002="SELECT * FROM tax_invoice_details WHERE tax_invoice_details_id='$tax_invoice_details_id_2'";
            $result_0002=mysqli_query($conn,$query_0002);
            if($row_0002=mysqli_fetch_array($result_0002)){
                $tax_invoice_details_id_2=$row_0002['tax_invoice_details_id'];
                $tax_invoice_id_2=$row_0002['tax_invoice_id'];
                $prod_name_2=$row_0002['prod_name'];
                $hsn_sac_code_2=$row_0002['hsn_sac_code'];
                $qty_2=$row_0002['qty'];
                $rate_2=$row_0002['rate'];
                $per_id_2=$row_0002['per_id'];
                $taxable_amt_2=$row_0002['taxable_amt'];
                $cgst_rate_2=$row_0002['cgst_rate'];
                $cgst_amt_2=$row_0002['cgst_amt'];
                $sgst_rate_2=$row_0002['sgst_rate'];
                $sgst_amt_2=$row_0002['sgst_amt'];
                $total_amount_2=$row_0002['total_amount'];
            }

            // row 3 data fetched 
            $prod_name_3="";
            $hsn_sac_code_3="";
            $qty_3="";
            $rate_3="";
            $per_id_3="";
            $taxable_amt_3="";
            $cgst_rate_3="";
            $cgst_amt_3="";
            $sgst_rate_3="";
            $sgst_amt_3="";
            $total_amount_3="";
            $query_0003="SELECT * FROM tax_invoice_details WHERE tax_invoice_details_id='$tax_invoice_details_id_3'";
            $result_0003=mysqli_query($conn,$query_0003);
            if($row_0003=mysqli_fetch_array($result_0003)){
                $tax_invoice_details_id_3=$row_0003['tax_invoice_details_id'];
                $tax_invoice_id_3=$row_0003['tax_invoice_id'];
                $prod_name_3=$row_0003['prod_name'];
                $hsn_sac_code_3=$row_0003['hsn_sac_code'];
                $qty_3=$row_0003['qty'];
                $rate_3=$row_0003['rate'];
                $per_id_3=$row_0003['per_id'];
                $taxable_amt_3=$row_0003['taxable_amt'];
                $cgst_rate_3=$row_0003['cgst_rate'];
                $cgst_amt_3=$row_0003['cgst_amt'];
                $sgst_rate_3=$row_0003['sgst_rate'];
                $sgst_amt_3=$row_0003['sgst_amt'];
                $total_amount_3=$row_0003['total_amount'];
            }


            // row 4 data fetched 
            $prod_name_4="";
            $hsn_sac_code_4="";
            $qty_4="";
            $rate_4="";
            $per_id_4="";
            $taxable_amt_4="";
            $cgst_rate_4="";
            $cgst_amt_4="";
            $sgst_rate_4="";
            $sgst_amt_4="";
            $total_amount_4="";
            $query_0004="SELECT * FROM tax_invoice_details WHERE tax_invoice_details_id='$tax_invoice_details_id_4'";
            $result_0004=mysqli_query($conn,$query_0004);
            if($row_0004=mysqli_fetch_array($result_0004)){
                $tax_invoice_details_id_4=$row_0004['tax_invoice_details_id'];
                $tax_invoice_id_4=$row_0004['tax_invoice_id'];
                $prod_name_4=$row_0004['prod_name'];
                $hsn_sac_code_4=$row_0004['hsn_sac_code'];
                $qty_4=$row_0004['qty'];
                $rate_4=$row_0004['rate'];
                $per_id_4=$row_0004['per_id'];
                $taxable_amt_4=$row_0004['taxable_amt'];
                $cgst_rate_4=$row_0004['cgst_rate'];
                $cgst_amt_4=$row_0004['cgst_amt'];
                $sgst_rate_4=$row_0004['sgst_rate'];
                $sgst_amt_4=$row_0004['sgst_amt'];
                $total_amount_4=$row_0004['total_amount'];
            }

            // row 5 data fetched 
            $prod_name_5="";
            $hsn_sac_code_5="";
            $qty_5="";
            $rate_5="";
            $per_id_5="";
            $taxable_amt_5="";
            $cgst_rate_5="";
            $cgst_amt_5="";
            $sgst_rate_5="";
            $sgst_amt_5="";
            $total_amount_5="";
            $query_0005="SELECT * FROM tax_invoice_details WHERE tax_invoice_details_id='$tax_invoice_details_id_5'";
            $result_0005=mysqli_query($conn,$query_0005);
            if($row_0005=mysqli_fetch_array($result_0005)){
                $tax_invoice_details_id_5=$row_0005['tax_invoice_details_id'];
                $tax_invoice_id_5=$row_0005['tax_invoice_id'];
                $prod_name_5=$row_0005['prod_name'];
                $hsn_sac_code_5=$row_0005['hsn_sac_code'];
                $qty_5=$row_0005['qty'];
                $rate_5=$row_0005['rate'];
                $per_id_5=$row_0005['per_id'];
                $taxable_amt_5=$row_0005['taxable_amt'];
                $cgst_rate_5=$row_0005['cgst_rate'];
                $cgst_amt_5=$row_0005['cgst_amt'];
                $sgst_rate_5=$row_0005['sgst_rate'];
                $sgst_amt_5=$row_0005['sgst_amt'];
                $total_amount_5=$row_0005['total_amount'];
            }
        }
    }
    ?>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Tax Invoice</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      

            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">TAX INVOICE</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                                <form action="" method="post">
                                <div class="row">
                                    <div class="col-lg-12 text-center">
                                        <img src="admin-source/images/logo2.png" width="200px" alt="">
                                        <h2 class="invoice-heading">Tax Invoice</h2>
                                        <h4 class="invoice-heading-sub">Orginal/Buyer's Copy/Triplicate Copy</h4>
                                        <hr>
                                    </div>
                                </div>

                                
                                
                                <!-- `irn_no`, `ack_no`, `ack_date` -->
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label for="customer_id"><span class="text-danger">*</span>&nbsp;COMPANY NAME :</label>
                                    </div>
                                    <div class="col-lg-3">
                                        <select id="customer_id" name="customer_id" class="form-control" required >
                                            <option value="">SELECT COMPANY NAME</option>
                                            <?php
                                            /* SELECT `customer_id`, `customer_company_name`, `address`, `state_code`, `state_name`, `gst_in`, `opening_balance`, `date_of_creation` FROM `master_customer` WHERE 1 */
                                            $q=mysqli_query($conn,"SELECT * FROM master_customer ORDER BY customer_company_name");
                                            while($f=mysqli_fetch_array($q))
                                            {
                                                $customer_id=$f['customer_id'];
                                                $customer_company_name=$f['customer_company_name'];
                                                ?>
                                                <option value="<?php echo $customer_id;?>" <?php if(isset($_REQUEST['xedit'])){ if($f['customer_id'] == $customer_idx){ echo "Selected";} }?>><?php echo $customer_company_name;?></option>
                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-9 pt-3">
                                        <div class="row">
                                            <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                                                <p>IRN :<span class="text-danger"></p>
                                            </div>
                                            <div class="col-lg-11 ">
                                                <input class="" type="text" name="irn_no"  id="irn_no"  size="100%" placeholder="Enter IRN" value="<?php if(isset($_REQUEST['xedit'])){echo $irn_no;}?>">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                                                <p>Ack No. :<span class="text-danger"></p>
                                            </div>
                                            <div class="col-lg-11">
                                                <input class="" type="text" name="ack_no"  id="ack_no"  size="100%" placeholder="Enter Ack No" value="<?php if(isset($_REQUEST['xedit'])){echo $ack_no;}?>">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-1 " style="padding-right:0px !important;padding-left:5px !important;">
                                                <p>Ack Date :<span class="text-danger"></p>
                                            </div>
                                            <div class="col-lg-11">
                                                <input class="" type="text" name="ack_date"  id="ack_date"  size="100%" placeholder="Enter Date" value="<?php if(isset($_REQUEST['xedit'])){echo $ack_date;}?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 pt-3">
                                        <img src="invoice/qr.png" width="100px" alt="" style="position:relative;left:50%;transform:translate(-50%,0);">
                                    </div>
                                </div>

                                <div class="row" style="border:2px solid black;">
                                    <div class="col-lg-6" style="border-right:2px solid black;">

                                        <div style="border-bottom:2px solid black;">
                                            <h5 class="pt-3"><b>A.R.Enterprise</b></h5>
                                            <h6>5A,Alimuddin Street, Kolkata-700016</h6>
                                            <h6>GSTIN/UIN: 19ADHPR3448R1ZL</h6>
                                            <h6>State Name : West Bengal, Code : 19</h6>
                                            <h6>E-Mail : ar.enterprise@yahoo.com</h6>
                                        </div>

                                        <!-- `consignee_name`, `consignee_address`, `consignee_gstin`, `consignee_state_name`,  -->
                                        <div style="border-bottom:2px solid black;">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h6 class="pt-1">Consignee (Ship to)</h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_name"  id="consignee_name"  size="100%" placeholder="Enter Name" value="<?php if(isset($_REQUEST['xedit'])){echo $consignee_name;}?>"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_address"  id="consignee_address"  size="100%" placeholder="Enter address" value="<?php if(isset($_REQUEST['xedit'])){echo $consignee_address;}?>"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">GSTIN/UIN:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_gstin"  id="consignee_gstin"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $consignee_gstin;}?>"></p>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">State Name:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="consignee_state_name"  id="consignee_state_name"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $consignee_state_name;}?>"></p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- `buyer_name`, `buyer_address`, `buyer_gstin`, `buyer_state_name`, `place_supply` -->
                                        <div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <h6 class="pt-1">Buyer (Bill to)</h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_name"  id="buyer_name"  size="100%" placeholder="Enter Name" value="<?php if(isset($_REQUEST['xedit'])){echo $buyer_name;}?>"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_address"  id="buyer_address"  size="100%" placeholder="Enter address" value="<?php if(isset($_REQUEST['xedit'])){echo $buyer_address;}?>"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">GSTIN/UIN:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_gstin"  id="buyer_gstin"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $buyer_gstin;}?>"></p>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">State Name:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="buyer_state_name"  id="buyer_state_name"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $buyer_state_name;}?>"></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <p class="pt-1">Place of Supply:</p>
                                                </div>
                                                <div class="col-lg-9">
                                                    <p class="pt-1"><input class="" type="text" name="place_supply"  id="place_supply"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $place_supply;}?>"></p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- `tax_invoice_id`, `invoice_no`, `invoice_date`, `delivery_note`, `mode_terms_payment`, `ref_no_date`, `other_reference`, `buyer_order_no`, `buyer_order_date`, `dispatch_doc_no`, `delivery_note_date`, `dispatch_through`, `dispatch_destination`, `terms_delivery` -->
                                    <div class="col-lg-6">
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Invoice No.</h6>
                                                <p><input class="" type="text" name="invoice_no"  id="invoice_no"  size="100%" placeholder="Enter invoice no." value="<?php if(isset($_REQUEST['xedit'])){echo $invoice_no;}?>"></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Dated</h6>
                                                <p><input class="" type="text" name="invoice_date"  id="invoice_date"  size="100%" placeholder="Enter Date" value="<?php if(isset($_REQUEST['xedit'])){echo $invoice_date;}?>"></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Delivery Note</h6>
                                                <p><input class="" type="text" name="delivery_note"  id="delivery_note"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $delivery_note;}?>"></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Mode/Terms of Payment</h6>
                                                <p><input class="" type="text" name="mode_terms_payment"  id="mode_terms_payment"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $mode_terms_payment;}?>"></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Reference No. & Date.</h6>
                                                <p><input class="" type="text" name="ref_no_date"  id="ref_no_date"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $ref_no_date;}?>"></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Other References</h6>
                                                <p><input class="" type="text" name="other_reference"  id="other_reference"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $other_reference;}?>"></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Buyer's Order No.</h6>
                                                <p><input class="" type="text" name="buyer_order_no"  id="buyer_order_no"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $buyer_order_no;}?>"></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Dated</h6>
                                                <p><input class="" type="text" name="buyer_order_date"  id="buyer_order_date"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $buyer_order_date;}?>"></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Dispatch Doc No.</h6>
                                                <p><input class="" type="text" name="dispatch_doc_no"  id="dispatch_doc_no"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $dispatch_doc_no;}?>"></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Delivery Note Date</h6>
                                                <p><input class="" type="text" name="delivery_note_date"  id="delivery_note_date"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $delivery_note_date;}?>"></p>
                                            </div>
                                        </div>
                                        <div class="row" style="border-bottom:2px solid black;">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <h6 class="pt-2">Dispatched through</h6>
                                                <p><input class="" type="text" name="dispatch_through"  id="dispatch_through"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $dispatch_through;}?>"></p>
                                            </div>
                                            <div class="col-lg-6">
                                                <h6 class="pt-2">Destination</h6>
                                                <p><input class="" type="text" name="dispatch_destination"  id="dispatch_destination"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $dispatch_destination;}?>"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <h6 class="pt-2">Terms of Delivery</h6>
                                                <p>
                                                    <textarea size="100%" name="terms_delivery"  id="terms_delivery"  id="" cols="100" rows="5" ><?php if(isset($_REQUEST['xedit'])){echo $terms_delivery;}?></textarea>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- SELECT `tax_invoice_details_id`, `description_goods`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE 1 -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div style="width:3%; border-right:2px solid black;border-left:2px solid black; text-align: center;">
                                        Sl No.
                                    </div>
                                    <div style="width:23%; border-right:2px solid black; text-align: center;">
                                        Description of Goods
                                    </div>
                                    <div style="width:10%; border-right:2px solid black;  text-align: center;">
                                        HSN/SAC 
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Qty
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Rate
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Per
                                    </div>
                                    <div style="width:5%; border-right:2px solid black; text-align: center;">
                                        Taxable Amt
                                    </div>
                                    <div style="width:15%; border-right:2px solid black;  text-align: center;">
                                        <div>
                                            <div style="width:100%; border-bottom:2px solid black;">
                                                <h6 class="text-center"><b>CGST</b></h6>
                                            </div>
                                            <div style="width:100%;">
                                                <div style="display:flex;">
                                                    <div style="width:50%; height:100%; border-right:2px solid black;">
                                                        <h6 class="text-center"><b>Rate</b></h6>

                                                    </div>
                                                    <div style="width:50%;">
                                                        <h6 class="text-center"><b>Amount</b></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="width:15%; border-right:2px solid black; text-align: center;">
                                        <div>
                                            <div style="width:100%; border-bottom:2px solid black;">
                                                <h6 class="text-center"><b>SGST&nbsp;/&nbsp;UGST</b></h6>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <h6 class="text-center"><b>Rate</b></h6>

                                                    </div>
                                                    <div class="col-lg-6">
                                                        <h6 class="text-center"><b>Amount</b></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="width:14%; border-right:2px solid black; text-align: center;">
                                        <p>Amount</p>
                                    </div>
                                </div>
                                <!-- ======================= bill section ======================= -->
                                <!-- SELECT `tax_invoice_details_id`, `description_goods`, `hsn_sac_code`, `qty`, `rate`, `taxable_amt`, `cgst_rate`, `cgst_amt`, `sgst_rate`, `sgst_amt`, `total_amount` FROM `tax_invoice_details` WHERE 1 -->
                                
                                <!-- =========== row 1 ============ -->
                                <div class="row" id="row1">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="" value="1">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $f['prod_id'];?>" <?php if(isset($_REQUEST['xedit'])) if($f['prod_id']==$prod_name_1) echo 'selected';?>><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="" value="<?php echo $hsn_sac_code_1;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty1"  id="qty1"  size="100%" placeholder="" value="<?php echo $qty_1;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate1"  id="rate"  size="100%" placeholder="" value="<?php echo $rate_1;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value1" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>" <?php if($per_id==$per_id_1){ echo "selected"; }?>  ><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt1"  id="taxable_amt"  size="100%" placeholder="" value="<?php echo $taxable_amt_1;?>">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate1"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $cgst_rate_1;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt1"  id="cgst_amt"  size="100%" placeholder="" value="<?php echo $cgst_amt_1;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate1"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $sgst_rate_1;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt1"  id="sgst_amt"  size="100%" placeholder="" value="<?php echo $sgst_amt_1;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount1"  id="total_amount"  size="100%" placeholder="" value="<?php echo $total_amount_1;?>">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 2 ============ -->
                                <div class="row" id="row2">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="" value="2">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $f['prod_id'];?>" <?php if(isset($_REQUEST['xedit'])) if($f['prod_id']==$prod_name_2) echo 'selected';?>><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="" value="<?php echo $hsn_sac_code_2;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty2"  id="qty1"  size="100%" placeholder="" value="<?php echo $qty_2;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate2"  id="rate"  size="100%" placeholder="" value="<?php echo $rate_2;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value2" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                    <option value="<?php echo $per_id;?>" <?php if($per_id==$per_id_2){ echo "selected"; }?>  ><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt2"  id="taxable_amt"  size="100%" placeholder="" value="<?php echo $taxable_amt_2;?>">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate2"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $cgst_rate_2;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt2"  id="cgst_amt"  size="100%" placeholder="" value="<?php echo $cgst_amt_2;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate2"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $sgst_rate_2;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt2"  id="sgst_amt"  size="100%" placeholder="" value="<?php echo $sgst_amt_2;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount2"  id="total_amount"  size="100%" placeholder="" value="<?php echo $total_amount_2;?>">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 3 ============ -->
                                <div class="row" id="row3">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="" value="3">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $f['prod_id'];?>" <?php if(isset($_REQUEST['xedit'])) if($f['prod_id']==$prod_name_3) echo 'selected';?>><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="" value="<?php echo $hsn_sac_code_3;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty3"  id="qty1"  size="100%" placeholder="" value="<?php echo $qty_3;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate3"  id="rate"  size="100%" placeholder="" value="<?php echo $rate_3;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value3" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                   <option value="<?php echo $per_id;?>" <?php if($per_id==$per_id_3){ echo "selected"; }?>  ><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt3"  id="taxable_amt"  size="100%" placeholder="" value="<?php echo $taxable_amt_3;?>">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate3"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $cgst_rate_3;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt3"  id="cgst_amt"  size="100%" placeholder="" value="<?php echo $cgst_amt_3;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate3"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $sgst_rate_3;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt3"  id="sgst_amt"  size="100%" placeholder="" value="<?php echo $sgst_amt_3;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount3"  id="total_amount"  size="100%" placeholder="" value="<?php echo $total_amount_3;?>">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 4 ============ -->
                                <div class="row" id="row4">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="" value="4">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $f['prod_id'];?>" <?php if(isset($_REQUEST['xedit'])) if($f['prod_id']==$prod_name_4) echo 'selected';?>><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="" value="<?php echo $hsn_sac_code_4;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty4"  id="qty1"  size="100%" placeholder="" value="<?php echo $qty_4;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate4"  id="rate"  size="100%" placeholder="" value="<?php echo $rate_4;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value4" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                     <option value="<?php echo $per_id;?>" <?php if($per_id==$per_id_4){ echo "selected"; }?>  ><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt4"  id="taxable_amt"  size="100%" placeholder="" value="<?php echo $taxable_amt_4;?>">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate4"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $cgst_rate_4;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt4"  id="cgst_amt"  size="100%" placeholder="" value="<?php echo $cgst_amt_4;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate4"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $sgst_rate_4;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt4"  id="sgst_amt"  size="100%" placeholder="" value="<?php echo $sgst_amt_4;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount4"  id="total_amount"  size="100%" placeholder="" value="<?php echo $total_amount_4;?>">
                                        </p>
                                    </div>
                                </div>
                                <!-- ============ row 5 ============ -->
                                <div class="row" id="row4">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;">
                                        <p class="pt-3"><!--Sl No.-->
                                            <input class="" type="text" name="serial_number"  id=""  size="100%" placeholder="" value="5">
                                        </p>
                                    </div>
                                    <div class="" style="width:23%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Description of Services-->
                                            <select class="prod_name" id="prod_name" name="prod_name[]" style="width:100%;" onchange="updateSerialNumber(this, 1)">
                                                <option value=""><span>SELECT GOODS ITEM</span></option>
                                                <?php
                                                /* SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product ORDER BY prod_name");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $prod_id=$f['prod_id'];
                                                    $prod_name=$f['prod_name'];
                                                    ?>
                                                    <option value="<?php echo $f['prod_id'];?>" <?php if(isset($_REQUEST['xedit'])) if($f['prod_id']==$prod_name_5) echo 'selected';?>><?php echo $prod_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </p>
                                    </div>
                                    <!-- SELECT `prod_id`, `prod_name`, `hsn_sac_id` FROM `master_finished_product` WHERE 1 -->
                                    <div class="" style="width:10%; border-right:2px solid black;">
                                        <p class="pt-3"><!--HSN/SAC-->
                                            <input class="hsn_sac_code" type="text" name="hsn_sac_code[]"  id="hsn_sac_code[]"  size="100%" placeholder="" value="<?php echo $hsn_sac_code_5;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Quantity-->
                                            <input class="quantity-input" type="text" name="qty5"  id="qty1"  size="100%" placeholder="" value="<?php echo $qty_5;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--Rate-->
                                            <input class="rate" type="text" name="rate5"  id="rate"  size="100%" placeholder="" value="<?php echo $rate_5;?>">
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->


                                        <select class="per_value" id="per_value" name="per_value5" style="width:100%;">
                                                <option value=""><span></span></option>
                                                <?php
                                                /* SELECT `per_id`, `per_name`, `per_value` FROM `master_finished_product_unit` WHERE 1 */
                                                $q=mysqli_query($conn,"SELECT * FROM master_finished_product_unit ORDER BY per_id");
                                                while($f=mysqli_fetch_array($q))
                                                {
                                                    $per_id=$f['per_id'];
                                                    $per_name=$f['per_name'];
                                                    $per_value=$f['per_value'];
                                                    ?>
                                                   <option value="<?php echo $per_id;?>" <?php if($per_id==$per_id_5){ echo "selected"; }?>  ><?php echo $per_name;?></option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                            <!-- <input class="" type="text" name="per"  id="per"  size="100%" placeholder=""> -->
                                        </p>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <p class="pt-3"><!--taxable amount-->
                                            <input class="tax-amt-input" type="text" name="taxable_amt4"  id="taxable_amt"  size="100%" placeholder="" value="<?php echo $taxable_amt_5;?>">

                                        </p>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="cgst_rate5"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $cgst_rate_5;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="cgst-amt-input" type="text" name="cgst_amt5"  id="cgst_amt"  size="100%" placeholder="" value="<?php echo $cgst_amt_5;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%; border-right:2px solid black;">
                                        <div style="display:flex;">
                                            <div style="width:50%; height:100%;border-right:2px solid black;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="gst_rate" type="text" name="sgst_rate5"  id="gst_rate[]"  size="100%" placeholder="" value="<?php echo $sgst_rate_5;?>">
                                                </p>
                                            </div>
                                            <div style="width:50%;height:100%;">
                                                <p class="pt-3"><!--per-->
                                                    <input class="sgst-amt-input" type="text" name="sgst_amt5"  id="sgst_amt"  size="100%" placeholder="" value="<?php echo $sgst_amt_5;?>">
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="width:14%; border-right:2px solid black;">
                                        <p class="pt-3"><!--per-->
                                            <input class="total-amt-input" type="text" name="total_amount5"  id="total_amount"  size="100%" placeholder="" value="<?php echo $total_amount_5;?>">
                                        </p>
                                    </div>
                                </div>
                                <!-- ======================================================================== -->
                                <!-- `grand_total_qty`, `grand_total_taxable_amt`, `grand_total_cgst_amt`, `grand_total_sgst_amt`, `grand_total_amt` -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="" style="width:3%; border-right:2px solid black;border-left:2px solid black;"></div>
                                    <div class="text-right" style="width:23%; border-right:2px solid black;">
                                        <h5 class="pt-3"> <b>Total</b></h5>
                                    </div>
                                    <div class="" style="width:10%; border-right:2px solid black;"></div>

                                    <div class="" style="width:5%; border-right:2px solid black;">
                                        <h6 class="pt-3"> <b><input class="grand-total-qty" type="text" name="grand_total_qty"  id="grand_total_qty"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $grand_total_qty;}?>"></b></h6>
                                    </div>
                                    <div class="" style="width:5%; border-right:2px solid black;"></div>
                                    <div class="" style="width:5%; border-right:2px solid black;"></div>

                                    <div class="" style="width:5%; border-right:2px solid black;">
                                    <h6 class="pt-3"> <b><input class="grand-total-tax-amt" type="text" name="grand_total_taxable_amt"  id="grand_total_taxable_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $grand_total_taxable_amt;}?>"></b></h6></div>

                                    <div class="" style="width:15%; display:flex; border-right:2px solid black;">
                                        <div style="width:50%; height:100%; border-right:2px solid black;"></div>
                                        <div style="width:50%; height:100%;">
                                            <h6 class="pt-3"> <b><input class="grand-total-cgst-amt" type="text" name="grand_total_cgst_amt"  id="grand_total_cgst_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $grand_total_cgst_amt;}?>"></b></h6>
                                        </div>
                                    </div>
                                    <div class="" style="width:15%;display:flex; border-right:2px solid black;">
                                        <div style="width:50%; height:100%; border-right:2px solid black;"></div>
                                        <div style="width:50%; height:100%;">
                                            <h6 class="pt-3"> <b><input class="grand-total-sgst-amt" type="text" name="grand_total_sgst_amt"  id="grand_total_sgst_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $grand_total_sgst_amt;}?>"></b></h6>       
                                        </div>
                                    </div>
                                    <div class="text-right" style="width:14%; border-right:2px solid black;">
                                        <h5 class="pt-3"><b>
                                            <input class="grand-total-amt" type="text" name="grand_total_amt"  id="grand_total_amt"  size="100%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $grand_total_amt;}?>">
                                        </b></h5>
                                    </div>
                                </div>
                                <!-- ======================================================================== -->

                                <!-- `amount_chargeable_word`, `tax_amount_word`, `remarks`,  -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-12 pt-1" style="border-right:2px solid black;border-left:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <p>Amount Chargeable (in words)</p>
                                            </div>
                                            <div class="col-lg-6">
                                                <p class="text-right">E. & O.E</p>
                                            </div>
                                        </div>
                                        <p> <input class="" type="text" name="amount_chargeable_word"  id="amount_chargeable_word"  onfocus="convertNumberToWords()" size="150%" placeholder="" value="<?php if(isset($_REQUEST['xedit'])){echo $tax_amount_word;}?>"></p>
                                    </div>
                                </div>

                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-1" style="border-right:2px solid black;border-left:2px solid black;">
                                        <h6 class="text-center"><b>HSN/SAC</b></h6>
                                    </div>
                                    <div class="col-lg-1 pt-1" style="border-right:2px solid black;">
                                        <h6 class="text-center"><b>Taxable Value</b></h6>
                                    </div>
                                    <div class="col-lg-5" style="border-right:2px solid black;">

                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">

                                                <div class="row">
                                                    <div class="col-lg-12" style="border-bottom:2px solid black;">
                                                        <h6 class="text-center"><b>CGST</b></h6>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                                <h6 class="text-center"><b>Rate</b></h6>

                                                            </div>
                                                            <div class="col-lg-6">
                                                                <h6 class="text-center"><b>Amount</b></h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">

                                                <div class="row">
                                                    <div class="col-lg-12" style="border-bottom:2px solid black;">
                                                        <h6 class="text-center"><b>SGST/UTGST</b></h6>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                                <h6 class="text-center"><b>Rate</b></h6>

                                                            </div>
                                                            <div class="col-lg-6">
                                                                <h6 class="text-center"><b>Amount</b></h6>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <h6 class="text-center"><b>Total Tax Amount</b></h6>
                                    </div>
                                </div>


                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                                        <p><input class="hsn_sac_code_output" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-5 " style="border-right:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                </div>

                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-5 " style="border-right:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                </div>

                                <!-- new cell grand total   -->
                                <div class="row" style="border-bottom:2px solid black;">
                                    <div class="col-lg-4 pt-2" style="border-right:2px solid black;border-left:2px solid black;">
                                        <h5 class="text-right"><b>Total</b></h5>
                                    </div>
                                    <div class="col-lg-1 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                    <div class="col-lg-5 " style="border-right:2px solid black;">
                                        <div class="row">
                                            <div class="col-lg-6" style="border-right:2px solid black;">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6" style="border-right:2px solid black;">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <p class="pt-2"><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 pt-2" style="border-right:2px solid black;">
                                        <p><input class="" type="text" name=""  id=""  size="100%" placeholder=""></p>
                                    </div>
                                </div>
                                <!-- `amount_chargeable_word`, `tax_amount_word`, `remarks` -->
                                <div class="row pt-3" style="border-right:2px solid black;border-left:2px solid black;">
                                    <div class="col-lg-3">
                                        <h5>Tax Amount (in words) : </h5>
                                    </div>
                                    <div class="col-lg-9">
                                        <p><input class="" type="text" name="tax_amount_word"  id="tax_amount_word"  size="100%" placeholder="INR Five Hundred Thirty and Six paise Only" value="<?php if(isset($_REQUEST['xedit'])){echo $tax_amount_word;}?>"></p>
                                    </div>
                                </div>

                                <div class="row pt-3" style="border-bottom:2px solid black;border-right:2px solid black;border-left:2px solid black;">
                                    <div class="col-lg-6">
                                        <h5><b> Remarks: </b></h5>

                                        <textarea size="100" name="remarks"  id="remarks"  id="" cols="100" rows="3" ><?php if(isset($_REQUEST['xedit'])){echo $remarks;}?></textarea>

                                        <div class="row pt-3">
                                            <div class="col-lg-6">
                                                <h5>
                                                    Company's PAN
                                                </h5>
                                            </div>
                                            <div class="col-lg-6">
                                                <h5>
                                                    <b>: ADHPR3448R</b>
                                                </h5>
                                            </div>
                                        </div>

                                        <div class="row pt-2">
                                            <div class="col-lg-12">
                                                <h5 style="text-decoration:underline;">
                                                    <b> Declaration</b>
                                                </h5>
                                                <p>We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</p>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="col-lg-6">
                                        <h5><b>Company's Bank Details</b></h5>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>A/c Holder's Name </h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b> : A.R.Enterprise</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>Bank Name </h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b>: Punjab National Bank</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>A/c No.</h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b> : 7870002100000553</b></h5>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <h5>Branch & IFS Code</h5>
                                            </div>
                                            <div class="col-lg-8">
                                                <h5><b> : Baguiati & PUNB0787000</b></h5>
                                            </div>
                                        </div>


                                        <div class="row pt-5" style="border-top:2px solid black;border-left:2px solid black;">
                                            <div class="col-lg-4 pt-5">
                                                <div>
                                                    <img src="invoice/prepared_by.png" alt="">
                                                </div>
                                                <div class="text-center">
                                                    <h6>Prepared By</h6>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 pt-5">
                                                <div>
                                                    <img src="invoice/verified_by.png" alt="">
                                                </div>
                                                <div class="text-center">
                                                    <h6>Verified By </h6>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 pt-5">
                                                <div>
                                                    <img src="invoice/authorised_signatory.png" alt="">
                                                </div>
                                                <div class="text-center">
                                                    <h6>Authorised Signatory</h6>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row p">
                                    <div class="col-lg-12">
                                        <h5 class="text-center pt-4"><b>SUBJECT TO KOLKATA JURISDICTION</b></h5>
                                        <h6 class="text-center pt-4">This is a Computer Generated Invoice</h6>
                                    </div>
                                </div>
                                <div class="row justify-content-between">
                                    <div></div>
                                    <div>
                                        <button type="submit" name="update" id="update" class="btn btn-primary" style="width:150px"> UPDATE </button>
                                    </div>
                                </div>
                                </form>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>

            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>

    <script>
    function updateSerialNumber(selectElement, rowNumber) {
        var selectedValue = selectElement.value;
        var serialNumberInput = document.querySelector('#row' + rowNumber + ' input[name="serial_number"]');
        serialNumberInput.value = selectedValue === '' ? '' : rowNumber.toString();
    }
</script>

<script>
function numberToWords(number) {
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
    const teens = ['', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', 'Ten', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    const scales = ['', 'Thousand', 'Lakh', 'Crore'];

    const toWords = (number) => {
        if (number === 0) return 'Zero';

        let words = '';

        const integerPart = Math.floor(number);
        const fractionalPart = Math.round((number - integerPart) * 100); // Get two decimal places

        if (integerPart > 0) {
            words += convertToWords(integerPart) + ' Rupees';
        }

        if (fractionalPart > 0) {
            words += (words ? ' and ' : '') + convertToWords(fractionalPart) + ' Paisa';
        }

        return words.trim().toUpperCase();
    };

    const convertToWords = (number) => {
        let words = '';

        for (let i = 0; number > 0 && i < scales.length; i++) {
            let triplet = number % 1000;
            if (triplet !== 0) {
                let tripletWords = '';
                let hundreds = Math.floor(triplet / 100);
                let tensUnits = triplet % 100;

                if (hundreds > 0) {
                    tripletWords += ones[hundreds] + ' Hundred ';
                }

                if (tensUnits > 0) {
                    if (tensUnits < 10) {
                        tripletWords += ones[tensUnits];
                    } else if (tensUnits < 20) {
                        tripletWords += teens[tensUnits - 10];
                    } else {
                        tripletWords += tens[Math.floor(tensUnits / 10)];
                        if (tensUnits % 10 !== 0) {
                            tripletWords += ' ' + ones[tensUnits % 10];
                        }
                    }
                }

                words = tripletWords.trim() + ' ' + scales[i] + ' ' + words;
            }

            number = Math.floor(number / 1000);
        }

        return words.trim();
    };

    return toWords(number);
}


function convertNumberToWords() {
    const numberInput = document.getElementById("grand_total_amt");
    const number = numberInput.value;

    if (!isNaN(number)) {
        var words = numberToWords(number);
        document.getElementById("amount_chargeable_word").value = words;
    } else {
        wordsOutput.value = ''; // Clear the output field if the input is not a valid number
    }
}

document.getElementById("grand_total_amt").addEventListener("input", convertNumberToWords);

</script>



</body>

</html>
