<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>
<?php
if (isset($_POST['update'])) {

    $user_id= $_POST['user_id'];
    $address = $_POST['address'];
    $contact_no = $_POST['contact_no'];
    $pan_no = $_POST['pan_no'];
    $user_email = $_POST['user_email'];

    $profile_picture_name = '';
    if (!empty($_FILES['profile_picture']['name'])) {
        $errors = array();
        $profile_picture = $_FILES['profile_picture']['name'];
        $profile_picture_temp = $_FILES['profile_picture']['tmp_name'];
        $file_extension = pathinfo($profile_picture, PATHINFO_EXTENSION);
        $unique_id = uniqid();
        $random_string = str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
        $profile_picture_name = $unique_id . '_' . $random_string . '.' . $file_extension;
        if (empty($errors) == true) {
            $SQL_OLD = "SELECT * FROM `master_user` WHERE `user_id`= '$user_id'";
            $QUERY_OLD = mysqli_query($conn, $SQL_OLD);
            if ($transactionDetails = mysqli_fetch_array($QUERY_OLD)) {
                $profile_picture_old = $transactionDetails['profile_picture'];
                unlink("dashboard_source/profile_picture/" . $profile_picture_old);
            }
            move_uploaded_file($profile_picture_temp, "dashboard_source/profile_picture/" . $profile_picture_name);
            $UPDATE = mysqli_query($conn, "UPDATE `master_user` SET `profile_picture` = '$profile_picture_name' WHERE `user_id` = '$user_id'");
        }
    }

    //update query
    $UPDATE = mysqli_query($conn, "UPDATE `master_user` SET `address` ='$address', `contact_no` = '$contact_no', `pan_no` = '$pan_no' WHERE `user_id`= '$user_id'");
    if ($UPDATE) {
        $msg="succ=Profile Updated Successfully.";
        header("location:profile.php?" . $msg);
    } else {
        $msg="err=Profile Not Updated.";
        header("location:profile.php?" . $msg);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>Dashboard</title>
<?php include('includes/dashboard_link_css.php');?>
</head>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">




            <!-- START PAGE CONTENT-->
            <?php
            //SELECT `user_id`, `role`, `name_display`, `address`, `contact_no`, `designation`, `pan_no`, `date_of_join`, `salary`, `user_email`, `user_name`, `password`, `profile_picture`, `status`, `verify_otp` FROM `master_user` WHERE 1
            $qre = mysqli_query($conn, "SELECT * FROM master_user where user_id=$user_id_session");
            if ($fetch = mysqli_fetch_array($qre)) {
            ?>

                <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-lg-3 col-md-4">
                            <div class="ibox">
                                <div class="ibox-body text-center">
                                    <div class="m-t-20">

                                        <?php
                                        $profile_picture = $fetch['profile_picture'];
                                        if ($profile_picture != "") { ?>
                                            <img class="rounded-circle" src="dashboard_source/profile_picture/<?php echo $profile_picture; ?>" width="100%" alt="">
                                        <?php
                                        } else { ?>
                                            <img src="dashboard_source/assets/img/admin-avatar.png" width="100%" alt="">

                                        <?php
                                        }
                                        ?>
                                    </div>
                                    <h5 class="font-strong m-b-10 m-t-10"><?php echo $fetch['name_display']; ?></h5>
                                    <div class="m-b-20 text-muted"><?php echo $fetch['designation']; ?></div>
                                </div>
                            </div>
                            <div class="ibox">
                                <div class="ibox-body">

                                    <p> Email : <?php echo $fetch['user_email']; ?></p>
                                    <p> Mobile No. : <?php echo $fetch['contact_no']; ?></p>
                                    <p> Account Type : <?php echo $fetch['role']; ?></p>
                                    <p> Address : <?php echo $fetch['address']; ?></p>
                                    <p> Pan No : <?php echo $fetch['pan_no']; ?></p>
                                    <p> Date Of Join : <?php echo $fetch['date_of_join']; ?></p>
                                    <p> Salary : <?php echo $fetch['salary']; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-8">
                            <div class="ibox">
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->
                                <div class="ibox-body">
                                    <ul class="nav nav-tabs tabs-line">

                                        <li class="nav-item">
                                            <a class="nav-link active " href="#tab-2" data-toggle="tab"><i class="ti-settings"></i> Update Details</a>
                                        </li>

                                    </ul>
                                    <div class="tab-content">

                                        <div class="tab-pane fade show active" id="tab-1">
                                            <form action="" method="post" enctype="multipart/form-data">
                                                <input type="hidden" id="user_id" name="user_id" readonly="readonly" value="<?php echo $user_id_session; ?>" />
                                                <div class="row">


                                                    <div class="form-group col-4">
                                                        <label>Address <span class="text-danger">*</span></label>
                                                        <input class="form-control" type="text" placeholder="Address" name="address" value="<?php echo $fetch['address']; ?>" required>
                                                    </div>
                                                    <div class="form-group col-4">
                                                        <label>Contact No <span class="text-danger">*</span></label>
                                                        <input class="form-control" type="text" placeholder="Contact No" name="contact_no" value="<?php echo $fetch['contact_no']; ?>" required>
                                                    </div>
                                                    <div class="form-group col-4">
                                                        <label>PAN No <span class="text-danger">*</span></label>
                                                        <input class="form-control" type="text" placeholder="PAN No" name="pan_no" value="<?php echo $fetch['pan_no']; ?>" required>
                                                    </div>
                                                    <div class="form-group col-4">
                                                        <label>Email <span class="text-danger">*</span></label>
                                                        <input class="form-control" type="text" placeholder="Email address" name="user_email" value="<?php echo $fetch['user_email']; ?>" required>
                                                    </div>
                                                    <div class="form-group col-4">
                                                        <label>Profile Picture <span class="text-danger">*</span></label>
                                                        <input class="form-control" type="file" name="profile_picture" value="<?php echo $fetch['profile_picture']; ?>"  >
                                                    </div>
                                                    <div class="form-group col-4 pt-2">
                                                        <button class="btn btn-warning mt-4 pt-2" type="submit" name="update">Update</button>
                                                    </div>




                                                </div>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php
            }
            ?>


    
            <!-- END PAGE CONTENT-->



            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
</body>

</html>