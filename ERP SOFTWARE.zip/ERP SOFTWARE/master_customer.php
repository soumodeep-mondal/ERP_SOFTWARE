<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
// Delete operation
if (isset($_POST['delete'])) {
    $customer_id_to_delete = $_POST['customer_id'];
    $sql_delete = "DELETE FROM `master_customer` WHERE `customer_id` = $customer_id_to_delete";

    if (mysqli_query($conn, $sql_delete)) {
        $msg = "succ=Record deleted successfully";
    } else {
        $msg = "err=Error deleting record: " . mysqli_error($conn);
    }
    header("location:master_customer.php?". $msg);
}

// Insert operation
if (isset($_POST['submit'])) {
    $customer_company_name = $_POST['customer_company_name'];
    $customer_name = $_POST['customer_name'];
    $customer_mob = $_POST['customer_mob'];
    $customer_address = $_POST['customer_address'];
    $customer_state_name = $_POST['customer_state_name'];
    $customer_state_code = $_POST['customer_state_code'];
    $customer_gst_in = $_POST['customer_gst_in'];

    // Insert query
    $sql = "INSERT INTO `master_customer` (`customer_company_name`, `customer_name`, `customer_mob`, `customer_address`, `customer_state_name`, `customer_state_code`, `customer_gst_in`) 
    VALUES ('$customer_company_name', '$customer_name', '$customer_mob', '$customer_address', '$customer_state_name', '$customer_state_code', '$customer_gst_in')";

    if (mysqli_query($conn, $sql)) {
        $msg = "succ=New Vendor record created successfully";
    } else {
        $msg = "err=Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    header("location:master_customer.php?". $msg);
}

// Update operation
if (isset($_POST['update'])) {
    $customer_id = $_POST['customer_id'];
    $customer_company_name = $_POST['customer_company_name'];
    $customer_name = $_POST['customer_name'];
    $customer_mob = $_POST['customer_mob'];
    $customer_address = $_POST['customer_address'];
    $customer_state_name = $_POST['customer_state_name'];
    $customer_state_code = $_POST['customer_state_code'];
    $customer_gst_in = $_POST['customer_gst_in'];

    $sql = "UPDATE `master_customer` SET 
    `customer_company_name` = '$customer_company_name',
    `customer_name` = '$customer_name',
    `customer_mob` = '$customer_mob',
    `customer_address` = '$customer_address',
    `customer_state_name` = '$customer_state_name',
    `customer_state_code` = '$customer_state_code',
    `customer_gst_in` = '$customer_gst_in'
    WHERE `customer_id` = $customer_id";

    if (mysqli_query($conn, $sql)) {
        $msg = "succ=Vendor record updated successfully";
    } else {
        $msg = "err=Error updating record: " . mysqli_error($conn);
    }

    header("location:master_customer.php?". $msg);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Dashboard</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
<?php
if (isset($_REQUEST['xedit'])) {
    $customer_id = $_REQUEST['customer_id'];
    $qre = mysqli_query($conn, "SELECT * FROM master_customer WHERE customer_id = '$customer_id'");
    if ($fetch = mysqli_fetch_array($qre)) {
        // Fetching fields from `master_customer`
        $customer_id = $fetch['customer_id'];
        $customer_company_name = $fetch['customer_company_name'];
        $customer_name = $fetch['customer_name'];
        $customer_mob = $fetch['customer_mob'];
        $customer_address = $fetch['customer_address'];
        $customer_state_name = $fetch['customer_state_name'];
        $customer_state_code = $fetch['customer_state_code'];
        $customer_gst_in = $fetch['customer_gst_in'];
    }
}
?>


<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">


            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Customer Master</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      
            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Upload Details</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->




                                    <form action="" method="post" enctype="multipart/form-data">
                                        <input type="hidden" id="customer_id" name="customer_id" readonly="readonly" value="<?php if(isset($_REQUEST['xedit'])) { echo $customer_id; } ?>" />

                                        <div class="row">
                                            <div class="col-sm-3 form-group">
                                                <label>Company  <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_company_name" id="customer_company_name" placeholder="Enter company name" onkeyup="convert_data_to_upper(this);" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_company_name); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group">
                                                <label>Customer  <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_name" id="customer_name" placeholder="Enter client name" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_name); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group">
                                                <label>Contact No <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_mob" id="customer_mob" placeholder="Enter contact number" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_mob); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group">
                                                <label>Address <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_address" id="customer_address" placeholder="Enter address" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_address); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group">
                                                <label>State Name <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_state_name" id="customer_state_name" placeholder="Enter state name" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_state_name); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group">
                                                <label>State Code <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_state_code" id="customer_state_code" placeholder="Enter state code" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_state_code); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group">
                                                <label>GST IN <span class="text-danger">*</span></label>
                                                <input class="form-control" type="text" name="customer_gst_in" id="customer_gst_in" placeholder="Enter GST IN" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($customer_gst_in); } ?>" required>
                                            </div>

                                            <div class="col-sm-3 form-group mt-4 pt-2">
                                                <?php if(isset($_REQUEST['xedit'])) { ?>
                                                    <button class="btn btn-warning" type="submit" name="update">Update</button>
                                                <?php } else { ?>
                                                    <button class="btn btn-success" type="submit" name="submit">Submit</button>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </form>


                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>





            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Customers Details</div>
                                 <!-- `customer_id`, `cutting_person_name`, `mob_no`, `address`, `aadhar_no`, `bank_details` SELECT * FROM `cutting_master` WHERE 1 -->
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Company Name</th>
                                        <th>Customer Name</th>
                                        <th>Contact No</th>
                                        <th>Address</th>
                                        <th>State Name</th>
                                        <th>State Code</th>
                                        <th>GST IN</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        // Fetching data from master_customer table
                                        $sql1 = "SELECT * FROM master_customer order by customer_company_name ";
                                        $query1 = mysqli_query($conn, $sql1);
                                        while ($prd = mysqli_fetch_array($query1)) {
                                    ?>
                                        <tr>
                                            <td><b><?php echo htmlspecialchars($prd['customer_company_name']); ?></b></td>
                                            <td><b><?php echo htmlspecialchars($prd['customer_name']); ?></b></td>
                                            <td><b><?php echo htmlspecialchars($prd['customer_mob']); ?></b></td>
                                            <td><b><?php echo nl2br(htmlspecialchars($prd['customer_address'])); ?></b></td>
                                            <td><b><?php echo htmlspecialchars($prd['customer_state_name']); ?></b></td>
                                            <td><b><?php echo htmlspecialchars($prd['customer_state_code']); ?></b></td>
                                            <td><b><?php echo htmlspecialchars($prd['customer_gst_in']); ?></b></td>
                                            <td class="d-flex">
                                                <a href="master_customer.php?master_customer=active&xedit=1&customer_id=<?php echo $prd['customer_id']; ?>">
                                                    <i class="fa fa-pencil-square" aria-hidden="true" style="font-size:25px;"></i>
                                                </a>
                                                <form method="post" action="" enctype="multipart/form-data" onsubmit="return myFunction();">
                                                    <input type="hidden" name="customer_id" value="<?php echo $prd['customer_id']; ?>" />
                                                    <button style="border:none; color:#007bff" type="submit" name="delete">
                                                        <i class="fa fa-trash" aria-hidden="true" style="font-size:25px;"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
    
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
</body>

</html>