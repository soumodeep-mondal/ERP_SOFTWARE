<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
if(isset($_POST['submit'])) {
    $department_id = trim($_POST['department_id']);
 
 
    
   $Delete = mysqli_query($conn,"DELETE FROM master_user_department_access WHERE department_id = '$department_id'");


    $i = 0;
    while(isset($_POST['user_id'][$i])) {
        if(!empty($_POST['user_id'][$i])) {
            $user_id = trim($_POST['user_id'][$i]);

            // Construct the SQL query
            $sql1 = "INSERT INTO master_user_department_access (department_id , user_id)
                     VALUES ('$department_id' , '$user_id')";

            // Execute the query
            $query1 = mysqli_query($conn, $sql1);

            if ($query1) {
                 
                header("Location:master_user_department_access.php?department_id=$department_id&msg=Record Insert Success");


            } else {
                echo "Error: " . $sql1 . "<br>" . $conn->error;
            }
        }
        $i++;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Project Access</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
    function set_department_id() {
        var department_id = document.getElementById("department_id").value;
        if (department_id != "") {
            window.location.href = "master_user_department_access.php?department_id=" + department_id;
        }
    }
</script>

</head>
 
<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">USER ACCESS</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      
 

            <div class="page-content fade-in-up">
                <form action="" method="post">
                <div class="row">
                    <div class="col-md-5">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Department Access</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->


                            <div class="ibox-body">
                               

                                    <div class="row">
                                        <div class="col-sm-9 form-group">
                                            <label>Department Name <span class="text-danger">*</span></label>
                                            <select class="form-control" name="department_id" id="department_id" required onchange="set_department_id();">
                                                <option value="">Select Department</option>
                                                <?php
                                                $query = mysqli_query($conn, "SELECT * FROM master_user_department");
                                                while ($row_project = mysqli_fetch_array($query)) { ?>
                                                    <option value="<?php echo $row_project['department_id']; ?>" <?php if (isset($_REQUEST['department_id'])) {
                                                                                                                    if ($row_project['department_id'] == $_REQUEST['department_id']) echo 'selected';
                                                                                                                } ?>>
                                                        <?php echo $row_project['department_name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        </div>

 

                                        <div class="col-sm-2 form-group mt-4 pt-2">
                                            <button class="btn btn-success" type="submit" name="submit">Submit</button>
                                        </div>
                                    </div>
                              

                            </div>
                        </div>
                    </div>

                    <div class="col-md-7">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Users List</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body" style="height:620px; overflow: scroll; "> 

 

                                <?php
                                if(isset($_REQUEST['department_id']))
                                {
                                ?>

                                <table class="table table-striped table-hover"  cellspacing="0" width="100%">
                                   
                                    <thead>
                                            <tr>
                                                <th></th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Contact No</th>
                                                <th>Address</th>
                                            </tr>
                                    </thead>
                                        <tbody>
                                            <?php
                                            $department_id = $_REQUEST['department_id'];
 
                                            $row_count=0;
                                            $query = mysqli_query($conn, "SELECT * FROM master_user WHERE role='EMPLOYEE' ORDER BY name_display");
                                            $row_count = mysqli_num_rows($query);
                                            if ($row_count > 0) {
                                                $Q=0;
                                                while ($row = mysqli_fetch_array($query)) 
                                                {
                                                    $user_id = $row['user_id'];
                                                    $name_display = $row['name_display'];
                                                    $user_email = $row['user_email'];
                                                    $contact_no = $row['contact_no'];
                                                    $designation = $row['designation'];
                                                    $address = $row['address'];
                                                    $count=0;
                                                    $query1 = mysqli_query($conn, "SELECT COUNT(*) as N FROM master_user_department_access where department_id='$department_id' AND user_id='$user_id'");
                                                    if($row1=mysqli_fetch_array($query1)){
                                                        $count=$row1['N'];
                                                    }

                                                    ?>
                                                    <tr>
                                                        <td><input type="checkbox" name="user_id[]" value="<?php echo $user_id;?>" id="user_id" <?php if($count){echo "checked";}?>  ></td>
                                                        <td><?php echo $name_display; ?></td>
                                                        <td><?php echo $designation; ?></td>
                                                        <td><?php echo $contact_no; ?></td>
                                                        <td><?php echo $address; ?></td>
                                                    </tr>
                                            <?php
                                                }
                                                $Q++;
                                            }
                                            ?>





                                        </tbody>
                                    
                                   
                                </table> 
                                    
                                <?php
                                }
                                else
                                {
                                  echo "<div class='text-danger'> <strong>**** Select Department ****</strong></div>"  ;
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
         
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
</body>

</html>
