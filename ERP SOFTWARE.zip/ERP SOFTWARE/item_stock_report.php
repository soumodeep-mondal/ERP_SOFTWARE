<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>
<?php
 
if(isset($_POST['search']))
{
    $reorder_qty=$_POST["reorder_qty"];
    $raw_material_id=$_POST["raw_material_id"];
    header("location:item_stock_report.php?reorder_qty=".$reorder_qty."&raw_material_id=".$raw_material_id);
}

if(isset($_POST["reorder_save"]))
{
 
    $reorder_qty=$_REQUEST["reorder_qty"];
    $raw_material_id=$_REQUEST["raw_material_id"];

    $update_raw_material_id=$_POST["update_raw_material_id"];
    $new_reorder_qty=$_POST["new_reorder_qty"];

    $query1=mysqli_query($conn,"UPDATE master_raw_material SET reorder_qty='$new_reorder_qty' WHERE raw_material_id='$update_raw_material_id'");
    if($query1)
    {
        $msg="succ=Reorder Quantity Updated Successfully";
        header("location:item_stock_report.php?reorder_qty=".$reorder_qty."&raw_material_id=".$raw_material_id."&".$msg);
    }   
     
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>PURCHASED ITEM REPORT</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Items Stock Report</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
                      <!-- Insert and Update Form -->
                      <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="ibox">
                                <div class="ibox-head">
                                    <div class="ibox-title">Items Stock Check</div>
                                    <div class="ibox-tools">
                                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                    </div>
                                </div>
                                <div class="ibox-body">
                                    <!-- Display Messages -->
                                    <?php include('includes/display_massage.php'); ?>

                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="row">
 
                                            <div class="col-sm-3 form-group">
                                                <label>Reorder Quantity</label>
                                                <input class="form-control" type="text" name="reorder_qty" id="reorder_qty" placeholder="Enter quantity" value="<?php if(isset($_REQUEST['reorder_qty'])) { echo $_REQUEST['reorder_qty']; } ?>" >
                                            </div>
                                            <div class="col-lg-4 form-group">
                                                <label>Raw Material </label>
                                                <select class="form-control" name="raw_material_id" id="raw_material_id">
                                                    <option value="" selected >Choose Name</option>
                                                    <?php
                                                    //SELECT `raw_material_id`, `raw_material_unit_id`, `raw_material_name`, `raw_material_desc`, `raw_material_quantity`, `reorder_qty` FROM `master_raw_material` WHERE 1
                                                    $sql_ctgy = "SELECT * FROM `master_raw_material` WHERE 1";
                                                    $query_ctgy = mysqli_query($conn, $sql_ctgy);
                                                    while ($ctgy = mysqli_fetch_array($query_ctgy)) { ?>
                                                        <option value="<?php echo $ctgy['raw_material_id']; ?>"<?php  if(isset($_REQUEST['raw_material_id'])) { if($_REQUEST['raw_material_id']==$ctgy['raw_material_id']) {  echo  "selected";}} ?>  ><?php echo $ctgy['raw_material_name']; ?></option>
                                                    <?php } ?>
                                                </select>

                                            </div>



                                            <div class="col-sm-1 form-group mt-4 pt-2">
                                                <button class="btn btn-success" type="submit" name="search">Search</button>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Insert and Update Form -->




                <?php

            $reorder_qty="";
            $raw_material_id='';
            
            if(isset($_REQUEST['reorder_qty']))
            {

                //SELECT `raw_material_id`, `raw_material_unit_id`, `raw_material_name`, `raw_material_desc`, `raw_material_quantity`, `reorder_qty` FROM `master_raw_material` WHERE 1
                
                if(isset($_REQUEST["reorder_qty"])){
                    if($_REQUEST["reorder_qty"]!="")
                    {
                        $reorder_qty=$_REQUEST["reorder_qty"];
                    }
                }

                if(isset($_REQUEST["raw_material_id"])){
                    if($_REQUEST["raw_material_id"]!="")
                    {
                        $raw_material_id=$_REQUEST["raw_material_id"];
                    }
                }
                


 
                $flag=0;
                $q="SELECT * FROM master_raw_material ";
                if($reorder_qty!=""){
                    if($flag==0){
                       $q=$q." where reorder_qty='$reorder_qty'";
                       $flag=1;
                    }else{
                        $q=$q." and reorder_qty='$reorder_qty'";
                    }
                  }
                
                if($raw_material_id!=""){
                    if($flag==0){
                       $q=$q." where raw_material_id='$raw_material_id'";
                       $flag=1;
                    }else{
                        $q=$q." and raw_material_id='$raw_material_id'";
                    }
                  }
                  $q=$q." order by raw_material_name  ";
                                           
                
            ?>
 

                <!-- Display Table -->
                <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox">
                                <div class="ibox-head">
                                    <div class="ibox-title">Raw Materials List</div>
                                    <div class="ibox-tools">
                                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                    </div>
                                </div>
                                <div class="ibox-body">
                                <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Raw Material Name</th>
                                                <th>Description</th>
                                                <th>Unit</th>
                                                <th>Reorder Qty</th>
                                                <th>Quantity</th>
                                                <th>Update Reorder Qty</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                // Fetching data from master_raw_material table
                                                 
                                                $query1 = mysqli_query($conn, $q);
                                                
                                                while ($prd = mysqli_fetch_array($query1)) 
                                                {
                                                    $raw_material_id = $prd['raw_material_id'];
                                                    
                                                    $raw_material_unit_id = $prd['raw_material_unit_id'];
                                                    $sql_unit = mysqli_query($conn,"SELECT `raw_material_unit_name` FROM `master_raw_material_unit` WHERE `raw_material_unit_id` = '$raw_material_unit_id'");
                                                 
                                                    if ($unit = mysqli_fetch_array($sql_unit)) {


                                            ?>
                                                <tr>
                                                    <td><b><?php echo htmlspecialchars($prd['raw_material_name']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($prd['raw_material_desc']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($unit['raw_material_unit_name']); ?></b></td>
                                                    <td><b><?php echo htmlspecialchars($prd['reorder_qty']); ?></b></td>
                                                    <td> 
                                                        <?php
                                                        if($prd['reorder_qty']<=$prd['raw_material_quantity'])
                                                        {
                                                            $badge_success='badge-success';
                                                        }
                                                        else
                                                        {
                                                            $badge_success='badge-danger';
                                                        }
                                                        ?>
                                                            <span class="badge <?= $badge_success; ?>"><?php echo htmlspecialchars($prd['raw_material_quantity']); ?></span>
                                                        
                                                        
                                                    </td>
                                                   
                                                    <td>
                                                        <form action="" method="post"  id="open_id<?= $raw_material_id; ?>" style="display: none;">
                                                            <input type="hidden" name="update_raw_material_id" value="<?= $raw_material_id;?>" />
                                                            <input type="text" class="form-control" name="new_reorder_qty" value="<?php echo $prd['reorder_qty']; ?>" style="width:50px;display:inline-block">
                                                            <button class="btn btn-success" name="reorder_save">Save</button>
                                                        </form>
                                                    </td>

                                                  
                                                    <td>
                                                        <button class="btn btn-primary" onclick="update_reorder(<?= $raw_material_id; ?>);">Update Reorder</button>
                                                    </td>
                                                </tr>
                                            <?php
                                                    }
                                                }
                                            ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Display Table -->

            <?php
            }
            ?>



 
                                 
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
    
 
    <script>
    function update_reorder(x) {
        // Get all forms with ids starting with 'open_id'
        var forms = document.querySelectorAll('form[id^="open_id"]');

        // Hide all forms
        forms.forEach(function(form) {
            form.style.display = 'none';
        });

        // Display the selected form
        var open_id = document.getElementById('open_id' + x);
        open_id.style.display = 'block';
    }
</script>                    
 


</body>

</html>
