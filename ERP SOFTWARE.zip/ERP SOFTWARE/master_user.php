<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>

<?php
	if(isset($_POST['delete']))	
    {
        $user_id_to_delete = $_POST['user_id'];
        $sql_delete = "DELETE FROM `master_user` WHERE `user_id` = $user_id_to_delete";
    
        if (mysqli_query($conn, $sql_delete )) {
            $msg="Record deleted successfully";
        } else {
            $msg="Error deleting record: " . mysqli_error($conn);
        }
        header("location:master_user.php?msg=".$msg);
	}

    if(isset($_POST['submit']))
    {
        $role = $_POST['role'];
        $name_display = $_POST['name_display'];
        $address = $_POST['address'];
        $contact_no = $_POST['contact_no'];
        $designation = $_POST['designation'];
        $pan_no = $_POST['pan_no'];
        $date_of_join = $_POST['date_of_join']; 
        $salary = $_POST['salary'];
        $user_email = $_POST['user_email'];
        $user_name = $_POST['user_name'];
        $password = $_POST['password']; 
        $status = $_POST['status']; 
        // Insert query
        $sql = "INSERT INTO `master_user` (`role`, `name_display`, `address`, `contact_no`, `designation`, `pan_no`, `date_of_join`, `salary`, `user_email`, `user_name`, `password`, `status`) 
        VALUES ('$role', '$name_display', '$address', '$contact_no', '$designation', '$pan_no', '$date_of_join', '$salary', '$user_email', '$user_name', '$password', '$status')";

        if (mysqli_query($conn, $sql)) {
            $msg= "New Employee record created successfully";
        } else {
            $msg= "Error: " . $sql . "<br>" . mysqli_error($conn);
            
        }
        header("location:master_user.php?msg=".$msg);

 
	
    }

    if(isset($_POST['update']))
    {
                                                                        
        $user_id = $_POST['user_id'];
        $role = $_POST['role'];
        $name_display = $_POST['name_display'];
        $address = $_POST['address'];
        $contact_no = $_POST['contact_no'];
        $designation = $_POST['designation'];
        $pan_no = $_POST['pan_no'];
        $date_of_join = $_POST['date_of_join'];  
        $salary = $_POST['salary'];
        $user_email = $_POST['user_email'];
        $user_name = $_POST['user_name'];
        $password = $_POST['password'];  
        $status = $_POST['status']; 

        $sql = "UPDATE `master_user` SET 
        `role` = '$role',
        `name_display` = '$name_display',
        `address` = '$address',
        `contact_no` = '$contact_no',
        `designation` = '$designation',
        `pan_no` = '$pan_no',
        `date_of_join` = '$date_of_join',
        `salary` = '$salary',
        `user_email` = '$user_email',
        `user_name` = '$user_name',
        `password` = '$password',
        `status` = '$status'
        WHERE `user_id` = $user_id";

        if (mysqli_query($conn, $sql)) {
            $msg= "Employee record updated successfully";
        } else {
            $msg= "Error updating record: " . mysqli_error($conn);
        }

        header("location:master_user.php?msg=".$msg);
    }

 
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<title>User Master</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>
<?php
if (isset($_REQUEST['xedit'])) {
    $user_id = $_REQUEST['user_id'];
    $qre = mysqli_query($conn, "SELECT * FROM master_user WHERE user_id = '$user_id'");
    if ($fetch = mysqli_fetch_array($qre)) {
        // Fetching fields from `master_user`
        $user_id = $fetch['user_id'];
        $role = $fetch['role'];
        $name_display = $fetch['name_display'];
        $address = $fetch['address'];
        $contact_no = $fetch['contact_no'];
        $designation = $fetch['designation'];
        $pan_no = $fetch['pan_no'];
        $date_of_join = $fetch['date_of_join'];
        $salary = $fetch['salary'];
        $user_email = $fetch['user_email'];
        $user_name = $fetch['user_name'];
        $password = $fetch['password'];
        $status = $fetch['status'];
    }
}

?>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">EMPLOYEE MASTER</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
      








            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Upoad Employee</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <!--==================DISPLAY MASSAGE=============================-->
                            <?php include('includes/display_massage.php'); ?>
                            <!--==================DISPLAY MASSAGE=============================-->
                            <div class="ibox-body">
                            <form  action="" method="post" enctype="multipart/form-data" >
                                <input type="hidden" id="user_id" name="user_id" readonly="readonly" value="<?php if(isset($_REQUEST['xedit'])) { echo $user_id; } ?>" />

                                <div class="row">
                                    <div class="col-sm-3 form-group">
                                        <label>Employee Name <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="name_display" id="name_display" placeholder="Enter name" onkeyup="convert_data_to_upper(this);" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($name_display); } ?>" required>
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>Contact No <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="contact_no" id="contact_no" placeholder="Enter contact number" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($contact_no); } ?>" required>
                                    </div>

                                    <div class="col-sm-3 form-group">
                                        <label>Address <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="address" id="address" placeholder="Enter address" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($address); } ?>" required>
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>Designation <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="designation" id="designation" placeholder="Enter designation" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($designation); } ?>" required>
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>Salary <span class="text-danger">*</span></label>
                                        <input class="form-control" type="number" name="salary" id="salary" placeholder="Enter salary" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($salary); } ?>" required>
                                    </div>

                                    <!-- Select Option for Role -->
                                    <div class="col-sm-2 form-group">
                                        <label>Role <span class="text-danger">*</span></label>
                                        <select class="form-control" name="role" id="role" required>
                                            <option value="EMPLOYEE" <?php if(isset($_REQUEST['xedit']) && $role === 'employee') echo 'selected'; ?>>Employee</option>
                                        </select>
                                    </div>

                                    <!-- Additional Fields from master_user table -->
                                    <div class="col-sm-2 form-group">
                                        <label>PAN No</label>
                                        <input class="form-control" type="text" name="pan_no" id="pan_no" placeholder="Enter PAN number" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($pan_no); } ?>">
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>Date of Join</label>
                                        <input class="form-control" type="date" name="date_of_join" id="date_of_join" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($date_of_join); } ?>">
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>Email</label>
                                        <input class="form-control" type="email" name="user_email" id="user_email" placeholder="Enter email" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($user_email); } ?>">
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>User ID  <span class="text-danger">*</span> </label><br>
                                        
                                        <input class="form-control" type="text" minlength="5" name="user_name" id="user_name" placeholder="Enter user ID" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($user_name); } ?>" required>
                                        <span id="username-availability"></span>
                                    </div>

                                    <div class="col-sm-2 form-group">
                                        <label>Password  <span class="text-danger">*</span></label>
                                        <input class="form-control" type="password" name="password" id="password" placeholder="Enter password" value="<?php if(isset($_REQUEST['xedit'])) { echo htmlspecialchars($password); } ?>"  required>
                                    </div>
                                    <div class="col-sm-2 form-group">
                                        <label>Status  <span class="text-danger">*</span></label>
                                    
                                        <select class="form-control" name="status" id="status">
                                            <option value="1" <?php if(isset($_REQUEST['xedit']) && $status === '1') echo 'selected'; ?>>Active</option>
                                            <option value="0" <?php if(isset($_REQUEST['xedit']) && $status === '0') echo 'selected'; ?>>Inactive</option>
                                        </select>
                                    </div>

                                    <div class="col-sm-3 form-group mt-4 pt-2">
                                        <?php if(isset($_REQUEST['xedit'])) { ?>
                                            <button class="btn btn-warning" type="submit" name="update">Update</button>
                                        <?php } else { ?>
                                            <button class="btn btn-success" type="submit" name="submit">Submit</button>
                                        <?php } ?>
                                    </div>
                                </div>
                            </form> 




                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title">Project Details</div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Contact No</th>
                                        <th>Address</th>
                                        <th>Designation</th>
                                        <th>Salary</th>
                                        <th class="text-center">Action</th>
                                        <td>Status</td>
                                        <th class="text-center">Update / Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM `master_user` WHERE `role`='EMPLOYEE' ORDER BY `user_id`";
                                    $query = mysqli_query($conn, $sql);
                                    while ($employeeDetails = mysqli_fetch_array($query)) {
                                        
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($employeeDetails['name_display']); ?></td>
                                            <td><?php echo htmlspecialchars($employeeDetails['contact_no']); ?></td>
                                            <td><?php echo htmlspecialchars($employeeDetails['address']); ?></td>
                                            <td><?php echo htmlspecialchars($employeeDetails['designation']); ?></td>
                                            <td><?php echo htmlspecialchars($employeeDetails['salary']); ?></td>
                                            <td class="text-center">
                                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo $employeeDetails['user_id']; ?>">
                                                    <i class="fa fa-eye" aria-hidden="true"></i> View Details
                                                </button>
                                            </td>
                                            <td>
                                                
                                                <?php 
                                                if($employeeDetails['status']!=1)
                                                {
                                                    echo "<span class='badge badge-danger badge-pill m-r-5 m-b-5'>Inactive</span> ";
                                                }
                                                else
                                                {
                                                   
                                                    
                                                    echo "<span class='badge badge-success badge-pill m-r-5 m-b-5'>Active</span> ";
                                                }
                                                ?>
                                            </td>
                                            
                                            <td class="text-center">
                                            <?php
                                            if($employeeDetails['role']!='ADMIN')
                                            { 
                                            ?>
                                                <a href="master_user.php?xedit=1&user_id=<?php echo $employeeDetails['user_id'];?>"><i class="fa fa-pencil-square" aria-hidden="true" style="font-size:25px;"></i></a>
                                                <form method="post" action="" enctype="multipart/form-data" onsubmit="return myFunction();" style="display:inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $employeeDetails['user_id']; ?>" />
                                                    <button style="border:none; background:none; color:#007bff" type="submit" name="delete"><i class="fa fa-trash" aria-hidden="true" style="font-size:25px;"></i></button>
                                                </form>

                                            <?php
                                            }
                                            ?>
                                            </td>
                                        </tr>






 

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal<?php echo $employeeDetails['user_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                <div class="modal-header">
                                                <h5 class="modal-title" id="employeeModalLabel">Employee Details</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p><strong>Employee Name:</strong> <?php echo htmlspecialchars($employeeDetails['name_display']); ?></p>
                                                            <p><strong>Contact No:</strong> <?php echo htmlspecialchars($employeeDetails['contact_no']); ?></p>
                                                            <p><strong>Address:</strong> <?php echo htmlspecialchars($employeeDetails['address']); ?></p>
                                                            <p><strong>Designation:</strong> <?php echo htmlspecialchars($employeeDetails['designation']); ?></p>
                                                            <p><strong>Salary:</strong> <?php echo htmlspecialchars($employeeDetails['salary']); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><strong>Role:</strong>  <?php echo htmlspecialchars($employeeDetails['role']); ?> </p>
                                                            <p><strong>PAN No:</strong>  <?php echo htmlspecialchars($employeeDetails['pan_no']); ?> </p>
                                                            <p><strong>Date of Join:</strong>  <?php echo htmlspecialchars($employeeDetails['date_of_join']); ?> </p>
                                                            <p><strong>Email:</strong>  <?php echo htmlspecialchars($employeeDetails['user_email']); ?> </p>
                                                            <p><strong>User ID:</strong>  <?php echo htmlspecialchars($employeeDetails['user_name']); ?> </p>
                                                            <p><strong>Password:</strong>  <?php echo htmlspecialchars($employeeDetails['password']); ?> </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                </div>
                                                </div>
                                            </div>
                                        </div>



                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>


                            </div>
                        </div>
                    </div>

                </div>
                <style>
                    .visitors-table tbody tr td:last-child {
                        display: flex;
                        align-items: center;
                    }

                    .visitors-table .progress {
                        flex: 1;
                    }

                    .visitors-table .progress-parcent {
                        text-align: right;
                        margin-left: 10px;
                    }
                </style>

            </div>



 
         
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
    <script>
    $(document).ready(function(){
        $('#user_name').keyup(function(){
            var username = $(this).val();
            if(username.length >= 5) { // Check only if username length is 3 or more
                $.ajax({
                    url: 'check_username.php', // PHP script to handle the AJAX request
                    method: 'POST',
                    data: {username: username},
                    success: function(data){
                        $('#username-availability').html(data); // Show response from server
                    }
                });
            } else {
                $('#username-availability').html('(Max 5 Character)'); // Clear message if username is too short
            }
        });
    });
    </script>
</body>

</html>
