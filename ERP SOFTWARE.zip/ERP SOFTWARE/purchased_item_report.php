<?php include('db/conn.php');?>
<?php include('db/sequre_page.php');?>
<?php
if(isset($_POST['delete']))	
{
    $purchased_id=$_POST['purchased_id'];
       
    $query1=mysqli_query($conn,"DELETE FROM purchased_item WHERE purchased_id='$purchased_id'");
        if($query1)
        {
            $query2=mysqli_query($conn,"DELETE FROM purchased_item_details WHERE purchased_id='$purchased_id'");    
            if($query2)
            {
                header("location:purchased_item_report.php?msg=Successfully deleted");   
            }
        }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>PURCHASED ITEM REPORT</title>
<?php include('includes/dashboard_link_css.php');?>
<script>
    /*USEFUL DEFAULT FUNCTION*/
    //DeleteRecheck
    //convert_data_to_upper
    //check_numeric
    //check_decimal
</script>

</head>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
            <?php include('includes/dashboard_header.php');?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">

            <!--=========== Start Indigator Bar===============================-->
            <div class="row pt-2 text-center dashboard-header-color">
                <div class="col-lg-12">
                   <h4 class="dashboard-page-heading">Purchased Item Report</h4>
                </div>
            </div>
            <!--=========== End Indigator Bar===============================-->
            <!-- START PAGE CONTENT-->
                      <!-- Insert and Update Form -->
                <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="ibox">
                                <div class="ibox-head">
                                    <div class="ibox-title">Purchased Items Search</div>
                                    <div class="ibox-tools">
                                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                    </div>
                                </div>
                                <div class="ibox-body">
                                    <!-- Display Messages -->
                                    <?php include('includes/display_massage.php'); ?>

                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="row">
 
                                            <div class="col-sm-2 form-group">
                                                <label>From Date </label>
                                                <input class="form-control" type="date" name="from_date" id="from_date" placeholder="" value="<?php if(isset($_REQUEST['from_date'])) { echo $_REQUEST['from_date']; } ?>" >
                                            </div>
                                            <div class="col-sm-2 form-group">
                                                <label>To Date </label>
                                                <input class="form-control" type="date" name="to_date" id="to_date" placeholder="" value="<?php if(isset($_REQUEST['to_date'])) { echo $_REQUEST['to_date']; } ?>" >
                                            </div>
                                            <div class="col-sm-3 form-group">
                                                <label>Invoice No.</label>
                                                <input class="form-control" type="text" name="invoice_no" id="invoice_no" placeholder="Enter Invoice No." value="<?php if(isset($_REQUEST['invoice_no'])) { echo $_REQUEST['invoice_no']; } ?>" >
                                            </div>
                                            <div class="col-lg-4 form-group">
                                                <label>Vendor </label>
                                                <select class="form-control" name="vendor_id" id="vendor_id">
                                                    <option value="" selected disabled="none">Choose Name</option>
                                                    <?php
                                                    $sql_ctgy = "SELECT * FROM `master_vendor` WHERE 1";
                                                    $query_ctgy = mysqli_query($conn, $sql_ctgy);
                                                    while ($ctgy = mysqli_fetch_array($query_ctgy)) { ?>
                                                        <option value="<?php echo $ctgy['vendor_id']; ?>"<?php  if(isset($_REQUEST['vendor_id'])) { if($_REQUEST['vendor_id']==$ctgy['vendor_id']) {  echo  "selected";}} ?>  ><?php echo $ctgy['vendor_name']; ?></option>
                                                    <?php } ?>
                                                </select>

                                            </div>



                                            <div class="col-sm-1 form-group mt-4 pt-2">
                                                <button class="btn btn-success" type="submit" name="search">Search</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Insert and Update Form -->




            <?php
            $from_date="";
            $to_date="";
            $invoice_no="";
            $vendor_id='';
            if(isset($_REQUEST['from_date']))
            {
                
                if(isset($_REQUEST["from_date"])){
                    if($_REQUEST["from_date"]!="")
                    {
                        $from_date=$_REQUEST["from_date"];
                    }
                }
                if(isset($_REQUEST["to_date"])){
                    if($_REQUEST["to_date"]!="")
                    {
                        $to_date=$_REQUEST["to_date"];
                    }
                }
                if(isset($_REQUEST["invoice_no"])){
                    if($_REQUEST["invoice_no"]!="")
                    {
                        $invoice_no=$_REQUEST["invoice_no"];
                    }
                }

                if(isset($_REQUEST["vendor_id"])){
                    if($_REQUEST["vendor_id"]!="")
                    {
                        $vendor_id=$_REQUEST["vendor_id"];
                    }
                }

                   //SELECT `purchased_id`, `vendor_id`, `invoice_no`, `invoice_date`, `invoice_amount`, `cgst_amt`, `sgst_amt`, `igst_amt`, `entry_date` FROM `purchased_item` WHERE 1
                $flag=0;
                $q="SELECT * FROM purchased_item ";
                if($invoice_no!=""){
                    if($flag==0){
                       $q=$q." where invoice_no='$invoice_no'";
                       $flag=1;
                    }else{
                        $q=$q." and invoice_no='$invoice_no'";
                    }
                  }
                if($from_date!=""){
                    if($flag==0){
                    $q=$q." where str_to_date(invoice_date,'%Y-%m-%d')>=str_to_date('".$from_date."','%Y-%m-%d') ";
                    $flag=1;
                        }else
                            $q=$q." and str_to_date(invoice_date,'%Y-%m-%d')>=str_to_date('".$from_date."','%Y-%m-%d') ";
                }
        
                if($to_date!=""){
                    if($flag==0){
                        $q=$q."  where str_to_date(invoice_date,'%Y-%m-%d')<=str_to_date('".$to_date."','%Y-%m-%d') ";
                    $flag=1;
                    }else
                        $q=$q."  and str_to_date(invoice_date,'%Y-%m-%d')<=str_to_date('".$to_date."','%Y-%m-%d') ";
                } 

                if($vendor_id!=""){
                    if($flag==0){
                       $q=$q." where vendor_id='$vendor_id'";
                       $flag=1;
                    }else{
                        $q=$q." and vendor_id='$vendor_id'";
                    }
                  }
                  $q=$q." order by invoice_date desc";
                                           
                
            ?>
 
            <div class="page-content fade-in-up">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox">
                                <div class="ibox-head">
                                    <div class="ibox-title"> Purchased Items Details</div>
                                    
                                </div>
                        
                                <div class="ibox-body">

                                    <div class="row">
                                        <div class="col-lg-12">
                                            
                                            <div class="row">
                                                <div class="text-center" style="width:12.5%"><b>Date</b></div>
                                                <div class="text-center" style="width:20%"><b>Invoice No</b></div>
                                                <div class="text-center" style="width:30%"><b>Vendor</b></div>
                                                <div class="text-center" style="width:12.5%"><b>Invoice Amount</b></div>
                                                <div class="text-center" style="width:12.5%"><b>Details</b></div>
                                                <div class="text-center" style="width:12.5%"><b>Action</b></div>
                                            </div>



                                            
                                            <?php
                                                //SELECT `purchased_id`, `vendor_id`, `invoice_no`, `invoice_date`, `invoice_amount`, `cgst_amt`, `sgst_amt`, `igst_amt`, `entry_date` FROM `purchased_item` WHERE 1
                                                   
                                                    $query11=mysqli_query($conn,$q);
                                                    while($fetch11=mysqli_fetch_array($query11)) 
                                                    {
                                                        $purchased_id=$fetch11['purchased_id'];
                                                        $invoice_no=$fetch11['invoice_no'];
                                                        $invoice_date=$fetch11['invoice_date'];
                                                        $invoice_amount=$fetch11['invoice_amount'];
                                                        $cgst_amt=$fetch11['cgst_amt'];
                                                        $sgst_amt=$fetch11['sgst_amt'];
                                                        $igst_amt=$fetch11['igst_amt'];
                                                        $entry_date=$fetch11['entry_date'];
                                                        $vendor_id=$fetch11['vendor_id'];
                                                    

                                                        $sql10="SELECT * FROM master_vendor where vendor_id='$vendor_id'";
                                                        $query10=mysqli_query($conn,$sql10);
                                                        if($fetch10=mysqli_fetch_array($query10)) 
                                                        {
                                                            //SELECT `vendor_id`, `vendor_name`, `vendor_person_name`, `vendor_address`, `vendor_contact_no`, `vendor_state`, `vendor_state_code`, `vendor_gst` FROM `master_vendor` WHERE 1
                                                            $vendor_name= $fetch10["vendor_name"];
                                                            $vendor_person_name= $fetch10["vendor_state"];
                                                            $vendor_address= $fetch10["vendor_address"];
                                                            $vendor_contact_no= $fetch10["vendor_contact_no"];
                                                            $vendor_state= $fetch10["vendor_state"];
                                                            $vendor_state_code= $fetch10["vendor_state"];
                                                            $vendor_gst= $fetch10["vendor_gst"];
                                                        }

        
                                                        $total_raw_qty=0;
                                                        $sql9="SELECT sum(raw_material_quantity) total_raw_qty FROM purchased_item_details WHERE  purchased_id='$purchased_id'";
                                                        $query9=mysqli_query($conn,$sql9);
                                                        if($fetch9=mysqli_fetch_array($query9)) 
                                                        {
                                                        //SELECT `purchased_item_details_id`, `purchased_id`, `raw_material_id`, `raw_material_quantity`, `raw_matarial_rate`, `raw_matarial_amount` FROM `purchased_item_details` WHERE 1
                                                        $total_raw_qty=$fetch9['total_raw_qty'];
                                                        }
                                                        

                                                ?>

                                            <div class="row bg-primary text-white mt-3 pb-1 pt-1" style="border:1px solid #000;">
                                                <div class="text-center" style="width:12.5%;"><b><?php echo (new DateTime($invoice_date))->format('d/m/Y');?></b></div>
                                                <div class="text-center" style="width:20%;"><b><?php echo $invoice_no;?></b></div>
                                                <div class="text-center" style="width:30%;"><b><?php echo $vendor_name;?></b></div>
                                                
                                                <div class="text-right" style="width:12.5%;"><b>
                                                    CGST - <?php echo $cgst_amt;?> <br>
                                                    SGST - <?php echo $sgst_amt;?> <br>
                                                    IGST - <?php echo $igst_amt;?> <br>
                                                    Amount - <?php echo $invoice_amount;?>
                                                </b></div>
                                                <div class="text-center" style="width:12.5%;"><button type="button" class="btn" onclick="toggleDiv(<?php echo $purchased_id;?>)">View</button></th></div>
                                                <div class="text-center" style="width:12.5%;">
                                                    <form action="" method="post" onsubmit="return DeleteRecheck();">
                                                            <input type="hidden" value="<?php echo $purchased_id;?>" name="purchased_id">
                                                           
                                                            <a  href="purchased_item_update.php?page_redirect=report&purchased_id=<?= $purchased_id?>&from_date=<?= $from_date?>&to_date=<?= $to_date?>&invoice_no=<?= $invoice_no?>&vendor_id=<?= $vendor_id?> "><i class="fa fa-pencil-square text-white" aria-hidden="true" style="font-size:25px;"></i></a>

                                                            <button style="border:none;  color:#007bff; background:transparent;" type="submit" name="delete"><i class="fa fa-trash text-white" aria-hidden="true" style="font-size:25px;"></i></button>
                                                    </form> 
                                                </div>
                                            </div>


                                            <div class="row" id="menu<?php echo $purchased_id;?>" style="display: none;">
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="text-center col-4" style="border:1px solid black;"><b>Raw Material</b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b>Quantity</b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b>Unit</b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b>Rate</b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b>Amount</b></div>
                                                    </div>
                                                    
                                                </div>
                                           

                                                <?php
                                                //SELECT `purchased_item_details_id`, `purchased_id`, `raw_material_id`, `raw_material_quantity`, `raw_matarial_rate`, `raw_matarial_amount` FROM `purchased_item_details` WHERE 1
                                                $raw_matarial_total_amount=0;
                                                $sql12="SELECT * FROM purchased_item_details WHERE purchased_id='$purchased_id'";
                                                $query12=mysqli_query($conn,$sql12);
                                                while($fetch12=mysqli_fetch_array($query12)) 
                                                {
                                                //`id`, `purchased_id`, `raw_material_id`, `raw_matarial_quantity`, `raw_matarial_desc` SELECT * FROM `direct_purchase_order_details` WHERE 1
                                                $raw_material_id=$fetch12['raw_material_id'];
                                                $raw_material_quantity=$fetch12['raw_material_quantity'];
                                                $raw_matarial_rate=$fetch12['raw_matarial_rate'];
                                                $raw_matarial_amount=$fetch12['raw_matarial_amount'];
                                                $raw_matarial_total_amount += $raw_matarial_amount;

                                                    $sql13="SELECT * FROM master_raw_material WHERE raw_material_id='$raw_material_id'";
                                                    $query13=mysqli_query($conn,$sql13);
                                                    if($fetch13=mysqli_fetch_array($query13)) 
                                                    {
                                                        $raw_material_name=$fetch13['raw_material_name'];
                                                        $raw_material_unit_id=$fetch13['raw_material_unit_id'];
                                                    }
                                                    $sql14="SELECT * FROM master_raw_material_unit WHERE raw_material_unit_id='$raw_material_unit_id'";
                                                    $query14=mysqli_query($conn,$sql14);
                                                    if($fetch14=mysqli_fetch_array($query14)) 
                                                    {
                                                        $raw_material_unit_name=$fetch14['raw_material_unit_name'];
                                                    }

                                                ?>

 
                                                <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="text-center col-4" style="border:1px solid black;"><?php echo $raw_material_name;?></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><?php echo $raw_material_quantity;?></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><?php echo $raw_material_unit_name;?></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><?php echo $raw_matarial_rate;?></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><?php echo $raw_matarial_amount;?></div>
                                                    </div>
                                                    
                                                </div>


                                                <?php
                                                }
                                                ?>

                                                <div class="col-lg-12 bg-primary text-white">
                                                    <div class="row">
                                                        <div class="text-center col-4" style="border:1px solid black;"><b></b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b></b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b></b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b>Total</b></div>
                                                        <div class="text-center col-2" style="border:1px solid black;"><b><?php echo $raw_matarial_total_amount;?></b></div>
                                                    </div>
                                                    
                                                </div>

               

                                            </div>

                                            <?php
                                            }
                                            ?>


                                 
                                        </div>


            
                                        


                   

                                 

                                    </div>
                                    
                                </div>
                            </div>     
                        </div>
                    </div>          
            </div>   

            <?php
            }
            ?>



 
                                 
            <!-- END PAGE CONTENT-->
            <?php include('includes/dashboard_footer.php');?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    <?php include('includes/dashboard_theme_setting.php');?>
    <!-- END THEME CONFIG PANEL-->

    <!-- CORE PLUGINS-->
    <?php include('includes/dashboard_link_script.php');?>
    
 
    <script>
        function toggleDiv(x) {
            

            var menu = document.getElementById('menu' + x);

            if (menu.style.display === 'none') {
                menu.style.display = 'block';

            } else {
                menu.style.display = 'none';
            }
        }
    </script>                            
 


</body>

</html>
