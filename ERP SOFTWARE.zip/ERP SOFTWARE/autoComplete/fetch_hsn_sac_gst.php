<?php
include_once("../db/conn.php");

$hsn_sac_code = null;
$gst_rate = 0;
if ($_GET['prod_id'] == "") {
    echo $hsn_sac_code . ',' . $gst_rate;
}
if (isset($_GET['prod_id'])) {
    $prod_id = $_GET['prod_id'];
    $query = "SELECT hsn_sac_code, gst_rate FROM master_finished_product JOIN master_hsn_sac_code ON master_finished_product.hsn_sac_id = master_hsn_sac_code.hsn_sac_id WHERE master_finished_product.prod_id = $prod_id";

    try {
        $result = mysqli_query($conn, $query);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $hsn_sac_code = $row["hsn_sac_code"];
                $gst_rate = $row["gst_rate"];
                echo $hsn_sac_code . ',' . $gst_rate;
            } else {
                echo $hsn_sac_code . ',' . $gst_rate;
            }
        } else {
            echo $hsn_sac_code . ',' . $gst_rate;
        }
    } catch (mysqli_sql_exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo $hsn_sac_code . ',' . $gst_rate;
}
