$(document).ready(function () {
  function calculateAmounts(current_row) {
    const quantity = parseInt(current_row.find(".quantity-input").val()) || 0;
    const rate = parseFloat(current_row.find(".rate").val()) || 0;
    const per = parseFloat(current_row.find(".per_value").val()) || 1;
    const gst_rate = parseFloat(current_row.find(".gst_rate").val()) || 0;

    const taxableAmount = quantity * rate * per;
    current_row.find(".tax-amt-input").val(taxableAmount.toFixed(2));

    const cgstRate = gst_rate;
    const cgstAmount = (taxableAmount * cgstRate) / 100;
    current_row.find(".cgst-amt-input").val(cgstAmount.toFixed(2));

    const sgstRate = gst_rate;
    const sgstAmount = (taxableAmount * sgstRate) / 100;
    current_row.find(".sgst-amt-input").val(sgstAmount.toFixed(2));

    const totalAmount = taxableAmount + cgstAmount + sgstAmount;
    current_row.find(".total-amt-input").val(totalAmount.toFixed(2));

    updateGrandTotal();
  }

  function updateGrandTotal() {
    let grandTotalQty = 0;
    let grandTotalTaxAmt = 0;
    let grandTotalCgstAmt = 0;
    let grandTotalSgstAmt = 0;
    let grandTotalAmt = 0;

    for (let i = 1; i <= 5; i++) {
      const row = $("#row" + i);
      grandTotalQty += parseInt(row.find("#qty1").val()) || 0;
      grandTotalTaxAmt += parseFloat(row.find(".tax-amt-input").val()) || 0;
      grandTotalCgstAmt += parseFloat(row.find(".cgst-amt-input").val()) || 0;
      grandTotalSgstAmt += parseFloat(row.find(".sgst-amt-input").val()) || 0;
      grandTotalAmt += parseFloat(row.find(".total-amt-input").val()) || 0;
    }

    $(".grand-total-qty").val(grandTotalQty);
    $(".grand-total-tax-amt").val(grandTotalTaxAmt.toFixed(2));
    $(".grand-total-cgst-amt").val(grandTotalCgstAmt.toFixed(2));
    $(".grand-total-sgst-amt").val(grandTotalSgstAmt.toFixed(2));
    $(".grand-total-amt").val(grandTotalAmt.toFixed(2));
  }

  $(document).on("input", ".rate, .quantity-input, .per_value", function () {
    var current_row = $(this).closest(".row");
    calculateAmounts(current_row);
  });

  $(document).on("change", ".prod_name", function () {
    var prod_id = $(this).val();
    var current_row = $(this).closest(".row");

    $.ajax({
      url: "autoComplete/fetch_hsn_sac_gst.php",
      type: "GET",
      data: { prod_id: prod_id },
      success: function (response) {
        var data = response.split(",");
        current_row.find(".hsn_sac_code").val(data[0]);
        var gst_rate = parseFloat(data[1]) / 2;
        current_row.find(".gst_rate").val(gst_rate.toFixed(2));

        current_row.find(".quantity-input, .rate, .per_value").trigger("input");
      },
      error: function (xhr, status, error) {
        console.error(xhr.responseText);
      },
    });
  });
});

