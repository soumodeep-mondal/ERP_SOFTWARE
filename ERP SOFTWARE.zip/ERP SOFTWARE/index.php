<?php header('location:includes/login.php'); ?>
<?php //header('location:dashboard_index.php'); ?>