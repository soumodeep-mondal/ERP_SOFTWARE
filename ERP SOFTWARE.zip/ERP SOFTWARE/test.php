<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check user_name Availability</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<form id="userForm" action="submit.php" method="post">
    user_name: <input type="text" id="user_name" name="user_name">
    <span id="user_nameError" style="color: red;"></span><br>
    <input type="submit" value="Submit">
</form>

<script>
$(document).ready(function() {
    $('#userForm').submit(function(event) { // Capture form submission
        event.preventDefault(); // Prevent default form submission

        var user_name = $('#user_name').val();
        $.ajax({
            url: 'check_username.php', // PHP file to check user_name availability
            type: 'post',
            data: {user_name: user_name},
            success: function(response) {
                if (response === "") {
                    // user_name is available, allow form submission
                    $('#userForm')[0].submit(); // Submit the form programmatically
                    // return true;
                    // run submit event 
                    // $('#userForm').trigger('submit');
                } else {
                    // user_name already exists, display error message
                    $('#user_nameError').text(response);
                }
            }
        });
    });
});
</script>

</body>
</html>
