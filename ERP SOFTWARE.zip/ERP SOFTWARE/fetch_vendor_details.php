<?php
include('db/conn.php');

if (isset($_POST['vendor_id'])) {
    $vendor_id = $_POST['vendor_id'];
    
    $sql = "SELECT vendor_person_name, vendor_contact_no, vendor_gst, vendor_address FROM vendor_master WHERE vendor_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $vendor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $vendor = $result->fetch_assoc();
        echo json_encode($vendor);
    } else {
        echo json_encode([]);
    }
}
?>
