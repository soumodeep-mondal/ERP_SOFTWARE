<?php
session_start();
if(isset($_SESSION['user_id']))	
{
  $user_id_session=$_SESSION['user_id'];	   
}	
else
{
 header("location:index.php");
}
?>
<?php
/*==========MUST BE UPDATE============================*/
$INFO_COMPANY_NAME="SKC INVOICE";
$INFO_COMPANY_URL="https://erp_software.in/";
$INFO_SOFTWARE_BUILD_YEAR="2024";
$INFO_DESIGN_DEVELOPED_SOFTWARE_COMPANY="SKC INFOTECH";
$INFO_DESIGN_DEVELOPED_SOFTWARE_COMPANY_URL="https://skcinfotech.in/";
/*==========MUST BE UPDATE============================*/
?>