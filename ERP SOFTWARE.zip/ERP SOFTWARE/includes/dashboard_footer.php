<footer class="page-footer">
    <div class="font-13"><?php echo $INFO_SOFTWARE_BUILD_YEAR; ?> © <b><?php echo $INFO_COMPANY_NAME;?></b> - All Rights Reserved.</div>
    <a class="px-4" href="" target="_blank">DESIGN & DEVELOPED BY <?php echo $INFO_DESIGN_DEVELOPED_SOFTWARE_COMPANY; ?></a>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer>
