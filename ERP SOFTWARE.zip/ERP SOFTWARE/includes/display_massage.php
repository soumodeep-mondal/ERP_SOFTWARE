    <?php
    if(isset($_GET["succ"]))
    {
        echo 
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>' . $_GET["succ"] . '</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>';
    }
    if(isset($_GET["err"]))
    {
        echo 
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>' . $_GET["err"] . '</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>';
    }
    ?>