<?php
include_once("../db/conn.php");

if(isset($_POST['register_request']))
{
	$user_name=trim($_POST['user_name']);
	$password=trim($_POST['password']);
	//insert 
	$sql="INSERT INTO `user_master`(`user_name`, `password`) VALUES ('$user_name','$
	$password')";
	$result=mysqli_query($conn,$sql);
	if($result)
	{
		header("location:login.php?msg=Successfully Registered! Please Login.");
	}
	else
	{
		header("location:register.php?msg=User Already Exists");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="../image/png" href="../dashboard_source/assets/img/favicon.png"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="../dashboard_source/assets/css/login.css">
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic " >
					<img src="../dashboard_source/assets/img/login_logo.png" width="100%" alt="IMG">
				</div>

				<form action="" method="POST" class="login100-form validate-form">
					<span class="login100-form-title">
						Register
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="user_name" id="user_name" placeholder="User ID">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="password" id="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div style="text-align:center; color:red;">
						
						<?php
						if(isset($_GET['msg'])) 
						{
							 echo "<h5>".$_GET['msg']."</h5>";
						}
						?>
					</div>


					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="register_request">
							Submit
						</button>
					</div>

					<!--
					<div class="text-center p-t-12">
						<span class="txt1">
							Forgot
						</span>
						<a class="txt2" href="#">
							Password
						</a>
					</div>
					-->
					
					<div class="text-center p-t-136">
					<!--<a class="txt2" href="sskm-admin-register.php">
							Register Now
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					-->
					</div>
					
				</form>
			</div>
		</div>
	</div>
	
 

</body>
</html>