    <!-- CORE PLUGINS-->
    <script src="./dashboard_source/assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="./dashboard_source/assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="./dashboard_source/assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="./dashboard_source/assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="./dashboard_source/assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <script src="./dashboard_source/assets/vendors/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
 
    <!-- CORE SCRIPTS-->
    <script src="dashboard_source/assets/js/app.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script src="./dashboard_source/assets/js/scripts/dashboard_1_demo.js" type="text/javascript"></script>

    <script src="./dashboard_source/assets/js/dashboard.js" type="text/javascript"></script>

 