<?php
include_once("../db/conn.php");

    if(isset($_POST['login_request']))
    {
        $user_name=trim($_POST['user_name']);
        $password=trim($_POST['password']);
   

        $sql="SELECT *  FROM master_user WHERE user_name='$user_name'";
        $query=mysqli_query($conn,$sql);
        $num=mysqli_num_rows($query);
        if($num>0)
        {
            if($fetch=mysqli_fetch_array($query))
            {
                if($password==$fetch['password'])
                {
                    session_start();
                    $_SESSION['user_id']=$fetch['user_id'];
                    header("location:../dashboard_index.php");
                }
            }
            else
            {
            header("location:login.php?msg=Invalide Password");
            }
        }
        else
        {
            header("location:login.php?msg=Invalide User");
        }
    }
?>