        <?php
        // Assuming $conn is your database connection object

        // Query to fetch data from master_user table
        $header_query = mysqli_query($conn,"SELECT * FROM `master_user` WHERE user_id='$user_id_session'");

            // Fetch data row by row
            if ($fetch_header_info = mysqli_fetch_assoc($header_query)) {
                // Access individual columns from $row
                $header_user_id = $fetch_header_info['user_id'];
                $header_role = $fetch_header_info['role'];
                $header_name_display = $fetch_header_info['name_display'];
                $header_address = $fetch_header_info['address'];
                $header_contact_no = $fetch_header_info['contact_no'];
                $header_designation = $fetch_header_info['designation'];
                $header_pan_no = $fetch_header_info['pan_no'];
                $header_date_of_join = $fetch_header_info['date_of_join'];
                $header_salary = $fetch_header_info['salary'];
                $header_user_email = $fetch_header_info['user_email'];
                $header_user_name = $fetch_header_info['user_name'];
                $header_password = $fetch_header_info['password'];
                $header_profile_picture = $fetch_header_info['profile_picture'];
                $header_status = $fetch_header_info['status'];
            }

        ?>
        
        
        
        <header class="header">
            <div class="page-brand">
                <a class="link" href="index.html">
                    <span class="brand"><?php echo $INFO_COMPANY_NAME;?> </span>
                    <span class="brand-mini"><?php echo substr($INFO_COMPANY_NAME,0,2);?></span>
                </a>
            </div>
            <div class="flexbox flex-1">
                <!-- START TOP-LEFT TOOLBAR-->
                <ul class="nav navbar-toolbar">
                    <li>
                        <a class="nav-link sidebar-toggler js-sidebar-toggler"><i class="ti-menu"></i></a>
                    </li>

                  
                    <li class="header-name pt-2">
                        <h3><b><?php echo $INFO_COMPANY_NAME;?></b></h3>
                    </li>

                    <!--
                     <li>
                        <form class="navbar-search" action="javascript:;">
                            <div class="rel">
                                <span class="search-icon"><i class="ti-search"></i></span>
                                <input class="form-control" placeholder="Search here...">
                            </div>
                        </form>
                      
                    </li> -->
                </ul>  
                <!-- END TOP-LEFT TOOLBAR-->
                <!-- START TOP-RIGHT TOOLBAR-->
              
                <ul class="nav navbar-toolbar">
                    <!--
                    <li class="dropdown dropdown-inbox">
                        <a class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope-o"></i>
                            <span class="badge badge-primary envelope-badge">9</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right dropdown-menu-media">
                            <li class="dropdown-menu-header">
                                <div>
                                    <span><strong>9 New</strong> Messages</span>
                                    <a class="pull-right" href="mailbox.html">view all</a>
                                </div>
                            </li>
                            <li class="list-group list-group-divider scroller" data-height="240px" data-color="#71808f">
                                <div>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <img src="./assets/img/users/u1.jpg" />
                                            </div>
                                            <div class="media-body">
                                                <div class="font-strong"> </div>Jeanne Gonzalez<small class="text-muted float-right">Just now</small>
                                                <div class="font-13">Your proposal interested me.</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <img src="./assets/img/users/u2.jpg" />
                                            </div>
                                            <div class="media-body">
                                                <div class="font-strong"></div>Becky Brooks<small class="text-muted float-right">18 mins</small>
                                                <div class="font-13">Lorem Ipsum is simply.</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <img src="./assets/img/users/u3.jpg" />
                                            </div>
                                            <div class="media-body">
                                                <div class="font-strong"></div>Frank Cruz<small class="text-muted float-right">18 mins</small>
                                                <div class="font-13">Lorem Ipsum is simply.</div>
                                            </div>
                                        </div>
                                    </a>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <img src="./assets/img/users/u4.jpg" />
                                            </div>
                                            <div class="media-body">
                                                <div class="font-strong"></div>Rose Pearson<small class="text-muted float-right">3 hrs</small>
                                                <div class="font-13">Lorem Ipsum is simply.</div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown dropdown-notification">
                        <a class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell-o rel"><span class="notify-signal"></span></i></a>
                        <ul class="dropdown-menu dropdown-menu-right dropdown-menu-media">
                            <li class="dropdown-menu-header">
                                <div>
                                    <span><strong>5 New</strong> Notifications</span>
                                    <a class="pull-right" href="javascript:;">view all</a>
                                </div>
                            </li>
                            <li class="list-group list-group-divider scroller" data-height="240px" data-color="#71808f">
                                <div>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <span class="badge badge-success badge-big"><i class="fa fa-check"></i></span>
                                            </div>
                                            <div class="media-body">
                                                <div class="font-13">4 task compiled</div><small class="text-muted">22 mins</small></div>
                                        </div>
                                    </a>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <span class="badge badge-default badge-big"><i class="fa fa-shopping-basket"></i></span>
                                            </div>
                                            <div class="media-body">
                                                <div class="font-13">You have 12 new orders</div><small class="text-muted">40 mins</small></div>
                                        </div>
                                    </a>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <span class="badge badge-danger badge-big"><i class="fa fa-bolt"></i></span>
                                            </div>
                                            <div class="media-body">
                                                <div class="font-13">Server #7 rebooted</div><small class="text-muted">2 hrs</small></div>
                                        </div>
                                    </a>
                                    <a class="list-group-item">
                                        <div class="media">
                                            <div class="media-img">
                                                <span class="badge badge-success badge-big"><i class="fa fa-user"></i></span>
                                            </div>
                                            <div class="media-body">
                                                <div class="font-13">New user registered</div><small class="text-muted">2 hrs</small></div>
                                        </div>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    -->

                    <li class="dropdown dropdown-user">
                        <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                            <img src="dashboard_source/assets/img/admin-avatar.png" />
                            <span></span><?php echo $header_name_display;?><i class="fa fa-angle-down m-l-5"></i></a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="profile.php"><i class="fa fa-user"></i>Profile</a>
                            <a class="dropdown-item" href="change_password.php"><i class="fa fa-cog"></i>Change Password</a>
                            <!-- <a class="dropdown-item" href="javascript:;"><i class="fa fa-support"></i>Support</a> -->
                            <!-- <li class="dropdown-divider"></li> -->
                            <a class="dropdown-item" href="login.html"><i class="fa fa-power-off"></i>Logout</a>
                        </ul>
                    </li>
                </ul>
            
                <!-- END TOP-RIGHT TOOLBAR-->
            </div>















 
        </header>
        <!-- END HEADER-->
        <!-- START SIDEBAR-->
        <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                    <div>
                        <img src="dashboard_source/assets/img/admin-avatar.png" width="45px" />
                    </div>
                    <div class="admin-info">
                        <div class="font-strong"><?php echo substr($header_name_display,0,strpos($header_name_display, ' '));?></div>
                        <small><?php echo strtoupper($header_designation);?></small></div>
                </div>
                <ul class="side-menu metismenu">
                    <?php 
                        $C_P ="";
                        $C_P = basename($_SERVER['PHP_SELF']);
                    ?>
                    <li>
                        <a class="<?php if($C_P=='dashboard_index.php'){ echo "active"; } ?>" href="dashboard_index.php"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">MENU</li>


                <?php
                if(strcmp(strtoupper($header_role),"ADMIN")==0)
                { 
                ?>

                    <!-- =======================================================================MASTERS================================================================================ -->
                    <li class="<?= in_array($C_P, ['master_customer.php', 'master_vendor.php', 'master_raw_material.php', 'master_raw_material_unit.php', 'master_user.php', 'master_user_department_access.php']) ? 'active' : '' ?>">
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Masters</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="master_customer.php"  class="<?php if($C_P=='master_customer.php'){ echo "active"; } ?>">Customer</a>
                            </li>
                            <li>
                                <a href="master_vendor.php"  class="<?php if($C_P=='master_vendor.php'){ echo "active"; } ?>">Vendor</a>
                            </li>
                            <li>
                                <a href="master_user.php"  class="<?php if($C_P=='master_user.php'){ echo "active"; } ?>">Users</a>
                            </li>
                            <li>
                                <a href="master_user_department_access.php"  class="<?php if($C_P=='master_user_department_access.php'){ echo "active"; } ?>">Access Master</a>
                            </li>
                            <li>
                                <a href="master_raw_material.php"  class="<?php if($C_P=='master_raw_material.php'){ echo "active"; } ?>">Raw Metrial</a>
                            </li>
                            <li>
                                <a href="master_raw_material_unit.php"  class="<?php if($C_P=='master_raw_material_unit.php'){ echo "active"; } ?>">Raw Metrial Unit</a>
                            </li>
                        </ul>
                    </li>
                    <!-- =======================================================================MASTERS================================================================================ -->
                    
                    <!-- =======================================================================PURCHASE================================================================================ -->
                    <li class="<?= in_array($C_P, ['purchased_item.php', 'purchased_item_report.php', 'purchased_item_update.php']) ? 'active' : '' ?>">
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Purchase</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="purchased_item.php"  class="<?php if($C_P=='purchased_item.php' || $C_P=='purchased_item_update.php' ){ echo "active"; } ?>">Purchased Item Entry</a>
                            </li>
 
                            <li class="<?= in_array($C_P, ['purchased_item_report.php']) ? 'active' : '' ?>">
                                <a href="javascript:;">
                                    <span class="nav-label">Report</span><i class="fa fa-angle-left arrow"></i></a>
                                <ul class="nav-3-level collapse">
                                    <li>
                                        <a href="purchased_item_report.php" class="<?php if($C_P=='purchased_item_report.php'){ echo "active"; } ?>">Purchased Item</a>
                                    </li>

                                </ul>
                            </li>

                        </ul>
                    </li>
                    <!-- =======================================================================PURCHASE================================================================================ -->
                    

                    <!-- =======================================================================STOCK================================================================================ -->
                    <li class="<?= in_array($C_P, ['item_stock_report.php']) ? 'active' : '' ?>">
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Stock</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <!-- <li>
                                <a href="purchased_item.php"  class="<?php if($C_P=='purchased_item.php'){ echo "active"; } ?>">Stock</a>
                            </li> -->
 
                            <li class="<?= in_array($C_P, ['item_stock_report.php']) ? 'active' : '' ?>">
                                <a href="javascript:;">
                                    <span class="nav-label">Report</span><i class="fa fa-angle-left arrow"></i></a>
                                <ul class="nav-3-level collapse">
                                    <li>
                                        <a href="item_stock_report.php" class="<?php if($C_P=='item_stock_report.php'){ echo "active"; } ?>">Item Stock Check</a>
                                    </li>
                                </ul>
                            </li>

                        </ul>
                    </li>
                    <!-- =======================================================================STOCK================================================================================ -->

                    <!-- =======================================================================SALES================================================================================ -->
                    <li class="<?= in_array($C_P, ['tax_invoice.php', 'tax_invoice_edit.php', 'tax_invoice_view.php', 'tax_invoice_report.php']) ? 'active' : '' ?>">
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Sales</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="tax_invoice.php"  class="<?php if($C_P=='tax_invoice.php' || $C_P=='tax_invoice_edit.php' || $C_P=='tax_invoice_view.php' ){ echo "active"; } ?>">Tax Invoice</a>
                            </li>
 
                            <li class="<?= in_array($C_P, ['tax_invoice_report.php']) ? 'active' : '' ?>">
                                <a href="javascript:;">
                                    <span class="nav-label">Report</span><i class="fa fa-angle-left arrow"></i></a>
                                <ul class="nav-3-level collapse">
                                    <li>
                                        <a href="tax_invoice_report.php" class="<?php if($C_P=='tax_invoice_report.php'){ echo "active"; } ?>">Tax Invoice</a>
                                    </li>
                                </ul>
                            </li>

                        </ul>
                    </li>
                    <!-- =======================================================================SALES================================================================================ -->


                <?php
                }
                else
                {
	 
                    $MASTER=0;
                    $PURCHASE=0;
                    $STOCK=0;
                    $SALES=0;
                    $ACCOUNTS=0;

                    $header_department="SELECT department_name FROM user_department_master,master_user_department_access where master_user_department_access.user_id='$header_user_id' and user_department_master.department_id=master_user_department_access.department_id";
                    $department_query=mysqli_query($conn,$header_department);
            
                    while($fetch_department=mysqli_fetch_array($department_query))
                    {
                            $department_name=$fetch_department['department_name'];

                            if($department_name=='MASTER')
                            {
                                $MASTER=1;
                            }
                            else if($department_name=='PURCHASE')
                            {
                                $PURCHASE=1;
                            }
                            else if($department_name=='STOCK')
                            {
                                $STOCK=1; 
                            }
                            else if($department_name=='SALES')
                            {
                                $SALES=1;
                            }
                            else if($department_name=='ACCOUNTS')
                            {
                                $ACCOUNTS=1;
                            }
                    }

                    ?>


                    <?php 
                    if($MASTER==1)
                    {
                    ?>
                    <!-- =======================================================================MASTERS================================================================================ -->
                    <li class="<?= in_array($C_P, ['master_customer.php', 'master_vendor.php', 'master_raw_material.php', 'master_raw_material_unit.php', 'master_user.php', 'master_user_department_access.php']) ? 'active' : '' ?>">
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Masters</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="master_customer.php"  class="<?php if($C_P=='master_customer.php'){ echo "active"; } ?>">Customer</a>
                            </li>
                            <li>
                                <a href="master_vendor.php"  class="<?php if($C_P=='master_vendor.php'){ echo "active"; } ?>">Vendor</a>
                            </li>
                            <li>
                                <a href="master_user.php"  class="<?php if($C_P=='master_user.php'){ echo "active"; } ?>">Users</a>
                            </li>
                            <li>
                                <a href="master_user_department_access.php"  class="<?php if($C_P=='master_user_department_access.php'){ echo "active"; } ?>">Access Master</a>
                            </li>
                            <li>
                                <a href="master_raw_material.php"  class="<?php if($C_P=='master_raw_material.php'){ echo "active"; } ?>">Raw Metrial</a>
                            </li>
                            <li>
                                <a href="master_raw_material_unit.php"  class="<?php if($C_P=='master_raw_material_unit.php'){ echo "active"; } ?>">Raw Metrial Unit</a>
                            </li>
                        </ul>
                    </li>
                    <!-- =======================================================================MASTERS================================================================================ -->
                    <?php 
                    }
                    if($PURCHASE==1)
                    {
                    ?>
                    <!-- =======================================================================PURCHASE================================================================================ -->
                    <li class="<?= in_array($C_P, ['purchased_item.php', 'purchased_item_report.php', 'purchased_item_update.php']) ? 'active' : '' ?>">
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Purchase</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="purchased_item.php"  class="<?php if($C_P=='purchased_item.php' || $C_P=='purchased_item_update.php' ){ echo "active"; } ?>">Purchased Item Entry</a>
                            </li>
 
                            <li class="<?= in_array($C_P, ['purchased_item_report.php']) ? 'active' : '' ?>">
                                <a href="javascript:;">
                                    <span class="nav-label">Report</span><i class="fa fa-angle-left arrow"></i></a>
                                <ul class="nav-3-level collapse">
                                    <li>
                                        <a href="purchased_item_report.php" class="<?php if($C_P=='purchased_item_report.php'){ echo "active"; } ?>">Purchased Item</a>
                                    </li>

                                </ul>
                            </li>

                        </ul>
                    </li>
                    <!-- =======================================================================PURCHASE================================================================================ -->
                    <?php 
                    }
                    if($STOCK==1)
                    {
                    ?>
                    <!-- ======================================================================STOCK================================================================================ -->

                    <!-- =======================================================================STOCK================================================================================ -->
                    <?php 
                    }
                    if($SALES==1)
                    {
                    ?>
                    <!-- ======================================================================SALES================================================================================ -->

                    <!-- =======================================================================SALES================================================================================ -->
                    <?php 
                    }
                    if($ACCOUNTS==1)
                    {
                    ?>
                    <!-- ======================================================================ACCOUNTS================================================================================ -->

                    <!-- =======================================================================ACCOUNTS================================================================================ -->
                    <?php 
                    }
                    ?>







                <?php
                }
                ?>

                    <!-- =======================================================================PURCHASE================================================================================ -->

                    <li>
                        <a class="<?php if($C_P=='dashboard_logout.php'){ echo "active"; } ?>" href="dashboard_logout.php"><i class="sidebar-item-icon fa fa-sign-out"></i>
                            <span class="nav-label">Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>